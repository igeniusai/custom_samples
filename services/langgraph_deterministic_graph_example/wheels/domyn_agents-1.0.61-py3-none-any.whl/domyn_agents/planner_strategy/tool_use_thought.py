"""ReAct-style tool-use planner strategy.

Extends ``ToolUsePlannerStrategy`` with explicit thought emission:
the model's reasoning (from ``reasoning_content``, ``thinking_blocks``,
or preamble ``content`` when accompanied by tool calls) is extracted and
surfaced as ``Part(thought=...)`` inside the ``LLM_END`` event, and propagated
into every action's ``thought`` field so that ``ToolUseContextManager``
correctly reconstructs the history.

When the model has no native thinking capability, the companion
``ToolUseWithThoughtContextManager`` instructs it to emit plain-text reasoning
as ``content`` before tool calls; that text is captured as the thought.

When content appears **without** tool calls it is the response to the user
(streamable), not a thought.
"""

from __future__ import annotations

import json
import traceback
import uuid
from collections.abc import AsyncGenerator
from datetime import datetime

from domyn_agents.core import (
    AgentAction,
    BaseEvent,
    ExecutionEventType,
    LLMCallAction,
    Part,
    ToolAction,
)
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import LLMMessage, LLMResponse, LLMToolCall
from domyn_agents.llm.delegate import DelegateLLMProvider
from domyn_agents.logger import get_logger
from domyn_agents.planner_strategy.context_management.tool_use import (
    ToolUseWithThoughtContextManager,
)
from domyn_agents.planner_strategy.tool_use import (
    MAX_FV_SOFT_MISS_RETRIES,
    ToolUsePlannerStrategy,
    _create_event,
    _handle_forward_verbatim,
    _hard_miss_event,
)
from domyn_agents.planner_strategy.utils import (
    FORWARD_VERBATIM_FEEDBACK_HARD_FALLBACK,
)


def _extract_thought(
    tool_call: LLMToolCall, response: LLMResponse | None, fallback_response: bool = False
) -> str | None:
    """Extract the thought/reasoning from an LLM response.

    Priority:
    1. ``reasoning_content`` — explicit reasoning field (DeepSeek R1, Kimi, etc.)
    2. First ``thinking`` block from ``thinking_blocks`` — Anthropic extended thinking
    3. ``content`` — plain text preamble emitted before tool calls (solicited via
       the system prompt instruction in ``ToolUseWithThoughtContextManager``).
       Only treated as thought when tool_calls are also present — otherwise it
       is the response to the user.
    """
    if tool_call and json.loads(tool_call.function.arguments).get("reasoning", None):
        function_args = json.loads(tool_call.function.arguments)
        return function_args["reasoning"].strip()
    elif fallback_response and response:
        if response.reasoning_content:
            return response.reasoning_content.strip()
        if response.thinking_blocks:
            for block in response.thinking_blocks:
                if block.get("type") == "thinking" and block.get("thinking"):
                    return block.get("thinking", "").strip()
        if response.content and response.tool_calls:
            return response.content.strip()
    return None


class ToolUseWithThoughtPlannerStrategy(ToolUsePlannerStrategy):
    """Native tool-calling strategy with explicit thought emission (ReAct-style).

    Uses ``ToolUseWithThoughtContextManager`` by default, which appends a reasoning
    instruction to the system prompt so that the LLM emits plain-text ``content``
    before every tool call.  That content — or ``reasoning_content`` /
    ``thinking_blocks`` for models with native extended thinking — is then
    extracted and emitted as ``Part(thought=...)`` inside the ``LLM_END`` event.

    Thought extraction priority (first non-empty wins):
    1. ``reasoning_content``  — DeepSeek R1, Kimi, etc.
    2. ``thinking_blocks``    — Anthropic extended thinking
    3. ``response.content``   — preamble text solicited by the system prompt
    """

    type: str = "tool_use_thought"
    name: str = "tool_use_thought"
    context_manager: ToolUseWithThoughtContextManager = ToolUseWithThoughtContextManager()

    async def execute(
        self, agent: BaseAgent, interaction_context: InteractionContext
    ) -> AsyncGenerator[BaseEvent, None]:
        """Execute the ReAct-tool-use loop.

        Same as the parent loop but:
        - emits ``LLM_END`` with ``content=[Part(thought=<thought>)]`` when a
          thought is present so downstream consumers can display it.
        - passes the thought through ``ToolAction.thought`` (and ``AgentAction.thought``)
          so that ``ToolUseContextManager`` correctly reconstructs the history.
        """
        logger = get_logger()
        iteration = 0
        # See ``ToolUsePlannerStrategy.execute`` for soft-miss semantics.
        fv_soft_miss_remaining = MAX_FV_SOFT_MISS_RETRIES
        # Last-ditch fallback after soft-miss budget is spent: nudge the LLM
        # to drop FORWARD_VERBATIM and respond directly using history info,
        # avoiding AGENT_ERROR when the model can't recover the FV target.
        fv_hard_fallback_used = False
        fv_soft_miss_carry: list[LLMMessage] = []

        while iteration < self.max_iterations:
            iteration += 1

            messages = await self.context_manager.get_context(
                context=interaction_context, agent=agent
            )
            if fv_soft_miss_carry:
                messages.extend(fv_soft_miss_carry)
            tool_defs = self.context_manager.get_tool_definitions(agent, interaction_context)

            if agent.memory_manager:
                recalled_memories = await agent.memory_manager.recall_memories(
                    user_id=interaction_context.user_id,
                    agent=agent,
                    recency_limit=agent.memory_manager.recency_limit,
                    question=interaction_context.agent_input.content[0].text
                    if interaction_context.agent_input and interaction_context.agent_input.content
                    else "",
                    run_config=interaction_context.run_config,
                )
                if recalled_memories:
                    messages.insert(
                        1,
                        LLMMessage(
                            role="assistant",
                            content="\n".join([mem.memory for mem in recalled_memories]),
                        ),
                    )

            # ── LLM invocation ────────────────────────────────────────────────
            response: LLMResponse | None = None

            if isinstance(agent.llm_provider, DelegateLLMProvider):
                # Bidirectional: runner executes LLM, sends back LLMResponse via asend()
                response = yield BaseEvent(
                    event_type=ExecutionEventType.LLM_START,
                    action=LLMCallAction(
                        messages=messages,
                        tools=tool_defs,
                        stream=agent.stream,
                    ),
                    author=agent.name,
                )
                if response is None:
                    logger.error("DelegateLLMProvider received None from runner — aborting")
                    break
                # thought extraction still applies to delegated responses
            else:
                yield _create_event(
                    event_type=ExecutionEventType.LLM_START,
                    content=[Part(text="Invoking LLM with tools")],
                    author=agent.name,
                )
                try:
                    if agent.stream:
                        streamed_text_parts: list[str] = []
                        response = None
                        last_chunk = None
                        async for chunk in agent.llm_provider.generate_streaming(
                            messages=messages, tools=tool_defs if tool_defs else None
                        ):
                            last_chunk = chunk
                            # Drop only no-op (None/empty) chunks. Whitespace-only
                            # chunks (paragraph breaks, list separators) carry
                            # semantic meaning and must reach the consumer.
                            if chunk.content:
                                streamed_text_parts.append(chunk.content)
                                if not self.use_stop:
                                    yield BaseEvent(
                                        event_type=ExecutionEventType.RESPONSE_TOKEN,
                                        content=[Part(text=chunk.content)],
                                        author=agent.name,
                                        is_partial=True,
                                    )
                            if chunk.tool_calls:
                                response = chunk.model_copy(
                                    update={"content": "".join(streamed_text_parts)}
                                )
                        if response is None:
                            accumulated = "".join(streamed_text_parts)
                            base = last_chunk or LLMResponse(
                                content="", generated_tokens=0, execution_time=0.0
                            )
                            response = base.model_copy(
                                update={"content": accumulated, "tool_calls": []}
                            )
                            streamed_text_parts = []
                    else:
                        response = await agent.llm_provider.generate(
                            messages=messages,
                            tools=tool_defs if tool_defs else None,
                        )
                        if not response.content and not response.tool_calls:
                            logger.error("LLM response has no content and no tool calls")
                except Exception as e:
                    logger.error(
                        f"LLM generation failed: {e}",
                        payload={"exception": traceback.format_exc()},
                    )
                    yield BaseEvent(
                        event_type=ExecutionEventType.ERROR_OCCURRED,
                        event_id=str(uuid.uuid4()),
                        timestamp=datetime.now(),
                        author=agent.name,
                        content=[Part(text=f"LLM error: {e}")],
                        error_message=str(e),
                        is_partial=False,
                    )
                    break

            yield BaseEvent(
                event_type=ExecutionEventType.LLM_END,
                event_id=str(uuid.uuid4()),
                timestamp=datetime.now(),
                author=agent.name,
                content=[Part(text="LLM response received")],
                is_partial=False,
            )

            response_text = (response.content or "").strip()
            has_tool_calls = bool(response.tool_calls)

            # ── Content only (no tool calls) → terminal (response to user) ────
            if response_text and not has_tool_calls:
                if self.use_stop:
                    yield BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=agent.name,
                        action=ToolAction(
                            name=self.context_manager.stop_tool_name,
                            parameters={"info": response_text},
                        ),
                        content=[Part(text=response_text)],
                    )
                else:
                    yield BaseEvent(
                        event_type=ExecutionEventType.RESPONSE,
                        content=[Part(text=response_text)],
                        author=agent.name,
                        is_partial=False,
                    )
                return

            # ── Process tool calls ────────────────────────────────────────────
            if has_tool_calls:
                for i, tool_call in enumerate(response.tool_calls):
                    try:
                        # ── Extract and emit thought ──────────────────────────────────────
                        thought = _extract_thought(tool_call, response, fallback_response=i == 0)
                    except json.JSONDecodeError as e:
                        action = ToolAction(
                            call_id="",
                            name=agent.name,
                            parameters={},
                            observation=f"Failed to extract thought due to JSON error: {e}",
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_ERROR,
                            author=agent.name,
                            action=action,
                        )
                        continue
                    thought = thought.strip() if thought else None  # normalize empty to None
                    try:
                        args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        args = {}

                    tool_name = tool_call.function.name
                    tool = agent.get_tool_by_name(tool_name)

                    if tool:
                        action = ToolAction(
                            call_id=tool_call.id,
                            name=tool_name,
                            parameters=args,
                            thought=thought,
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_START,
                            author=agent.name,
                            action=action,
                        )
                    elif tool_name in [
                        a.name for a in interaction_context.agents_visibility_description
                    ]:
                        agent_action = AgentAction(
                            call_id=tool_call.id,
                            name=tool_name,
                            parameters=args,
                            thought=thought,
                            message=thought,
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.AGENT_CALL,
                            author=agent.name,
                            action=agent_action,
                        )
                        return
                    elif tool_name == self.context_manager.stop_tool_name and self.use_stop:
                        yield BaseEvent(
                            event_type=ExecutionEventType.AGENT_END,
                            author=agent.name,
                            action=ToolAction(
                                call_id=tool_call.id,
                                name=tool_name,
                                parameters=args,
                                thought=thought,
                            ),
                            content=[],
                        )
                        return
                    elif tool_name == self.context_manager.ask_user_tool_name and self.use_stop:
                        yield BaseEvent(
                            event_type=ExecutionEventType.RESPONSE,
                            content=[Part(text=args.get("text", ""))],
                            author=agent.name,
                            need_feedback=True,
                            action=ToolAction(name=tool_name, parameters=args, thought=thought),
                        )
                        return
                    elif (
                        tool_name == self.context_manager.forward_verbatim_tool_name
                        and self.forward_verbatim_enabled
                    ):
                        fv_result = _handle_forward_verbatim(
                            agent,
                            interaction_context,
                            tool_call,
                            args,
                            use_stop=self.use_stop,
                            stop_tool_name=self.context_manager.stop_tool_name,
                        )
                        if isinstance(fv_result, BaseEvent):
                            yield fv_result
                            return
                        if not self.use_stop and fv_soft_miss_remaining > 0:
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="assistant",
                                    content=None,
                                    tool_calls=[tool_call],
                                )
                            )
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="tool",
                                    tool_call_id=tool_call.id,
                                    name=tool_name,
                                    content=fv_result.feedback,
                                )
                            )
                            fv_soft_miss_remaining -= 1
                            logger.info(
                                f"FORWARD_VERBATIM soft-miss: retries remaining={fv_soft_miss_remaining}"
                            )
                            break
                        # Soft-miss budget exhausted. Last-ditch fallback (top-level
                        # only): tell the LLM to abandon FORWARD_VERBATIM and
                        # RESPOND directly with information already in history,
                        # instead of ending on AGENT_ERROR. Sub-agents skip this
                        # so the parent owns recovery.
                        if not self.use_stop and not fv_hard_fallback_used:
                            fv_hard_fallback_used = True
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="assistant",
                                    content=None,
                                    tool_calls=[tool_call],
                                )
                            )
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="tool",
                                    tool_call_id=tool_call.id,
                                    name=tool_name,
                                    content=FORWARD_VERBATIM_FEEDBACK_HARD_FALLBACK,
                                )
                            )
                            logger.info(
                                "FORWARD_VERBATIM hard-fallback: instructing LLM "
                                "to abandon FV and RESPOND directly"
                            )
                            break
                        yield _hard_miss_event(
                            agent,
                            use_stop=self.use_stop,
                            stop_tool_name=self.context_manager.stop_tool_name,
                        )
                        return
                    else:
                        action = ToolAction(
                            call_id=tool_call.id,
                            name=tool_name,
                            parameters=args,
                            observation=f"Tool '{tool_name}' not found",
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_ERROR,
                            author=agent.name,
                            action=action,
                        )
            elif response.content:
                if self.use_stop:
                    yield BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=agent.name,
                        action=ToolAction(
                            call_id=tool_call.id,
                            name=self.context_manager.stop_tool_name,
                            parameters={"info": response.content},
                            thought=thought,
                        ),
                        content=[Part(text=response.content)],
                    )
                else:
                    yield BaseEvent(
                        event_type=ExecutionEventType.RESPONSE,
                        content=[Part(text=response.content)],
                        author=agent.name,
                        is_partial=False,
                    )
                return

        yield BaseEvent(
            event_type=ExecutionEventType.RESPONSE,
            event_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            author=agent.name,
            content=[Part(text=f"Reached maximum iterations ({self.max_iterations})")],
            is_partial=False,
        )
