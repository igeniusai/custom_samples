"""DelegateAgent — an agent whose execution is handled by a remote runner.

A DelegateAgent appears in the local agent hierarchy (so the parent agent's
planner can hand off to it), but its actual execution is delegated via a
RunnerTransport to another runner instance, which may be in-process or remote.

The agent is a thin wrapper: it streams every event from the transport straight
to the runner.  The only transformation applied is that a final (non-partial)
``RESPONSE`` is converted to ``AGENT_END`` when the agent is running as a
sub-agent, so the parent orchestrator can resume with the result in history.

Tool events (``TOOL_START`` / ``TOOL_END``) from the external agent are
forwarded verbatim for observability.  The runner already skips local tool
execution for ``DelegateAgent`` instances, so no special routing is needed here.

Configuration example (programmatic)::

    from domyn_agents.agents.delegate_agent import DelegateAgent
    from domyn_agents.runner.websocket_transport import WebSocketTransport

    transport = WebSocketTransport(ws_url="ws://runner-b/ws")
    specialist = DelegateAgent(
        name="Specialist",
        description="Expert in domain X",
        transport=transport,
    )
    root_agent.sub_agents.append(specialist)
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator, Coroutine
from typing import Any, cast

from pydantic import ConfigDict, Field, model_validator

from domyn_agents.agents.base import HandoffVisibility
from domyn_agents.core import AgentDescription, BaseEvent, ExecutionEventType, Part
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.hooks.base import HookPhase
from domyn_agents.hooks.function_hook import FunctionHook
from domyn_agents.logger import get_logger
from domyn_agents.tools import MCPTool
from domyn_agents.tools.delegate_tool import DelegateTool
from domyn_agents.tools.function_tool import FunctionTool

logger = get_logger()


class DelegateAgent(BaseAgent):
    """Agent whose execution is fully delegated to a remote runner."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    type: str = "delegate"
    stream: bool = False  # runner must not suppress the promoted RESPONSE event

    runner_url: str | None = Field(
        default=None,
        description="URL of the remote runner. Used by HTTP-based transports.",
    )
    transport: Any | None = Field(
        default=None,
        description="RunnerTransport instance that handles communication with the remote runner.",
    )
    handoff_visibility: HandoffVisibility = Field(
        default=HandoffVisibility.STANDARD,
        description="Visibility level for handoff — same semantics as Agent.handoff_visibility.",
    )

    tools: list[FunctionTool | DelegateTool] = Field(
        default_factory=list,
        description=(
            "Tools the external agent may call. FunctionTools are executed locally "
            "and the result is sent back; DelegateTools are observed only (the "
            "external agent executes them itself)."
        ),
    )

    hooks: list[FunctionHook] = Field(
        default_factory=list, description="Hooks to be executed during the agent execution"
    )

    @property
    def pre_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.PRE_AGENT_CALL]

    @property
    def post_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.POST_AGENT_CALL]

    @property
    def on_event_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.ON_AGENT_EVENT]

    @model_validator(mode="before")
    @classmethod
    def _build_transport_from_dict(cls, values: Any) -> Any:
        """If ``transport`` is a plain dict, build the RunnerTransport from it.

        This lets callers (including the config loader) pass raw dicts and get
        a fully wired DelegateAgent back from ``model_validate``.
        """
        if not isinstance(values, dict):
            return values

        transport = values.get("transport")
        if transport is None or not isinstance(transport, dict):
            return values

        from domyn_agents.runner.transport import build_transport

        built = build_transport(transport)
        values["transport"] = built
        # Preserve runner_url as a convenience attribute for HTTP-based transports.
        values.setdefault("runner_url", transport.get("url") or None)
        # Tools stay in values["tools"] so they are held on the agent and
        # looked up by the runner when the external agent calls them.

        return values

    @property
    def invocation_parameters(self) -> dict[str, Any]:
        """Default parameters for agent invocation as function."""
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The specific task to perform by the agent. This is the more specific request for the agent to perform, with all the necessary details.",
                },
            },
            "required": ["task"],
        }

    @property
    def invocation_json_schema(self) -> dict:
        schema = {
            "properties": {
                self.name_string: {"const": self.name, "type": "string"},
                self.parameters_string: self.invocation_parameters,
            },
            "required": [self.parameters_string],
            "description": self.description,
        }
        return schema

    def get_tool_by_name(self, tool_name: str) -> FunctionTool | DelegateTool | None:
        return next((t for t in self.tools if t.name == tool_name), None)

    def get_agent_description(self) -> AgentDescription:
        return AgentDescription(
            name=self.name,
            description=self.description,
            invocation_json_schema=self.invocation_json_schema,
            invocation_parameters=self.invocation_parameters,
        )

    def __hash__(self) -> int:
        return hash(self.name)

    async def execute(
        self, context: InteractionContext
    ) -> AsyncGenerator[tuple[BaseEvent, InteractionContext], None]:
        if self.transport is None:
            raise RuntimeError(
                f"DelegateAgent '{self.name}' has no transport configured. "
                "Set a RunnerTransport before execution."
            )

        is_subagent = (
            context.agent_input is not None
            and context.agent_input.event_type == ExecutionEventType.AGENT_START
        )

        originating_action = context.agent_input.action if context.agent_input is not None else None
        agent_end_emitted = False

        async for event in self.transport.execute(self.name, context):
            # Some external agents signal completion via AGENT_END (with content)
            # instead of RESPONSE. Promote it to a final RESPONSE only on the
            # root-agent path. For sub-agent path, keep AGENT_END semantics.
            # An AGENT_END with no content is a pure wire-level termination
            # signal — end the generator cleanly.

            if event.event_type == ExecutionEventType.AGENT_END:
                if not event.content:
                    event = event.model_copy(
                        update={
                            "content": [
                                Part(
                                    thought=f"Agent {self.name} finished without providing a content"
                                )
                            ]
                        }
                    )
                if is_subagent:
                    # Ensure the AGENT_END carries the originating action so the parent
                    # context manager can reconstruct the assistant message.
                    # Preserve error_code/error_message so the parent planner's
                    # OBSERVATION message surfaces the failure to the parent LLM.
                    agent_end_emitted = True
                    yield (
                        BaseEvent(
                            event_type=ExecutionEventType.AGENT_END,
                            author=self.name,
                            content=event.content,
                            action=originating_action,
                            error_code=event.error_code,
                            error_message=event.error_message,
                        ),
                        context,
                    )
                else:
                    logger.info(
                        "[DelegateAgent '%s'] Promoting AGENT_END with content to final RESPONSE",
                        self.name,
                    )
                    yield (
                        BaseEvent(
                            event_type=ExecutionEventType.RESPONSE,
                            author=self.name,
                            content=event.content,
                            is_partial=False,
                            error_code=event.error_code,
                            error_message=event.error_message,
                        ),
                        context,
                    )
                continue

            if (
                event.event_type == ExecutionEventType.RESPONSE
                and not event.is_partial
                and is_subagent
            ):
                # Sub-agent path: the parent orchestrator expects AGENT_END to resume.
                # Carry the originating action so the parent context manager can
                # reconstruct the assistant message.
                logger.info(
                    "[DelegateAgent '%s'] Converting final RESPONSE to AGENT_END for parent orchestrator",
                    self.name,
                )
                agent_end_emitted = True
                yield (
                    BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=self.name,
                        content=event.content,
                        action=originating_action,
                    ),
                    context,
                )
            else:
                yield event, context

        # Fallback: if running as sub-agent and the transport ended without emitting
        # a proper AGENT_END (e.g. connection drop, timeout, or partial-only stream),
        # synthesize one so the parent runner can pop the stack and resume correctly.
        if is_subagent and not agent_end_emitted:
            logger.warning(
                "[DelegateAgent '%s'] Transport ended without AGENT_END — emitting fallback",
                self.name,
            )
            yield (
                BaseEvent(
                    event_type=ExecutionEventType.AGENT_END,
                    author=self.name,
                    content=[
                        Part(thought=f"Agent {self.name} completed without explicit response")
                    ],
                    action=originating_action,
                ),
                context,
            )

    async def initialize_mcp_tools(self) -> None:
        """Initialize and fetch tools from configured MCP servers.

        This method should be called after agent creation to automatically
        discover and add tools from configured MCP servers.
        """

        tasks: list[Coroutine[Any, Any, Any]] = []

        async def safe_tool_init(t: MCPTool) -> None:
            try:
                await t.initialize()
            except Exception as e:
                get_logger().warning(
                    f"Could not initialize MCP tool {t.name} from {t.server_url}: {e}"
                )

        mcp_tools = filter(lambda x: isinstance(x, MCPTool), cast(list[MCPTool], self.tools))
        init_tasks = map(safe_tool_init, mcp_tools)
        tasks.extend(init_tasks)
        await asyncio.gather(*tasks)
