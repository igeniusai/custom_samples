"""Worker runtime: owns one ws connection's queue, drain, semaphore, and in-flight tasks.

Per connection (lifecycle controlled by the caller):

  - One bounded ``asyncio.Queue[str]`` of outbound BaseEvent JSON payloads.
    Trace events from the handler are best-effort: ``put_nowait`` rejection
    bumps ``events_dropped`` and discards. Platform-tool ``TOOL_START``
    payloads use ``put`` (blocking) so they cannot be dropped — losing them
    would deadlock the awaiting future.
  - One drain task pulls from the queue and ``await ws.send(payload)``.
  - One semaphore caps in-flight invocations at ``max_concurrency``. A
    ``busy_buffer`` allows a small queue of waiting invocations beyond
    that; over-limit invokes are rejected synchronously with a
    ``WorkerBusy`` ERROR_OCCURRED BaseEvent and never enter the registry.
  - One in-flight task registry keyed by request_id (kept so future cancel
    routing can be added without a structural change).
  - One per-invocation ``_make_emit(request_id)`` closure that JSON-encodes
    the ``BaseEvent`` produced by the handler and enqueues it.

The receive loop dispatches AGENT_START to ``_on_invoke`` and routes
TOOL_END / TOOL_ERROR to pending platform-tool futures keyed by
``ToolAction.call_id``; any other inbound BaseEvent is debug-logged and
ignored.
"""

from __future__ import annotations

import asyncio
import contextlib
import contextvars
import json
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import typer
from pydantic import ValidationError

from domyn_agents.core import BaseEvent, ExecutionEventType, Part, RelayMessage, ToolAction
from domyn_agents.integrations.langgraph.domyn_platform import PlatformRelay
from domyn_agents.integrations.langgraph.handler import PlatformCallbackHandler
from domyn_agents.integrations.langgraph.utils import InputMapper
from domyn_agents.logger import get_logger


@dataclass(frozen=True)
class _InvocationCtx:
    """Identity carried from an AGENT_START into the runnable so platform tool
    calls emitted mid-execution can be tagged with the same correlation IDs."""

    request_id: str
    author: str
    interaction_id: str | None
    conversation_id: str | None
    turn_id: str | None


_invocation_ctx: contextvars.ContextVar[_InvocationCtx | None] = contextvars.ContextVar(
    "domyn_langgraph_invocation_ctx", default=None
)

logger = get_logger()


def _extract_result_text(result: Any) -> str:
    """Extract plain text from a LangGraph ainvoke result.

    Priority:
    1. Last AI message content (ReAct / messages-based graphs).
    2. A top-level ``result`` string field (state-machine graphs that build
       a human-readable summary, e.g. loan_assessment_graph).
    3. Full JSON dump as a last resort.
    """
    if isinstance(result, dict):
        messages = result.get("messages")
        if messages:
            for msg in reversed(messages):
                content = getattr(msg, "content", None)
                if isinstance(content, str) and content:
                    return content
        result_field = result.get("result")
        if isinstance(result_field, str) and result_field:
            return result_field
    return json.dumps(result, default=str)


class Runtime:
    """Owns one WebSocket's invoke / event lifecycle for a connected runnable."""

    def __init__(
        self,
        *,
        runnable: Any,
        ws: Any,
        project_id: str = "domyn-relay",
        max_concurrency: int = 8,
        busy_buffer: int | None = None,
        queue_maxsize: int = 10_000,
        input_mapper: InputMapper | None = None,
        platform_relay: PlatformRelay | None = None,
    ) -> None:
        self._runnable = runnable
        self._ws = ws
        self._project_id = project_id
        self._max_concurrency = max_concurrency
        self._busy_buffer = busy_buffer if busy_buffer is not None else max_concurrency
        self._queue_maxsize = queue_maxsize
        self._input_mapper = input_mapper
        self._platform_relay = platform_relay

        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._in_flight: dict[str, asyncio.Task[None]] = {}
        self._outbound: asyncio.Queue[str] = asyncio.Queue(maxsize=queue_maxsize)
        self._drain_task: asyncio.Task[None] | None = None
        self._stop = asyncio.Event()
        self._platform_calls: dict[str, asyncio.Future[Any]] = {}

        self.events_sent = 0
        self.events_dropped = 0

    async def run(self) -> None:
        """Start the drain task and run the receive loop until the ws closes."""
        self._drain_task = asyncio.create_task(self._drain_loop(), name="outbound-drain")
        if self._platform_relay is not None:
            self._platform_relay.bind(self)
        try:
            await self._receive_loop()
        finally:
            await self.aclose()

    async def aclose(self) -> None:
        self._stop.set()
        if self._platform_relay is not None:
            self._platform_relay.unbind(self)
        for fut in self._platform_calls.values():
            if not fut.done():
                fut.set_exception(RuntimeError("Runtime shutting down"))
        self._platform_calls.clear()
        for task in list(self._in_flight.values()):
            task.cancel()
        if self._in_flight:
            await asyncio.gather(*self._in_flight.values(), return_exceptions=True)
        if self._drain_task is not None:
            self._drain_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._drain_task
            self._drain_task = None

    # ---- emit closure ----

    def _make_emit(self, request_id: str) -> Callable[[BaseEvent], Awaitable[None]]:
        """Build a per-invocation emit closure that JSON-encodes and enqueues."""

        async def emit(base_event: BaseEvent) -> None:
            payload = base_event.model_dump_json()
            try:
                logger.debug("emit request_id=%s payload=%.1200s", request_id, payload)
                typer.echo(f"emit request_id={request_id} payload={payload:.1200}")
                self._outbound.put_nowait(payload)
            except asyncio.QueueFull:
                self.events_dropped += 1
                logger.warning("outbound queue full; dropped event request_id=%s", request_id)

        return emit

    # ---- loops ----

    async def _drain_loop(self) -> None:
        while not self._stop.is_set():
            try:
                payload = await self._outbound.get()
            except asyncio.CancelledError:
                return
            try:
                logger.debug("drain send payload=%.1200s", payload)
                typer.echo(f"drain send payload={payload:.1200}")
                await self._ws.send(payload)
                self.events_sent += 1
            except asyncio.CancelledError:
                return
            except Exception:
                logger.warning("drain_loop send failed", exc_info=True)
                self.events_dropped += 1
            finally:
                self._outbound.task_done()

    async def _receive_loop(self) -> None:
        async for raw in self._ws:
            try:
                body = RelayMessage.model_validate_json(raw)
                event = body.payload
                _ = body.meta
            except ValidationError:
                logger.debug("received non-BaseEvent message: %.200s", raw)
                continue

            if event.event_type == ExecutionEventType.AGENT_START:
                await self._on_invoke(event)
            elif event.event_type in (
                ExecutionEventType.TOOL_END,
                ExecutionEventType.TOOL_ERROR,
            ):
                self._on_tool_response(event)
            else:
                logger.debug("ignoring BaseEvent event_type=%s", event.event_type.value)

    def _on_tool_response(self, event: BaseEvent) -> None:
        """Resolve the future of a pending platform tool call keyed by call_id."""
        call_id = getattr(event.action, "call_id", None) if event.action else None
        if call_id is None:
            return
        future = self._platform_calls.pop(call_id, None)
        if future is None or future.done():
            return
        if event.event_type == ExecutionEventType.TOOL_ERROR:
            future.set_exception(
                RuntimeError(event.error_message or f"platform tool error ({event.error_code})")
            )
            return
        observation = getattr(event.action, "observation", None) if event.action else None
        future.set_result(observation)

    # ---- platform tool round-trip ----

    async def call_platform_tool(self, name: str, kwargs: dict[str, Any]) -> Any:
        """Send a TOOL_START to the relay and suspend until TOOL_END/TOOL_ERROR.

        Called by ``PlatformTool._arun`` while a langgraph node is executing.
        The current AGENT_START's identity is read from a contextvar so the
        emitted TOOL_START carries the matching author/interaction/turn IDs.
        """
        ctx = _invocation_ctx.get()
        call_id = str(uuid.uuid4())

        tool_start = BaseEvent(
            event_type=ExecutionEventType.TOOL_START,
            author=ctx.author if ctx else self._project_id,
            timestamp=datetime.now(UTC).replace(tzinfo=None),
            conversation_id=ctx.conversation_id if ctx else None,
            interaction_id=ctx.interaction_id if ctx else None,
            turn_id=ctx.turn_id if ctx else None,
            action=ToolAction(name=name, parameters=kwargs, call_id=call_id),
        )

        loop = asyncio.get_running_loop()
        future: asyncio.Future[Any] = loop.create_future()
        self._platform_calls[call_id] = future

        try:
            # Use put() (not put_nowait) so we never silently drop a TOOL_START —
            # dropping it would deadlock the awaiting future. Queue ordering
            # guarantees this TOOL_START is sent after any trace events the
            # handler already enqueued for this invocation.
            await self._outbound.put(tool_start.model_dump_json())
        except Exception:
            self._platform_calls.pop(call_id, None)
            raise

        try:
            return await future
        finally:
            self._platform_calls.pop(call_id, None)

    # ---- invoke handling ----

    async def _on_invoke(self, event: BaseEvent) -> None:
        request_id = event.event_id or ""
        if not request_id:
            logger.warning("AGENT_START event has no event_id; skipping")
            return

        action_params = getattr(event.action, "parameters", None)
        if action_params:
            raw_input: dict[str, Any] = dict(action_params)
        else:
            raw_input = event.model_dump(mode="json")

        input_data: Any = self._input_mapper(raw_input) if self._input_mapper else raw_input

        metadata: dict[str, Any] = {
            **event.metadata,
            "user_id": event.metadata.get("user_id") or event.author,
            "session_id": event.interaction_id or event.metadata.get("session_id"),
            "conversation_id": event.conversation_id,
        }

        if len(self._in_flight) >= self._max_concurrency + self._busy_buffer:
            busy = BaseEvent(
                event_type=ExecutionEventType.ERROR_OCCURRED,
                author=event.author,
                event_id=request_id,
                timestamp=datetime.now(UTC).replace(tzinfo=None),
                interaction_id=event.interaction_id,
                error_code="WorkerBusy",
                error_message="max concurrency reached",
            )
            try:
                logger.debug("rejecting invoke request_id=%s with WorkerBusy", request_id)
                await self._ws.send(busy.model_dump_json())
            except Exception:
                logger.warning("failed to send WorkerBusy rejection", exc_info=True)
            return

        handler = PlatformCallbackHandler(
            project_id=self._project_id,
            emit=self._make_emit(request_id),
            user_id=metadata.get("user_id"),
            session_id=metadata.get("session_id"),
        )

        async def _runner() -> None:
            ctx_token = _invocation_ctx.set(
                _InvocationCtx(
                    request_id=request_id,
                    author=event.author,
                    interaction_id=event.interaction_id,
                    conversation_id=event.conversation_id,
                    turn_id=event.turn_id,
                )
            )
            async with self._semaphore:
                try:
                    result = await self._runnable.ainvoke(
                        input_data,
                        config={
                            "callbacks": [handler],
                            "metadata": {**metadata, "request_id": request_id},
                        },
                    )
                    done = BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=event.author,
                        event_id=request_id,
                        timestamp=datetime.now(UTC).replace(tzinfo=None),
                        interaction_id=event.interaction_id,
                        conversation_id=event.conversation_id,
                        content=(
                            [Part(text=_extract_result_text(result))] if result is not None else []
                        ),
                    )
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.error(
                        "invocation failed request_id=%s: %s", request_id, exc, exc_info=True
                    )
                    done = BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=event.author,
                        event_id=request_id,
                        timestamp=datetime.now(UTC).replace(tzinfo=None),
                        interaction_id=event.interaction_id,
                        conversation_id=event.conversation_id,
                        error_code=type(exc).__name__,
                        error_message=str(exc),
                    )
                finally:
                    await handler.aclose()
                    _invocation_ctx.reset(ctx_token)

                try:
                    await asyncio.wait_for(self._outbound.join(), timeout=2.0)
                except TimeoutError:
                    logger.warning(
                        "outbound drain timed out before completion request_id=%s",
                        request_id,
                    )
                # Stamp AGENT_END after the queue drains so its timestamp is
                # definitively later than all callback events (tool/llm) already sent.
                done = done.model_copy(update={"timestamp": datetime.now(UTC).replace(tzinfo=None)})
                try:
                    payload = done.model_dump_json()
                    logger.debug("completion request_id=%s payload=%.1200s", request_id, payload)
                    typer.echo(f"completion request_id={request_id} payload={payload:.1200}")
                    await self._ws.send(payload)
                except Exception:
                    logger.warning(
                        "failed to send completion request_id=%s", request_id, exc_info=True
                    )

        task = asyncio.create_task(_runner(), name=f"invoke:{request_id}")
        self._in_flight[request_id] = task

        def _cleanup(_t: asyncio.Task[None], rid: str = request_id) -> None:
            self._in_flight.pop(rid, None)

        task.add_done_callback(_cleanup)
