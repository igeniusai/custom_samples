import sys
import warnings
from importlib.metadata import PackageNotFoundError, version

warnings.filterwarnings(
    "ignore", category=UserWarning, message=r"Field name .* shadows an attribute in parent"
)

from domyn_agents.agents import register_agent_type  # noqa: E402
from domyn_agents.core import decorators as _decorators  # noqa: E402
from domyn_agents.runner.transport import register_transport  # noqa: E402

try:
    __version__ = version("domyn-agents")
except PackageNotFoundError:
    __version__ = "unknown"

# Make decorators available as a module directly under domyn_agents
sys.modules[f"{__name__}.decorators"] = _decorators
decorators = _decorators

__all__ = ["__version__", "decorators", "register_agent_type", "register_transport"]
