"""WebSocket-based RunnerTransport for DelegateAgent.

Thin wire layer: connects to a WebSocket relay, sends an ``AGENT_START`` to
kick off the external agent, and streams every event it receives back to the
caller with ``author`` normalised to *agent_name*.

**Reconnect-per-boundary behaviour**

The connection is opened fresh for each *boundary* event (any non-partial
event).  Partial / token-level ``RESPONSE`` events are yielded from the same
connection without reconnecting.  This prevents a long-lived socket from
accumulating stale events from concurrent conversations.

When the runner executes a local tool it calls ``send_result()`` which stores
the ``TOOL_END`` event.  The next ``execute()`` iteration reconnects, sends the
pending event, and then waits for the next boundary.

``send_result()`` lets the caller push ``TOOL_END`` / ``LLM_END`` results back
to the external agent while the stream is active.  All higher-level logic —
tool routing, event-type conversion — belongs in the ``DelegateAgent`` that
consumes this transport.

Wire it up::

    from domyn_agents.runner.websocket_transport import WebSocketTransport
    from domyn_agents.agents.delegate_agent import DelegateAgent

    transport = WebSocketTransport(ws_url="ws://localhost:8765")
    agent = DelegateAgent(
        name="MathAgent",
        description="...",
        transport=transport,
    )

The caller is responsible for adding the ``DelegateAgent`` to its parent's
``sub_agents`` list (or using it as the entrypoint of a ``Runner``).
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import websockets
import websockets.asyncio.client as ws_client

from domyn_agents.core import AgentAction, BaseEvent, ExecutionEventType, Part
from domyn_agents.core.context import InteractionContext
from domyn_agents.logger import get_logger
from domyn_agents.runner.transport import RunnerTransport


def _is_streaming_event(event: BaseEvent) -> bool:
    """Return True for events that should NOT trigger a reconnect."""
    return event.event_type == ExecutionEventType.RESPONSE and (event.is_partial is True)


def _is_terminal_event(event: BaseEvent) -> bool:
    """Return True when the full delegate session is over."""
    if event.event_type == ExecutionEventType.AGENT_END:
        return True
    return event.event_type == ExecutionEventType.RESPONSE and not event.is_partial


class WebSocketTransport(RunnerTransport):
    """Bidirectional WebSocket transport for ``DelegateAgent``.

    Parameters
    ----------
    type:
        ``"websocket"`` — used as the ``transport.type`` discriminator in configs.
    ws_url:
        ``ws://`` or ``wss://`` URL of the relay server.
    headers:
        Extra HTTP headers sent on the WebSocket handshake (e.g.
        ``{"channel-id": "abc", "Authorization": "Bearer …"}``).
    timeout:
        Seconds to wait for the next message before raising
        ``asyncio.TimeoutError``.
    ping_interval:
        Interval in seconds between WebSocket keep-alive pings.  ``None``
        disables pings.
    """

    type: ClassVar[str] = "websocket"

    @classmethod
    def from_config(cls, config: dict) -> WebSocketTransport:
        return cls(
            ws_url=config.get("url", ""),
            headers=config.get("headers"),
            timeout=float(config.get("timeout", 60.0)),
            ping_interval=config.get("ping_interval", 20.0),
        )

    def __init__(
        self,
        ws_url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 60.0,
        ping_interval: float | None = 20.0,
    ) -> None:
        self._ws_url = ws_url
        self._headers = headers or {}
        self._timeout = timeout
        self._ping_interval = ping_interval
        # Pending outbound event set by send_result() between generator turns.
        self._pending_outbound: BaseEvent | None = None

    # ------------------------------------------------------------------
    # RunnerTransport interface
    # ------------------------------------------------------------------

    async def execute(
        self,
        agent_name: str,
        context: InteractionContext,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Stream events for *agent_name* from the remote WebSocket endpoint.

        Opens a fresh connection for each boundary event so no socket is held
        open between turns.  Yields every received event with ``author``
        normalised to *agent_name*.  Terminates after ``AGENT_END`` or a final
        ``RESPONSE``.
        """
        user_text = self._extract_user_text(context)

        forwarded_action = (
            context.agent_input.action
            if context.agent_input is not None
            and context.agent_input.event_type == ExecutionEventType.AGENT_START
            and isinstance(context.agent_input.action, AgentAction)
            else AgentAction(
                name=agent_name,
                parameters={"user_request": user_text, "task": user_text},
            )
        )
        agent_start = BaseEvent(
            event_type=ExecutionEventType.AGENT_START,
            author=agent_name,
            content=[Part(text=user_text)],
            action=forwarded_action,
            interaction_id=context.interaction_id,
            turn_id=context.turn_id,
        )

        # On the first iteration we send AGENT_START; on subsequent iterations
        # we send the pending TOOL_END / LLM_END stored by send_result().
        first_iteration = True

        connect_kwargs: dict[str, Any] = {
            "additional_headers": self._headers,
            "open_timeout": self._timeout,
        }
        if self._ping_interval is not None:
            connect_kwargs["ping_interval"] = self._ping_interval

        while True:
            outbound = agent_start if first_iteration else self._pending_outbound
            first_iteration = False
            self._pending_outbound = None

            get_logger().info("[WS transport] Connecting to %s", self._ws_url)
            boundary_event: BaseEvent | None = None

            try:
                async with ws_client.connect(self._ws_url, **connect_kwargs) as ws:  # type: ignore[arg-type]
                    if outbound is not None:
                        get_logger().debug(
                            "[WS transport] Sending %s for agent '%s'",
                            outbound.event_type.value,
                            agent_name,
                        )
                        await ws.send(outbound.model_dump_json())

                    async for event in self._relay(ws, agent_name):
                        yield event
                        if not _is_streaming_event(event):
                            boundary_event = event
                            break  # close connection, surface event to caller
            except TimeoutError:
                error_msg = (
                    f"The delegated agent '{agent_name}' could not be reached "
                    f"(connection timeout to {self._ws_url}). "
                    "The connection has been closed. Please check the agent's availability and connection."
                )
                get_logger().warning(
                    "[WS transport] Connect timeout to %s — stopping", self._ws_url
                )
                yield BaseEvent(
                    event_type=ExecutionEventType.AGENT_END,
                    author=agent_name,
                    error_code="delegate_timeout",
                    error_message=error_msg,
                    content=[Part(text=error_msg)],
                )
                break
            except websockets.exceptions.ConnectionClosed as exc:
                get_logger().info("[WS transport] Connection closed unexpectedly: %s", exc)
                break

            if boundary_event is None:
                get_logger().warning("[WS transport] Connection closed without a boundary event")
                break

            if _is_terminal_event(boundary_event):
                get_logger().info("[WS transport] Session complete for agent '%s'", agent_name)
                break
            # Non-terminal boundary (TOOL_START etc.): caller will call
            # send_result() and then advance the generator for the next round.

    async def send_result(self, event: BaseEvent) -> None:
        """Store a result event to be sent on the next reconnect."""
        self._pending_outbound = event
        get_logger().debug("[WS transport] Queued %s for next reconnect", event.event_type.value)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _relay(
        self,
        ws: ws_client.ClientConnection,
        agent_name: str,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Receive events from the WebSocket and yield them verbatim.

        Normalises ``author`` to *agent_name* on every event.
        """
        while True:
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=self._timeout)
            except TimeoutError:
                error_msg = (
                    f"The delegated agent '{agent_name}' stopped responding "
                    f"(no message received within {self._timeout}s). "
                    "The connection has been closed. Please check the agent's availability and connection."
                )
                get_logger().warning("[WS transport] Timeout waiting for next event — closing")
                yield BaseEvent(
                    event_type=ExecutionEventType.AGENT_END,
                    author=agent_name,
                    error_code="delegate_timeout",
                    error_message=error_msg,
                    content=[Part(text=error_msg)],
                )
                break
            except websockets.exceptions.ConnectionClosed as exc:
                get_logger().info("[WS transport] Connection closed: %s", exc)
                break

            try:
                event = BaseEvent.model_validate_json(raw)
            except Exception:
                get_logger().warning("[WS transport] Could not parse event: %r", raw)
                continue

            event = event.model_copy(update={"author": agent_name})
            get_logger().debug("[WS transport] Received %s", event.event_type.value)
            yield event

            # Yield all events; the outer execute() loop decides when to break.

    @staticmethod
    def _extract_user_text(context: InteractionContext) -> str:
        """Pull plain text from the user input event in *context*.

        For root-agent calls the user_input is a ``USER_INPUT`` event whose
        ``content`` carries the user message directly.

        For sub-agent calls the user_input is the ``AGENT_START`` event emitted
        by the parent orchestrator's planner.  The text lives in
        ``action.parameters`` (keys ``task`` and/or ``user_request``) because
        the planner encodes the handoff as an agent tool-call — there is no
        ``content`` on the event.
        """
        user_input = context.agent_input

        parts = getattr(user_input, "content", []) or []
        text_from_content = " ".join(p.text for p in parts if p.text)
        if text_from_content:
            return text_from_content

        action = getattr(user_input, "action", None)
        if action is not None:
            params: dict[str, Any] = getattr(action, "parameters", None) or {}
            task: str = params.get("task", "")
            user_request: str = params.get("user_request", "")
            if task and user_request and task != user_request:
                return f"{user_request}\n\nTask: {task}"
            return task or user_request

        return ""
