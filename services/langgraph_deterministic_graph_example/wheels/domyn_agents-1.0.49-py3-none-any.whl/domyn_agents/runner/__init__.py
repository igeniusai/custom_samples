import asyncio
import copy
import inspect
import json
import uuid
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel

from domyn_agents.agents.agent import Agent
from domyn_agents.agents.base import HandoffVisibility
from domyn_agents.agents.delegate_agent import DelegateAgent
from domyn_agents.conversation_manager import (
    BaseConversationManager,
    ConversationInfo,
    InMemoryConversationManager,
)
from domyn_agents.conversation_manager.base import StackAgentEntry
from domyn_agents.core import (
    METADATA_FORWARD_VERBATIM,
    AgentAction,
    BaseAction,
    BaseEvent,
    ExecutionEventType,
    FeedbackAction,
    FeedbackParameters,
    LLMCallAction,
    Part,
    ToolAction,
)
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.hooks.base import HookError, HookResult, HookType
from domyn_agents.hooks.function_hook import FunctionHook
from domyn_agents.llm.base import LLMResponse
from domyn_agents.llm.delegate import DelegateLLMProvider
from domyn_agents.logger import get_logger
from domyn_agents.registry.agents import get_agent_registry
from domyn_agents.tools.base import ToolResult, UpdateToolResult
from domyn_agents.tools.delegate_tool import DelegateTool
from domyn_agents.tools.function_tool import FunctionTool
from domyn_agents.tools.streamable_function_tool import (
    StreamableToolResult,
)

NO_COPY_KEYS = {"tool", "result", "agent"}


@dataclass
class RunnerState:
    """Encapsulates the state of a runner execution."""

    application_name: str
    user_id: str
    conversation_id: str
    conversation_info: ConversationInfo
    current_agent: Agent | DelegateAgent
    available_agents: list[Agent | DelegateAgent]
    entrypoint_agent: Agent | DelegateAgent
    interaction_id: str | None = None
    turn_id: str | None = None  # stable across agent transitions within a single user-input turn
    run_config: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)


class ContextBuilder:
    """Helper class to build InteractionContext instances."""

    @staticmethod
    def create_context(
        state: RunnerState,
        user_input: BaseEvent,
        agent_stack_entry: StackAgentEntry | None = None,
    ) -> InteractionContext:
        """Create an InteractionContext with proper visibility rules."""
        agents_visibility = ContextBuilder._get_agents_visibility(
            state.current_agent, state.entrypoint_agent
        )

        # filter events_history
        visible_authors = [state.current_agent.name] + [a.name for a in agents_visibility]
        user_event_types = [ExecutionEventType.USER_INPUT, ExecutionEventType.TOOL_FEEDBACK]
        restrict_user_events_by_interaction_id = (
            state.current_agent is not state.entrypoint_agent
            and state.current_agent.handoff_visibility != HandoffVisibility.GLOBAL
        )
        events_history = [
            event
            for event in state.conversation_info.events_history
            if event.author in visible_authors
            or (
                event.event_type in user_event_types
                and (
                    not restrict_user_events_by_interaction_id
                    or event.interaction_id == state.interaction_id
                )
            )
        ]

        if user_input.interaction_id is None:
            user_input.interaction_id = state.interaction_id

        # build interaction_history. For TOOL_FEEDBACK resume we must seed it from the
        # persisted history (the in-progress agent's prior tool calls live there).
        # For other inputs the history is populated incrementally via _add_event(...,
        # context=context) as USER_INPUT and AGENT_START are stored.
        interaction_history: list[BaseEvent] = []
        if (
            user_input.event_type == ExecutionEventType.TOOL_FEEDBACK
            and state.conversation_info.events_history
        ):
            # recover the AGENT_START that called the current agent plus all its interaction events
            agents_calls = list(
                filter(
                    lambda x: (
                        x.event_type == ExecutionEventType.AGENT_START
                        and x.action.name == state.current_agent.name
                    ),
                    state.conversation_info.events_history,
                )
            )
            if agents_calls:
                agents_calls = [agents_calls[-1]]

            interaction_history = agents_calls + list(
                filter(
                    lambda x: (
                        x.interaction_id == state.interaction_id
                        and x.event_type != ExecutionEventType.USER_INPUT
                    ),
                    state.conversation_info.events_history,
                )
            )

        return InteractionContext(
            conversation_id=state.conversation_id,
            user_id=state.user_id,
            agent_input=user_input,
            interaction_id=state.interaction_id,
            turn_id=state.turn_id,
            conversation_history=events_history,
            interaction_history=interaction_history,
            agents_visibility_description=[
                agent.get_agent_description()
                for agent in agents_visibility
                if agent != state.current_agent
            ],  # TODO: perche non prendo quello di sopra direttamente?
            state=state.conversation_info.state or {},
            run_config=state.run_config,
        )

    @staticmethod
    def _get_agents_visibility(
        current_agent: Agent | DelegateAgent, entrypoint_agent: Agent | DelegateAgent
    ) -> list[Agent | DelegateAgent]:
        """Determine which agents are visible based on handoff visibility settings."""

        if current_agent.handoff_visibility == HandoffVisibility.GLOBAL:
            return _return_subagents(entrypoint_agent)
        elif current_agent.handoff_visibility == HandoffVisibility.PEERS:
            parent = _find_parent(entrypoint_agent, current_agent)
            if parent is None:
                return _return_subagents(current_agent)
            peers: list[Agent | DelegateAgent] = []
            for sibling in parent.sub_agents:
                peers.extend(_return_subagents(_return_agent(sibling)))
            return peers
        else:  # HandoffVisibility.STANDARD
            return [_return_agent(agent) for agent in current_agent.sub_agents]


def _return_agent(agent: Agent | DelegateAgent | str) -> Agent | DelegateAgent:
    """Return the agent instance, resolving string references via the registry."""
    if isinstance(agent, str):
        return get_agent_registry().get_agent(agent)
    return agent


def _find_parent(
    root: Agent | DelegateAgent, target: Agent | DelegateAgent
) -> Agent | DelegateAgent | None:
    """Find the direct parent of `target` in the agent tree rooted at `root`."""
    for sub_agent in getattr(root, "sub_agents", []):
        resolved = _return_agent(sub_agent)
        if resolved == target:
            return root
        parent = _find_parent(resolved, target)
        if parent is not None:
            return parent
    return None


def _return_subagents(agent: Agent | DelegateAgent) -> list[Agent | DelegateAgent]:
    """Return all agents in the subtree rooted at `agent`, including itself."""
    agents: list[Agent | DelegateAgent] = []

    for sub_agent in getattr(agent, "sub_agents", []):
        _sub_agent = _return_agent(sub_agent)
        agents.extend(_return_subagents(_sub_agent))

    if agent not in agents:
        agents.append(_return_agent(agent))
    return list(filter(None, agents))


class AgentHookExecution(BaseModel):
    event: BaseEvent
    context: InteractionContext
    break_execution: bool


class OnEventHookExecution(BaseModel):
    hook_event: BaseEvent
    current_event: BaseEvent
    break_execution: bool = False


class Runner:
    """Orchestrates agent execution and conversation management."""

    def __init__(
        self,
        conversation_manager: BaseConversationManager | None = None,
        runner_id: str | None = None,
    ):
        logger = get_logger()
        self.runner_id = runner_id or f"runner_{uuid.uuid4().hex[:8]}"
        self.conversation_manager = conversation_manager or InMemoryConversationManager()
        logger.info(
            "Runner initialized with conversation manager: %s, runner_id: %s",
            type(self.conversation_manager).__name__,
            self.runner_id,
        )

    async def run(
        self,
        application_name: str,
        user_id: str,
        user_input: BaseEvent,
        root: Agent,
        entrypoint_name: str | None = None,
        entrypoint_visibility: HandoffVisibility | None = None,
        conversation_id: str | None = None,
        run_config: dict | None = None,
        metadata: dict | None = None,
    ) -> AsyncGenerator[BaseEvent, None]:
        """
        Run the agent framework with the given parameters.
        """

        if entrypoint_name is None:
            entrypoint_name = root.name

        entrypoint: Agent | DelegateAgent | None = next(
            filter(lambda agent: agent.name == entrypoint_name, _return_subagents(root)), None
        )

        if entrypoint is None:
            raise ValueError(
                f"Entrypoint agent '{entrypoint_name}' not found in the agent hierarchy."
            )

        entrypoint.handoff_visibility = entrypoint_visibility or entrypoint.handoff_visibility

        state = await self._get_state(
            application_name=application_name,
            user_id=user_id,
            root=root,
            entrypoint=entrypoint,
            conversation_id=conversation_id,
        )

        # pass run_config to state
        state.run_config = run_config or {}

        # metadata could not be empty
        if metadata is None:
            metadata = {}

        # add metadata to the state
        state.metadata = metadata

        # Set up IDs; AGENT_START is built after hooks so hooks can modify user_input first
        is_new_conversation, stack_agent_name = await self._setup_conversation_turn(
            state, user_input
        )
        # TODO: this could be moved inside execute_agent_loop
        # Build the InteractionContext now so on_agent_event hooks fired on the initial
        # USER_INPUT receive a real context. interaction_history starts
        # empty for non-TOOL_FEEDBACK inputs and is populated incrementally below by
        # _add_event(..., context=context) calls.
        await self._refresh_state(state)
        stack_entry = await self.conversation_manager.get_last_agent_stack(
            state.application_name, state.user_id, state.conversation_id
        )
        context = ContextBuilder.create_context(state, user_input, stack_entry)

        should_continue = True
        # Run ON_AGENT_EVENT hooks on the incoming user input before storing it
        async for on_exec in self.run_on_event_hooks(
            state.current_agent.on_event_hooks,
            user_input,
            context=context,
            agent_name=state.current_agent.name,
            state=state,
        ):
            yield on_exec.hook_event
            user_input = on_exec.current_event
            should_continue = not on_exec.break_execution and (
                on_exec.current_event.event_type != ExecutionEventType.RESPONSE
                or on_exec.current_event.is_partial
            )
            if not should_continue:
                break
        if not should_continue:
            if not on_exec.break_execution:
                await self._add_event(state, user_input, context=context)
                yield user_input
            return

        # Store the (possibly modified) user input
        await self._add_event(state, user_input, context=context)

        # Build AGENT_START from the (possibly hook-modified) user_input, then store/yield it.
        # Hooks do NOT run on AGENT_START — they already fired on USER_INPUT above.
        # Side effect: on_agent_event hooks with on_event_triggers = AGENT_START will not fire on the initial AGENT_START
        event_start = self._build_agent_start_event(
            state, user_input, is_new_conversation, stack_agent_name
        )
        if event_start and event_start.event_type != user_input.event_type:
            if is_new_conversation:
                await self._add_event(state, event_start, context=context)
            yield event_start
        elif is_new_conversation and event_start:
            # TOOL_FEEDBACK resuming: event_start is user_input (already stored above), store only
            await self._add_event(state, event_start, context=context)

        # Keep agent_input pointing at the (possibly hook-modified) input so the loop sees the latest
        context.agent_input = user_input

        # Execute agent loop
        async for event in self._execute_agent_loop(state, user_input, context):
            yield event

    async def _get_state(
        self,
        application_name: str,
        user_id: str,
        root: Agent | DelegateAgent,
        entrypoint: Agent | DelegateAgent,
        conversation_id: str | None,
    ) -> RunnerState:
        """Retrieve or create runner state with conversation and agent setup."""
        if root is None:
            raise ValueError("Root agent must be provided.")

        if entrypoint is None:
            entrypoint = root

        available_agents = _return_subagents(root)

        if not await self.conversation_manager.check_conversation_exists(
            application_name, user_id, conversation_id
        ):
            conversation_info = await self.conversation_manager.create_conversation(
                application_name, user_id, conversation_id
            )
        else:
            conversation_info = await self.conversation_manager.get_conversation(
                application_name, user_id, conversation_id
            )
        conversation_id = conversation_info.conversation_id

        # Determine current agent (resume from stack or use entrypoint)
        current_agent = await self._get_current_agent(
            application_name, user_id, conversation_id, entrypoint, available_agents
        )

        return RunnerState(
            application_name=application_name,
            user_id=user_id,
            conversation_id=conversation_id,
            conversation_info=conversation_info,
            current_agent=current_agent,
            available_agents=available_agents,
            entrypoint_agent=root,
        )

    async def _get_current_agent(
        self,
        application_name: str,
        user_id: str,
        conversation_id: str,
        entrypoint: Agent | DelegateAgent,
        available_agents: list[Agent | DelegateAgent],
    ) -> Agent | DelegateAgent:
        """Get the current agent from stack or return entrypoint."""
        stack_entry = await self.conversation_manager.get_last_agent_stack(
            application_name, user_id, conversation_id
        )

        if stack_entry:
            return next(
                (agent for agent in available_agents if agent.name == stack_entry.agent_name),
                entrypoint,
            )
        return entrypoint

    async def _setup_conversation_turn(
        self, state: RunnerState, user_input: BaseEvent
    ) -> tuple[bool, str | None]:
        """Set up IDs for a new/resumed turn. Must be called before ON_AGENT_EVENT hooks run.

        Returns (is_new_conversation, stack_agent_name) where:
        - is_new_conversation is True only for new conversations whose AGENT_START must be persisted.
        - stack_agent_name is the agent name from the existing stack entry (resumed conversations only).
        """
        stack_entry = await self.conversation_manager.get_last_agent_stack(
            state.application_name, state.user_id, state.conversation_id
        )

        if not stack_entry:  # New conversation
            state.interaction_id = InteractionContext.generate_interaction_id()
            state.turn_id = user_input.turn_id or InteractionContext.generate_turn_id()

            user_input.conversation_id = state.conversation_id
            user_input.interaction_id = state.interaction_id
            user_input.turn_id = state.turn_id

            await self.conversation_manager.add_agent_to_stack(
                application_name=state.application_name,
                user_id=state.user_id,
                conversation_id=state.conversation_id,
                interaction_id=state.interaction_id,
                turn_id=state.turn_id,
                agent_name=state.current_agent.name,
            )
            return True, None

        else:  # Resuming conversation
            state.interaction_id = stack_entry.interaction_id
            if user_input.event_type == ExecutionEventType.USER_INPUT:
                state.turn_id = user_input.turn_id or InteractionContext.generate_turn_id()
            else:
                state.turn_id = (
                    user_input.turn_id
                    or stack_entry.turn_id
                    or InteractionContext.generate_turn_id()
                )

            user_input.conversation_id = state.conversation_id
            user_input.interaction_id = state.interaction_id
            user_input.turn_id = state.turn_id

            return False, stack_entry.agent_name

    def _build_agent_start_event(
        self,
        state: RunnerState,
        user_input: BaseEvent,
        is_new_conversation: bool,
        stack_agent_name: str | None,
    ) -> BaseEvent:
        """Build the AGENT_START event from the (possibly hook-modified) user_input.

        Must be called after ON_AGENT_EVENT hooks have run on user_input so that any
        content modifications made by those hooks are reflected in the AGENT_START event.
        """
        if is_new_conversation:  # New conversation
            return BaseEvent(
                event_type=ExecutionEventType.AGENT_START,
                author=state.current_agent.name,
                content=user_input.content,
                conversation_id=state.conversation_id,
                interaction_id=state.interaction_id,
                turn_id=state.turn_id,
                action=AgentAction(
                    name=state.current_agent.name,
                    parameters={},
                    thought="",
                ),
            )

        # Resuming conversation
        if user_input.event_type == ExecutionEventType.USER_INPUT:
            return BaseEvent(
                event_type=ExecutionEventType.AGENT_START,
                author=state.current_agent.name,
                content=user_input.content,
                conversation_id=state.conversation_id,
                interaction_id=state.interaction_id,
                turn_id=state.turn_id,
                action=AgentAction(
                    name=state.current_agent.name,
                    parameters={},
                    thought="",
                ),
            )

        # TOOL_FEEDBACK resumption: treat user_input itself as the start event
        return user_input

    async def _execute_agent_loop(
        self,
        state: RunnerState,
        user_input: BaseEvent,
        context: InteractionContext,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Execute the main agent loop with proper event handling."""
        logger = get_logger()

        logger.info("Runner: starting agent loop")

        # handle feedback on tool
        if user_input.event_type == ExecutionEventType.TOOL_FEEDBACK:
            # mi sa che devo fare check rispetto a prima

            # come gestire solo il feedback negativo
            # creare observation
            # se Y -> eseguo tool (con nuovi parametri se forniti)
            # .      con use confirm prendo quelli vecchi
            # se N -> user refuse to execute tool -> e lo metto in tool end

            # recover last tool_start
            previous_event: BaseEvent | None = next(
                filter(
                    lambda x: x.event_type == ExecutionEventType.TOOL_START,
                    reversed(context.interaction_history),
                ),
                None,
            )
            if previous_event is None:
                logger.error("TOOL_FEEDBACK received but no prior TOOL_START found in history")
                return

            if user_input.action.approve:
                tool: FunctionTool | DelegateTool | None = state.current_agent.get_tool_by_name(
                    user_input.action.name
                )
                if tool is None:
                    logger.error(f"Approval received for unknown tool '{user_input.action.name}'")
                    return
                user_input.action = user_input.action.to_tool_action()
                tool_events = (
                    self._execute_tool(tool, state, context, user_input)  # Function Tool
                )
                last_tool_event = None
                async for tool_event in tool_events:
                    tool_event.turn_id = state.turn_id
                    tool_event.interaction_id = context.interaction_id
                    if tool_event.event_type not in [
                        ExecutionEventType.TOOL_END,
                        ExecutionEventType.TOOL_ERROR,
                    ]:
                        yield tool_event
                    last_tool_event = tool_event
                if last_tool_event is not None:
                    last_tool_event.interaction_id = context.interaction_id
                    last_tool_event.turn_id = state.turn_id
                yield last_tool_event

                if user_input.action.parameters != previous_event.action.parameters:
                    new_updated_action = user_input.model_copy(deep=True).action
                    new_updated_action.parameters = previous_event.action.parameters
                    new_updated_action.observation = f"IMPORTANT: The user update tool parameters for tool: {user_input.action.name} with parameters: {user_input.action.parameters}). Continue the executions with these new parameters."
                    tool_end_event = BaseEvent(
                        event_type=ExecutionEventType.TOOL_END,
                        author=previous_event.author,
                        interaction_id=context.interaction_id,
                        action=new_updated_action,
                    )
                    tool_start_event = BaseEvent(
                        event_type=ExecutionEventType.TOOL_START,
                        author=previous_event.author,
                        interaction_id=context.interaction_id,
                        action=user_input.action,
                    )

                    # save the tool end and start in history
                    await self._add_event(state, tool_end_event, context=context)
                    await self._add_event(state, tool_start_event, context=context)

            else:
                new_refuse_action = user_input.action.to_tool_action()
                new_refuse_action.observation = (
                    f"User refused to execute the tool {user_input.action.name}."
                )
                tool_event = BaseEvent(
                    event_type=ExecutionEventType.TOOL_END,
                    author=previous_event.author,
                    interaction_id=context.interaction_id,
                    action=new_refuse_action,
                )

            # save the tool end in history
            await self._add_event(state, tool_event, context=context)

            # Recover the AGENT_START that seeded the current agent's task
            context.agent_input = next(
                filter(
                    lambda x: (
                        x.event_type == ExecutionEventType.AGENT_START
                        and getattr(x.action, "name", None) == state.current_agent.name
                    ),
                    reversed(context.conversation_history),
                ),
                context.agent_input,
            )

        # Run pre-hooks of the current agent before starting the planner loop
        should_continue = True
        async for hook_exec in self._apply_agent_hooks(
            hooks=state.current_agent.pre_hooks,
            state=state,
            context=context,
            agent=state.current_agent,
        ):
            context = hook_exec.context
            if should_continue:
                should_continue = not hook_exec.break_execution
            yield hook_exec.event

        agent_iterator = state.current_agent.execute(context).__aiter__()
        # Pending LLM response to feed back to the planner via asend()
        # when a DelegateLLMProvider is in use.
        pending_llm_response: LLMResponse | None = None

        while state.current_agent is not None and should_continue:
            try:
                event: BaseEvent
                yielded = await agent_iterator.asend(pending_llm_response)
                event, context = yielded

                # Compatibility: some tests/legacy mocks yield (event, context)
                # from the inner execute generator. In that case the wrapped
                # iterator returns ((event, context), context).
                if isinstance(event, tuple) and len(event) == 2 and isinstance(event[0], BaseEvent):
                    nested_context = event[1]
                    event = event[0]
                    if isinstance(nested_context, InteractionContext):
                        context = nested_context

                pending_llm_response = None
            except StopAsyncIteration:
                break

            event = self._ensure_event_identifiers(state=state, event=event, context=context)

            # Run ON_AGENT_EVENT hooks of the current agent on each emitted event
            if agent_on_event_hooks := state.current_agent.on_event_hooks:
                async for on_exec in self.run_on_event_hooks(
                    agent_on_event_hooks,
                    event,
                    context,
                    agent_name=state.current_agent.name,
                    state=state,
                ):
                    yield on_exec.hook_event
                    event = on_exec.current_event
                    should_continue = not on_exec.break_execution
                    if not should_continue:
                        break
                if not should_continue:
                    break

            # TODO: to test se porta controindicazioni salvare prima di ritornare
            if event.is_partial is False:
                await self._add_event(state, event, context=context)
            # boh se funziona
            await self.conversation_manager.update_conversation_state(
                state.application_name,
                state.user_id,
                state.conversation_id,
                context.state,
            )

            # Sync in-memory state to prevent loss on next context refresh
            # Without this, custom keys in context.state are lost when creating next InteractionContext
            state.conversation_info.state = context.state

            # Handle response events (end of conversation)
            match event.event_type:
                case ExecutionEventType.RESPONSE:
                    if (
                        not event.need_feedback and not event.is_partial
                    ):  # final response, end conversation
                        await self.conversation_manager.empty_agents_stack(
                            state.application_name, state.user_id, state.conversation_id
                        )
                    # Yield RESPONSE when:
                    # - agent is not streaming (no RESPONSE_TOKEN sequence to replace it), OR
                    # - the event carries FORWARD_VERBATIM metadata from the active
                    #   user-facing agent, OR
                    # - the event needs feedback from the user:
                    #   feedback responses are emitted as a single direct yield,
                    #   not preceded by RESPONSE_TOKEN streaming, so dropping
                    #   them under stream=True loses the user-facing question.
                    if (
                        not state.current_agent.stream
                        or event.metadata.get(METADATA_FORWARD_VERBATIM)
                        or event.need_feedback
                    ):
                        yield event
                    if event.need_feedback:
                        return
                    if not event.is_partial:
                        # Final response - close agent and execute post-hooks before exiting
                        try:
                            await agent_iterator.aclose()
                        finally:
                            # Execute post-hooks of the ending agent (must run even if aclose fails)
                            async for hook_exec in self._apply_agent_hooks(
                                hooks=state.current_agent.post_hooks,
                                state=state,
                                context=context,
                                agent=state.current_agent,
                            ):
                                context = hook_exec.context
                                if should_continue:
                                    should_continue = not hook_exec.break_execution
                                yield hook_exec.event

                        # Yield AGENT_END event and exit
                        event = BaseEvent(
                            event_type=ExecutionEventType.AGENT_END,
                            author=event.author,
                            interaction_id=event.interaction_id,
                            turn_id=state.turn_id,
                        )

                        if agent_on_event_hooks := state.current_agent.on_event_hooks:
                            async for on_exec in self.run_on_event_hooks(
                                agent_on_event_hooks,
                                event,
                                context,
                                agent_name=state.current_agent.name,
                                state=state,
                            ):
                                yield on_exec.hook_event
                                event = on_exec.current_event
                        event = self._ensure_event_identifiers(
                            state=state, event=event, context=context
                        )
                        await self._add_event(state, event, context)
                        yield event
                        break

                # Handle agent call (strategy emits AGENT_CALL when delegating to a sub-agent)
                case ExecutionEventType.AGENT_CALL:
                    try:
                        await agent_iterator.aclose()
                    except Exception:
                        logger.warning(
                            "agent_iterator.aclose() failed during agent transition", exc_info=True
                        )

                    stopped_by_hook = False
                    async for hook_exec in self._apply_agent_hooks(
                        hooks=state.current_agent.post_hooks,
                        state=state,
                        context=context,
                        agent=state.current_agent,
                    ):
                        context = hook_exec.context
                        yield hook_exec.event
                        if hook_exec.break_execution:
                            stopped_by_hook = True
                    if stopped_by_hook:
                        break
                    if should_continue is False:
                        yield event
                        break

                    # Yield AGENT_CALL first so consumers see the calling agent's action
                    yield event

                    new_agent, new_context, agent_start_event = await self._handle_agent_transition(
                        state, event, context
                    )

                    if new_agent is None:
                        break

                    state.current_agent = new_agent
                    context = new_context

                    # Then yield the runner-created AGENT_START (called agent receiving its task).
                    # Apply the called agent's on_event hooks first so they can modify the event.
                    if agent_start_event is not None:
                        if called_agent_on_event_hooks := new_agent.on_event_hooks:
                            async for on_exec in self.run_on_event_hooks(
                                called_agent_on_event_hooks,
                                agent_start_event,
                                context,
                                agent_name=new_agent.name,
                                state=state,
                            ):
                                yield on_exec.hook_event
                                agent_start_event = on_exec.current_event
                                should_continue = not on_exec.break_execution and (
                                    on_exec.current_event.event_type != ExecutionEventType.RESPONSE
                                    or on_exec.current_event.is_partial
                                )
                                if not should_continue:
                                    break
                            if not should_continue:
                                if not on_exec.break_execution:
                                    await self._add_event(state, agent_start_event, context=context)
                                    yield agent_start_event
                                break
                        await self._add_event(state, agent_start_event, context=context)
                        yield agent_start_event

                    async for hook_exec in self._apply_agent_hooks(
                        hooks=state.current_agent.pre_hooks,
                        state=state,
                        context=context,
                        agent=state.current_agent,
                    ):
                        context = hook_exec.context
                        if should_continue:
                            should_continue = not hook_exec.break_execution
                        yield hook_exec.event
                    agent_iterator = new_agent.execute(context).__aiter__()
                    continue  # skip bottom yield — already yielded AGENT_CALL above

                # AGENT_START events proxied from the remote are forwarded as-is.
                # The runner must NOT re-enter the transition path for these events.
                case ExecutionEventType.AGENT_START:
                    if isinstance(state.current_agent, DelegateAgent):
                        yield event
                        continue

                # Handle agent end (sub-agent returning to caller)
                case ExecutionEventType.AGENT_END:
                    try:
                        await agent_iterator.aclose()
                    except Exception:
                        logger.warning(
                            "agent_iterator.aclose() failed during agent transition", exc_info=True
                        )

                    stopped_by_hook = False
                    async for hook_exec in self._apply_agent_hooks(
                        hooks=state.current_agent.post_hooks,
                        state=state,
                        context=context,
                        agent=state.current_agent,
                    ):
                        context = hook_exec.context
                        yield hook_exec.event
                        if hook_exec.break_execution:
                            stopped_by_hook = True
                    if stopped_by_hook:
                        break
                    if should_continue is False:
                        yield event
                        break

                    new_agent, new_context, _ = await self._handle_agent_transition(
                        state, event, context
                    )

                    if new_agent is None:
                        yield event
                        break

                    state.current_agent = new_agent
                    context = new_context

                    async for hook_exec in self._apply_agent_hooks(
                        hooks=state.current_agent.pre_hooks,
                        state=state,
                        context=context,
                        agent=state.current_agent,
                    ):
                        context = hook_exec.context
                        if should_continue:
                            should_continue = not hook_exec.break_execution
                        yield hook_exec.event
                    agent_iterator = new_agent.execute(context).__aiter__()

                case ExecutionEventType.LLM_START:
                    # Handle delegate LLM execution when the agent uses DelegateLLMProvider.
                    # The planner yielded LLM_START with an LLMCallAction payload instead of
                    # calling the provider directly. Execute here and set pending_llm_response
                    # so the next asend() feeds the result back to the planner.
                    if (
                        not isinstance(state.current_agent, DelegateAgent)
                        and isinstance(event.action, LLMCallAction)
                        and isinstance(
                            getattr(state.current_agent, "llm_provider", None),
                            DelegateLLMProvider,
                        )
                    ):
                        provider: DelegateLLMProvider = state.current_agent.llm_provider
                        if provider.wrapped is not None:
                            if event.action.stream:
                                chunks = []
                                async for chunk in provider.wrapped.generate_streaming(
                                    messages=event.action.messages,
                                    tools=event.action.tools,
                                ):
                                    chunks.append(chunk)
                                    if chunk.content:
                                        yield self._ensure_event_identifiers(
                                            state=state,
                                            context=context,
                                            event=BaseEvent(
                                                event_type=ExecutionEventType.RESPONSE_TOKEN,
                                                content=[Part(text=chunk.content)],
                                                author=state.current_agent.name,
                                                interaction_id=context.interaction_id,
                                                turn_id=state.turn_id,
                                                is_partial=True,
                                            ),
                                        )
                                accumulated = "".join(c.content or "" for c in chunks)
                                last = chunks[-1] if chunks else None
                                pending_llm_response = (
                                    last.model_copy(update={"content": accumulated})
                                    if last
                                    else LLMResponse(
                                        content=accumulated, generated_tokens=0, execution_time=0.0
                                    )
                                )
                            else:
                                pending_llm_response = await provider.wrapped.generate(
                                    messages=event.action.messages,
                                    tools=event.action.tools,
                                )
                        # Yield LLM_START for observability (without large payload)
                        observability_text = (
                            "Delegated LLM call — executing via wrapped provider"
                            if provider.wrapped is not None
                            else "Delegated LLM call — no wrapped provider, runner-to-runner transport not yet implemented"
                        )
                        yield self._ensure_event_identifiers(
                            state=state,
                            context=context,
                            event=BaseEvent(
                                event_type=ExecutionEventType.LLM_START,
                                content=[Part(text=observability_text)],
                                author=event.author,
                                interaction_id=context.interaction_id,
                                turn_id=state.turn_id,
                            ),
                        )
                        continue

                case ExecutionEventType.TOOL_START:
                    if isinstance(state.current_agent, DelegateAgent):
                        # Yield for observability regardless of action type — the external
                        # agent may send TOOL_START with a null or non-ToolAction action.
                        event = self._ensure_event_identifiers(
                            state=state, event=event, context=context
                        )
                        yield event

                        known_tool = (
                            state.current_agent.get_tool_by_name(event.action.name)
                            if isinstance(event.action, ToolAction)
                            else None
                        )
                        if known_tool is None:
                            # Unknown tool: external agent handles it — observe only.
                            continue
                        # Known tool: execute locally and send the result back so
                        # the external agent can continue its reasoning loop.
                        tool_events = self._execute_tool(known_tool, state, context, event)
                        async for tool_event in tool_events:
                            tool_event = self._ensure_event_identifiers(
                                state=state,
                                event=tool_event,
                                context=context,
                            )
                            if tool_event.event_type not in [
                                ExecutionEventType.TOOL_END,
                                ExecutionEventType.TOOL_ERROR,
                            ]:
                                yield tool_event
                        event = tool_event
                        await self._add_event(state, event, context=context)
                        if state.current_agent.transport is not None:
                            await state.current_agent.transport.send_result(event)
                        yield event  # TOOL_END / TOOL_ERROR for observability
                        continue

                    # skip if tool start action not provided
                    # TODO: per il futuro quando arriveranno solo le action
                    if not isinstance(event.action, ToolAction):
                        continue

                    tool: FunctionTool | DelegateTool | None = state.current_agent.get_tool_by_name(
                        event.action.name
                    )

                    if tool is None:
                        action_copy = event.action.model_copy()
                        action_copy.observation = f"Tool '{event.action.name}' not found on agent '{state.current_agent.name}'"
                        yield self._ensure_event_identifiers(
                            state=state,
                            context=context,
                            event=BaseEvent(
                                event_type=ExecutionEventType.TOOL_ERROR,
                                author=state.current_agent.name,
                                action=action_copy,
                                error_code="ToolNotFound",
                                error_message=action_copy.observation,
                            ),
                        )
                        continue

                    # Pure DelegateTool (no wrapped callable): forward to parent runner via
                    # transport.  Transport (Step 5) is not yet implemented — yield TOOL_ERROR.
                    if isinstance(tool, DelegateTool) and tool.wrapped is None:
                        action_copy = event.action.model_copy()
                        action_copy.observation = (
                            f"DelegateTool '{tool.tool_name}' has no local implementation. "
                            "Runner-to-runner transport (Step 5) is not yet implemented."
                        )
                        yield event  # emit TOOL_START for observability
                        yield self._ensure_event_identifiers(
                            state=state,
                            context=context,
                            event=BaseEvent(
                                event_type=ExecutionEventType.TOOL_ERROR,
                                author=state.current_agent.name,
                                action=action_copy,
                                error_code="DelegateToolNoTransport",
                                error_message=action_copy.observation,
                            ),
                        )
                        continue

                    # check need feedback
                    if tool.approval_type:
                        approval_event = BaseEvent(
                            event_type=ExecutionEventType.TOOL_NEEDS_FEEDBACK,
                            author=state.current_agent.name,
                            conversation_id=state.conversation_id,
                            interaction_id=context.interaction_id,
                            turn_id=state.turn_id,
                            action=FeedbackAction(
                                call_id=event.action.call_id,
                                approval_type=tool.approval_type,
                                name=event.action.name,
                                thought=event.action.thought,
                                parameters=[
                                    FeedbackParameters(name=k, value=v, type=type(v).__name__)
                                    for k, v in event.action.parameters.items()
                                ],
                            ),
                        )
                        if agent_on_event_hooks := state.current_agent.on_event_hooks:
                            async for on_exec in self.run_on_event_hooks(
                                agent_on_event_hooks,
                                approval_event,
                                context,
                                agent_name=state.current_agent.name,
                                state=state,
                            ):
                                yield on_exec.hook_event
                                approval_event = on_exec.current_event
                                should_continue = not on_exec.break_execution and (
                                    on_exec.current_event.event_type != ExecutionEventType.RESPONSE
                                    or on_exec.current_event.is_partial
                                )
                                if not should_continue:
                                    break
                            if not should_continue:
                                if not on_exec.break_execution:
                                    await self._add_event(state, approval_event, context=context)
                                    yield approval_event
                                break
                        yield approval_event
                        break  # aspettiamo feedback prima di riprendere

                    yield event  # ritorniamo all utente il tool start

                    tool_events = self._execute_tool(tool, state, context, event)

                    async for tool_event in tool_events:
                        tool_event = self._ensure_event_identifiers(
                            state=state,
                            event=tool_event,
                            context=context,
                        )
                        tool_event.turn_id = state.turn_id
                        tool_event.interaction_id = context.interaction_id
                        if agent_on_event_hooks := state.current_agent.on_event_hooks:
                            async for on_exec in self.run_on_event_hooks(
                                agent_on_event_hooks,
                                tool_event,
                                context,
                                agent_name=state.current_agent.name,
                                state=state,
                            ):
                                yield on_exec.hook_event
                                tool_event = on_exec.current_event
                                should_continue = not on_exec.break_execution and (
                                    on_exec.current_event.event_type != ExecutionEventType.RESPONSE
                                    or on_exec.current_event.is_partial
                                )
                                if not should_continue:
                                    break
                            if not should_continue:
                                if not on_exec.break_execution:
                                    yield tool_event
                                break
                        if tool_event.event_type not in [
                            ExecutionEventType.TOOL_END,
                            ExecutionEventType.TOOL_ERROR,
                        ]:
                            yield tool_event
                    # questo verra ritornato all utente
                    event = tool_event
                    # salviamo il tool end
                    await self._add_event(state, event, context=context)
                    if not should_continue:
                        break
            # normal event yield
            # TODO: refactor funzione, si brutto ma per ora evito doppie yield di response partial

            if event.event_type != ExecutionEventType.RESPONSE:
                # aggiorno lo stato
                await self.conversation_manager.update_conversation_state(
                    state.application_name,
                    state.user_id,
                    state.conversation_id,
                    context.state,
                )

                yield event

    def _ensure_event_identifiers(
        self,
        state: RunnerState,
        event: BaseEvent,
        context: InteractionContext | None = None,
    ) -> BaseEvent:
        """Fill event identifiers from runner/context when missing."""
        event.event_id = event.event_id or f"event_{uuid.uuid4()}"
        event.conversation_id = event.conversation_id or state.conversation_id
        event.interaction_id = (
            event.interaction_id or getattr(context, "interaction_id", None) or state.interaction_id
        )
        event.turn_id = event.turn_id or getattr(context, "turn_id", None) or state.turn_id
        return event

    async def _execute_tool(
        self,
        tool: FunctionTool | DelegateTool,
        state: RunnerState,
        context: InteractionContext,
        event: BaseEvent,
    ) -> AsyncGenerator[BaseEvent, None]:
        tool_args = {
            "run_config": context.run_config,
            "state": context.state,
            **event.action.parameters,
        }
        """Execute a streamable tool and yield events."""
        tool_result: ToolResult | None = None
        try:
            # Execute pre-hooks before executing the tool
            async for hook_result, updated_tool_args in self.run_tool_pre_hooks(
                context=context, tool_args=tool_args, state=state, tool=tool
            ):
                tool_args = updated_tool_args
                yield hook_result
            # Execute the tool

            if not inspect.isasyncgenfunction(tool.execute):
                tool_result = await tool.execute(**tool_args)
            else:
                _s: ToolResult | StreamableToolResult | UpdateToolResult
                async for _s in tool.execute(
                    **tool_args,
                ):
                    if isinstance(_s, StreamableToolResult):
                        yield BaseEvent(
                            event_type=ExecutionEventType.RESPONSE,
                            author=state.current_agent.name,
                            action=event.action,
                            is_partial=True,
                            content=_s.data if isinstance(_s.data, list) else [_s.data],
                        )
                    elif isinstance(_s, UpdateToolResult):
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_UPDATE,
                            author=state.current_agent.name,
                            action=event.action,
                            is_partial=True,
                            content=[Part(metadata=_s.data)],
                        )
                    else:
                        # Here we have a ToolResult as last event
                        tool_result = _s
            if tool_result is None:
                raise RuntimeError("Streamable tool did not yield a result.")
            if tool_result.state is not None:
                # Inplace update of context state
                context.state.clear()
                context.state.update(tool_result.state)
            # update tool_result.state with context.state for post hooks --> so the post hooks receive the updated state
            tool_result.state = context.state
            # Execute post hooks before yielding the tool end if the execution is successful
            async for hook_execution, tool_result in self.run_tool_post_hooks(  # noqa: B007, B020
                context=context, tool_result=tool_result, state=state, tool=tool
            ):
                yield hook_execution

            # only last event become observation
            action_copy = event.action.model_copy()
            action_copy.observation = (
                tool_result.data if not tool_result.error else tool_result.error
            )
            tool_event = BaseEvent(
                event_type=ExecutionEventType.TOOL_END
                if not tool_result.error
                else ExecutionEventType.TOOL_ERROR,
                author=state.current_agent.name,
                action=action_copy,
                metadata=tool_result.metadata if tool_result.metadata else {},
                error_code=tool_result.error_code,
                error_message=tool_result.error,
            )
            yield tool_event
        except Exception as e:
            action_copy = event.action.model_copy()
            action_copy.observation = f"Error executing tool {event.action.name}: {e}"
            error_code: str | None
            error_message: str | None
            if tool_result is None:
                error_code = "Missing tool result due to exception"
                error_message = str(e)
            else:
                # Use error info from _s if available, otherwise use defaults
                error_code = tool_result.error_code
                error_message = tool_result.error
            tool_event = BaseEvent(
                event_type=ExecutionEventType.TOOL_ERROR,
                author=state.current_agent.name,
                action=action_copy,
                error_code=error_code,
                error_message=error_message,
            )
            yield tool_event

    async def _handle_agent_transition(
        self, state: RunnerState, event: BaseEvent, current_context: InteractionContext
    ) -> tuple[Agent | DelegateAgent | None, InteractionContext, BaseEvent | None]:
        """Handle agent call/end transitions.

        Returns (new_agent, new_context, agent_start_event) where agent_start_event is the
        runner-created AGENT_START event when an AGENT_CALL was handled, else None.
        """
        new_interaction_id = InteractionContext.generate_interaction_id()
        agent_start_event: BaseEvent | None = None

        if event.event_type == ExecutionEventType.AGENT_CALL:
            new_agent = next(
                (agent for agent in state.available_agents if agent.name == event.action.name), None
            )
            if new_agent is not None:
                # Create the AGENT_START that represents the called agent receiving its task.
                # author = called agent so context managers can identify the called agent's start.
                # Task is stored in content (mirroring USER_INPUT), not in action.parameters.
                task_text = (
                    json.dumps(event.action.parameters)
                    if event.action.parameters
                    else (event.action.message or "")
                    if event.action and event.action.message
                    else " ".join(p.text for p in event.content if p.text)
                    if event.content
                    else ""
                )
                # Fall back to the parent's current user input when the LLM omits the task.
                if not task_text and current_context.agent_input is not None:
                    inp = current_context.agent_input
                    task_text = " ".join(p.text for p in (inp.content or []) if p.text)
                    if not task_text:
                        params = getattr(getattr(inp, "action", None), "parameters", None) or {}
                        task_text = params.get("task", "") or params.get("user_request", "") or ""
                agent_start_event = BaseEvent(
                    event_type=ExecutionEventType.AGENT_START,
                    author=new_agent.name,
                    content=[Part(text=task_text)],
                    action=AgentAction(
                        name=new_agent.name,
                        parameters={"task": task_text} if task_text else {},
                        thought=None,
                        message=None,
                    ),
                    interaction_id=new_interaction_id,
                    turn_id=state.turn_id,
                )
                state.current_agent = new_agent
                state.interaction_id = new_interaction_id
                await self._refresh_state(state)
        elif event.event_type == ExecutionEventType.AGENT_START:
            new_agent = next(
                (agent for agent in state.available_agents if agent.name == event.action.name), None
            )
        elif event.event_type == ExecutionEventType.AGENT_END:
            await self.conversation_manager.pop_agent_from_stack(
                state.application_name, state.user_id, state.conversation_id
            )

            stack_entry = await self.conversation_manager.get_last_agent_stack(
                state.application_name, state.user_id, state.conversation_id
            )

            new_agent = None
            if stack_entry:
                new_agent = next(
                    (
                        agent
                        for agent in state.available_agents
                        if agent.name == stack_entry.agent_name
                    ),
                    state.entrypoint_agent,
                )
                new_interaction_id = stack_entry.interaction_id or new_interaction_id
        else:
            raise ValueError(f"Unexpected event type {event.event_type} for agent transition.")

        if new_agent is None:
            return None, current_context, None

        # For AGENT_CALL, state was already updated above; update for other event types here
        if event.event_type != ExecutionEventType.AGENT_CALL:
            state.current_agent = new_agent
            state.interaction_id = new_interaction_id
            await self._refresh_state(state)

        stack_entry = await self.conversation_manager.get_last_agent_stack(
            state.application_name, state.user_id, state.conversation_id
        )

        context_event = agent_start_event if agent_start_event is not None else event
        new_context = ContextBuilder.create_context(state, context_event, stack_entry)

        if event.event_type in (ExecutionEventType.AGENT_CALL, ExecutionEventType.AGENT_START):
            await self.conversation_manager.add_agent_to_stack(
                state.application_name,
                state.user_id,
                state.conversation_id,
                agent_name=new_agent.name,
                interaction_id=new_context.interaction_id,
                turn_id=state.turn_id,
            )

        return new_agent, new_context, agent_start_event

    async def _apply_agent_hooks(
        self,
        hooks: list[FunctionHook],
        state: RunnerState,
        context: InteractionContext,
        agent: Agent | DelegateAgent,
    ) -> AsyncGenerator[AgentHookExecution, None]:
        """Run agent hooks and yield each execution result."""
        async for hook_exec in self.run_agent_transition_hooks(
            hooks=hooks, context=context, agent=agent, state=state
        ):
            yield hook_exec

    async def _refresh_state(self, state: RunnerState) -> None:
        """Refresh conversation info in state."""
        state.conversation_info = await self.conversation_manager.get_conversation(
            state.application_name, state.user_id, state.conversation_id
        )

    async def _add_event(
        self, state: RunnerState, event: BaseEvent, context: InteractionContext | None
    ) -> None:
        """Add event to conversation and interaction history."""
        event = self._ensure_event_identifiers(state=state, event=event, context=context)
        event.metadata.update(state.metadata)
        await self.conversation_manager.add_conversation_event(
            state.application_name, state.user_id, state.conversation_id, event
        )
        # Add event also to interaction history if context is provided
        if context is not None:
            context.interaction_history.append(event)

    @staticmethod
    async def _collect_hook_results(
        hook: FunctionHook,
        fallback_error_msg: str,
        **kwargs: Any,
    ) -> AsyncGenerator[HookResult, None]:
        """Run one hook and yield all results (is_update partials then final).
        If the hook never yields a final result, synthesises an error HookResult."""
        has_final = False
        async for result in hook.run(**kwargs):
            yield result
            if not result.is_update:
                has_final = True
        if not has_final:
            yield HookResult(
                success=False,
                error=HookError(error_code=404, error_message=fallback_error_msg),
                name=hook.name,
            )

    @staticmethod
    async def _drain_listener_queue(
        listener_hooks: list[FunctionHook],
        **kwargs: Any,
    ) -> AsyncGenerator[HookResult, None]:
        """Run listener hooks concurrently via a queue and yield every HookResult."""
        queue: asyncio.Queue = asyncio.Queue()
        tasks = [
            asyncio.create_task(h.drain_to_queue(queue=queue, **kwargs)) for h in listener_hooks
        ]
        pending = len(tasks)
        while pending > 0:
            item = await queue.get()
            if not item.is_update:
                pending -= 1
            yield item
        await asyncio.gather(*tasks, return_exceptions=True)

    async def run_agent_transition_hooks(
        self,
        hooks: list[FunctionHook],
        context: InteractionContext,
        agent: BaseAgent,
        state: RunnerState,
    ) -> AsyncGenerator[AgentHookExecution, None]:
        break_loop_response = (
            None  # Overwrite in case more hooks break the execution only one will be used
        )
        if hooks:
            updater_hooks = [hook for hook in hooks if hook.type == HookType.UPDATER]
            # Run updater hooks sequentially
            context = copy.deepcopy(context)
            for hook in updater_hooks:
                event = BaseEvent(
                    event_type=ExecutionEventType.HOOK_START,
                    author=agent.name,
                    metadata={"hook_name": hook.name},
                    interaction_id=context.interaction_id,
                    turn_id=context.turn_id,
                )
                await self._add_event(state, event, context=context)
                yield AgentHookExecution(event=event, context=context, break_execution=False)

                # All updater hooks are now async generators
                async for result in self._collect_hook_results(
                    hook,
                    f"Updater hook {hook.name} did not return a result.",
                    context=copy.deepcopy(context),
                    agent=agent,
                ):
                    if result.is_update:
                        hook_event = self.create_hook_event(
                            result, author=agent.name, context=context
                        )
                        await self._add_event(state, hook_event, context=context)
                        yield AgentHookExecution(
                            event=hook_event,
                            context=context,
                            break_execution=False,
                        )
                    else:
                        hook_result = result  # AgentHookResult (final)
                if hook_result is None:
                    # Generator yielded nothing useful; treat as failure
                    hook_result = HookResult(
                        new_context=context,
                        emitted_content=None,
                        success=False,
                        error=HookError(
                            error_code=404,
                            error_message=f"Updater hook {hook.name} did not return a result.",
                        ),
                        name=hook.name,
                    )

                if hook_result.break_execution:
                    break_loop_response = self.break_loop_response_event(
                        hook_result, author=agent.name
                    )
                # Skip updating context if hooks fails
                # TODO: LOG ERROR?
                new_context = hook_result.new_context if hook_result.success else context
                hook_end_event = self.create_hook_event(
                    hook_result, author=agent.name, context=context
                )
                await self._add_event(state, hook_end_event, context=context)
                yield AgentHookExecution(
                    event=hook_end_event,
                    context=new_context,
                    break_execution=hook_result.break_execution,
                )

                context = new_context  # update context for next updater hook
            # RUN LISTENER HOOKS CONCURRENTLY ON THE UPDATED CONTEXT
            listener_hooks = [hook for hook in hooks if hook.type == HookType.LISTENER]

            if listener_hooks:
                for hook in listener_hooks:
                    hook_start = BaseEvent(
                        event_type=ExecutionEventType.HOOK_START,
                        author=agent.name,
                        metadata={"hook_name": hook.name},
                        interaction_id=context.interaction_id,
                        turn_id=context.turn_id,
                    )
                    await self._add_event(state, hook_start, context=context)
                    yield AgentHookExecution(
                        event=hook_start,
                        context=context,
                        break_execution=False,
                    )

                async for item in self._drain_listener_queue(
                    listener_hooks, context=copy.deepcopy(context), agent=agent
                ):
                    if item.break_execution and not item.is_update:
                        break_loop_response = self.break_loop_response_event(
                            item, author=agent.name
                        )
                    hook_event = self.create_hook_event(item, author=agent.name, context=context)
                    await self._add_event(state, hook_event, context=context)
                    yield AgentHookExecution(
                        event=hook_event,
                        context=context,
                        break_execution=item.break_execution and not item.is_update,
                    )

        if break_loop_response:
            break_loop_response.turn_id = context.turn_id
            await self._add_event(state, break_loop_response, context=context)
            yield AgentHookExecution(
                event=break_loop_response,
                context=context,
                break_execution=True,
            )

    async def run_on_event_hooks(
        self,
        hooks: list[FunctionHook],
        event: BaseEvent,
        context: InteractionContext | None,
        state: RunnerState,
        agent_name: str = "runner",
    ) -> AsyncGenerator[OnEventHookExecution, None]:
        current_event = event

        hooks = [h for h in hooks if event.event_type in h.on_event_triggers]
        if not hooks:
            return

        def _hook_start(hook_name: str) -> BaseEvent:
            return BaseEvent(
                event_type=ExecutionEventType.HOOK_START,
                author=agent_name,
                metadata={"hook_name": hook_name},
                interaction_id=context.interaction_id if context else current_event.interaction_id,
                turn_id=context.turn_id if context else current_event.turn_id,
            )

        def _make_hook_event(hook_result: HookResult) -> BaseEvent:
            return self.create_hook_event(
                hook_result,
                author=agent_name,
                context=context,
                interaction_id=current_event.interaction_id,
                turn_id=current_event.turn_id,
            )

        updater_hooks = [h for h in hooks if (h.type == HookType.UPDATER)]
        for hook in updater_hooks:
            hook_start = _hook_start(hook.name)
            await self._add_event(state, hook_start, context=context)
            yield OnEventHookExecution(
                hook_event=hook_start,
                current_event=current_event,
            )
            async for result in self._collect_hook_results(
                hook,
                f"Updater on_agent_event hook {hook.name} did not return a result.",
                event=current_event,
                context=context,
            ):
                if result.is_update:
                    hook_event = _make_hook_event(result)
                    await self._add_event(state, hook_event, context=context)
                    yield OnEventHookExecution(
                        hook_event=hook_event,
                        current_event=current_event,
                    )
                else:
                    if result.break_execution:
                        break_response = self.break_loop_response_event(result, author=agent_name)
                        break_response.turn_id = current_event.turn_id
                        break_response.interaction_id = current_event.interaction_id
                        await self._add_event(state, break_response, context=context)
                        yield OnEventHookExecution(
                            hook_event=break_response,
                            current_event=current_event,
                            break_execution=True,
                        )
                        return
                    if result.success and result.modified_event is not None:
                        current_event = result.modified_event
                    hook_event = _make_hook_event(result)
                    await self._add_event(state, hook_event, context=context)
                    yield OnEventHookExecution(
                        hook_event=hook_event,
                        current_event=current_event,
                    )

        listener_hooks = [h for h in hooks if h.type == HookType.LISTENER]
        if listener_hooks:
            for hook in listener_hooks:
                hook_start = _hook_start(hook.name)
                await self._add_event(state, hook_start, context=context)
                yield OnEventHookExecution(
                    hook_event=hook_start,
                    current_event=current_event,
                )

            break_response: BaseEvent | None = None
            async for item in self._drain_listener_queue(
                listener_hooks, event=current_event, context=context
            ):
                if item.break_execution and break_response is None:
                    br = self.break_loop_response_event(item, author=agent_name)
                    br.turn_id = current_event.turn_id
                    br.interaction_id = current_event.interaction_id
                    break_response = br
                hook_event = _make_hook_event(item)
                await self._add_event(state, hook_event, context=context)
                yield OnEventHookExecution(
                    hook_event=hook_event,
                    current_event=current_event,
                )

            if break_response is not None:
                await self._add_event(state, break_response, context=context)
                yield OnEventHookExecution(
                    hook_event=break_response,
                    current_event=current_event,
                    break_execution=True,
                )

    async def run_tool_pre_hooks(
        self,
        tool: FunctionTool | DelegateTool,
        tool_args: dict,
        context: InteractionContext,
        state: RunnerState,
    ) -> AsyncGenerator[tuple[BaseEvent, dict], None]:
        # RUN UPDATER HOOKS SEQUENTIALLY
        updater_hooks: list[FunctionHook] = [
            hook for hook in tool.pre_hooks if hook.type == HookType.UPDATER
        ]
        tool_args = {
            k: copy.deepcopy(v) if k not in NO_COPY_KEYS else v for k, v in tool_args.items()
        }
        for hook in updater_hooks:
            # add start event
            hook_start = BaseEvent(
                event_type=ExecutionEventType.HOOK_START,
                author=state.current_agent.name,
                metadata={"hook_name": hook.name},
                interaction_id=context.interaction_id,
            )
            await self._add_event(state, hook_start, context=context)
            yield hook_start, tool_args
            async for result in self._collect_hook_results(
                hook,
                f"Updater Tool pre-hook {hook.name} did not return a result.",
                tool=tool,
                tool_args=copy.deepcopy(tool_args),
            ):
                if result.is_update:
                    hook_event = self.create_hook_event(
                        result, author=state.current_agent.name, context=context
                    )
                    await self._add_event(state, hook_event, context=context)
                    yield hook_event, tool_args
                else:
                    tool_args = (
                        result.new_tool_args
                        if result.success and result.new_tool_args is not None
                        else tool_args
                    )
                    hook_event = self.create_hook_event(
                        result, author=state.current_agent.name, context=context
                    )
                    await self._add_event(state, hook_event, context=context)
                    yield hook_event, tool_args
                    if result.new_tool_args is not None and "state" in result.new_tool_args:
                        context.state.clear()
                        context.state.update(result.new_tool_args.get("state", {}))
        # RUN LISTENER HOOKS CONCURRENTLY ON THE NEW KWARGS
        listener_hooks: list[FunctionHook] = [
            hook for hook in tool.pre_hooks if hook.type == HookType.LISTENER
        ]
        if listener_hooks:
            for hook in listener_hooks:
                hook_start = BaseEvent(
                    event_type=ExecutionEventType.HOOK_START,
                    author=state.current_agent.name,
                    metadata={"hook_name": hook.name},
                    interaction_id=context.interaction_id,
                )
                await self._add_event(state, hook_start, context=context)
                yield hook_start, tool_args
            async for item in self._drain_listener_queue(
                listener_hooks, tool=tool, tool_args=copy.deepcopy(tool_args)
            ):
                hook_event = self.create_hook_event(
                    item, author=state.current_agent.name, context=context
                )
                await self._add_event(state, hook_event, context=context)
                yield hook_event, tool_args

    async def run_tool_post_hooks(
        self,
        tool: FunctionTool | DelegateTool,
        tool_result: ToolResult,
        context: InteractionContext,
        state: RunnerState,
    ) -> AsyncGenerator[tuple[BaseEvent, ToolResult], None]:
        # RUN UPDATER HOOKS SEQUENTIALLY
        tool_result = copy.deepcopy(tool_result)
        updater_hooks: list[FunctionHook] = [
            hook for hook in tool.post_hooks if hook.type == HookType.UPDATER
        ]
        for hook in updater_hooks:
            hook_start = BaseEvent(
                event_type=ExecutionEventType.HOOK_START,
                author=state.current_agent.name,
                metadata={"hook_name": hook.name},
                interaction_id=context.interaction_id,
            )
            await self._add_event(state, hook_start, context=context)
            yield hook_start, tool_result
            async for result in self._collect_hook_results(
                hook,
                f"Updater Tool post-hook {hook.name} did not return a result.",
                tool=tool,
                result=copy.deepcopy(tool_result),
            ):
                if result.is_update:
                    hook_event = self.create_hook_event(
                        result, author=state.current_agent.name, context=context
                    )
                    await self._add_event(state, hook_event, context=context)
                    yield hook_event, tool_result
                else:
                    tool_result = (
                        result.new_result
                        if result.success and result.new_result is not None
                        else tool_result
                    )
                    hook_event = self.create_hook_event(
                        result, author=state.current_agent.name, context=context
                    )
                    await self._add_event(state, hook_event, context=context)
                    yield hook_event, tool_result
                    if result.new_result is not None and result.new_result.state is not None:
                        context.state.clear()
                        context.state.update(result.new_result.state)

        # RUN LISTENER HOOKS CONCURRENTLY ON THE NEW RESULT
        listener_hooks: list[FunctionHook] = [
            hook for hook in tool.post_hooks if hook.type == HookType.LISTENER
        ]
        if listener_hooks:
            for hook in listener_hooks:
                hook_start = BaseEvent(
                    event_type=ExecutionEventType.HOOK_START,
                    author=state.current_agent.name,
                    metadata={"hook_name": hook.name},
                    interaction_id=context.interaction_id,
                )
                await self._add_event(state, hook_start, context=context)
                yield hook_start, tool_result
            async for item in self._drain_listener_queue(
                listener_hooks, tool=tool, result=copy.deepcopy(tool_result)
            ):
                hook_event = self.create_hook_event(
                    item, author=state.current_agent.name, context=context
                )
                await self._add_event(state, hook_event, context=context)
                yield hook_event, tool_result

    @staticmethod
    def create_hook_event(
        hook_result: HookResult,
        author: str,
        context: InteractionContext | None,
        interaction_id: str | None = None,
        turn_id: str | None = None,
    ) -> BaseEvent:
        _interaction_id = context.interaction_id if context else interaction_id
        _turn_id = context.turn_id if context else turn_id
        if hook_result.is_update:
            event = BaseEvent(
                event_type=ExecutionEventType.HOOK_UPDATE,
                author=author,
                metadata={"hook_name": hook_result.name} if hook_result.name else {},
                content=hook_result.emitted_content,
                interaction_id=_interaction_id,
                turn_id=_turn_id,
            )
        elif hook_result.success:
            event = BaseEvent(
                event_type=ExecutionEventType.HOOK_END,
                author=author,
                metadata={"hook_name": hook_result.name},
                content=hook_result.emitted_content,
                interaction_id=_interaction_id,
                turn_id=_turn_id,
            )
        else:
            if hook_result.error:
                error_code = hook_result.error.error_code or "unknown_error"
                error_message = (
                    hook_result.error.error_message or "Unknown error occurred while running hook."
                )
            else:
                error_code = "unknown_error"
                error_message = "Unknown error occurred while running hook."
            event = BaseEvent(
                event_type=ExecutionEventType.HOOK_ERROR,
                author=author,
                error_code=str(error_code),
                error_message=error_message,
                metadata={"hook_name": hook_result.name},
                interaction_id=_interaction_id,
                turn_id=_turn_id,
            )
        return event

    @staticmethod
    def break_loop_response_event(hook_result: HookResult, author: str) -> BaseEvent:
        response_content = None
        if hook_result.emitted_content:  # Check reason of guardrail that didn't pass first
            for part in hook_result.emitted_content:
                if (
                    part.guardrail_result
                    and (not part.guardrail_result.passed)
                    and not part.guardrail_result.error_occurred
                    and part.guardrail_result.reason
                ):
                    response_content = part.guardrail_result.reason
                    break
            if (
                response_content is None
            ):  # If no guardrail reason, check if there is a text to return
                for part in hook_result.emitted_content:
                    if part.text:
                        response_content = part.text
                        break
            if response_content is None:  # If there is still no text, return default message
                response_content = f"Execution stopped by hook {hook_result.name}"
        response_event = BaseEvent(
            event_type=ExecutionEventType.RESPONSE,
            content=[Part(text=response_content)],
            author=author,
            action=BaseAction(name=hook_result.name, parameters={"break_execution": True}),
        )
        return response_event
