"""Transport abstraction for runner-to-runner communication.

A RunnerTransport is the channel between two runners. The local runner
delegates agent execution to a remote runner via a transport. Events flow
back from the remote runner; results (TOOL_END, LLM_END) can be sent back
via send_result() for back-delegated steps.

Custom transport types self-register by subclassing ``RunnerTransport`` and
declaring a ``type`` class variable::

    from domyn_agents.runner.transport import RunnerTransport

    class MyTransport(RunnerTransport):
        type = "my_transport"

        @classmethod
        def from_config(cls, config: dict) -> "MyTransport":
            return cls(url=config["url"])

        async def execute(self, agent_name, context):
            ...

        async def send_result(self, event):
            ...

As soon as the class is defined (i.e. the module containing it is imported)
``my_transport`` becomes available as a ``transport.type`` value in YAML
configs.  No manual registration call is needed.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from typing import ClassVar

from domyn_agents.core import BaseEvent
from domyn_agents.core.context import InteractionContext


class RunnerTransport(ABC):
    """Bidirectional channel between a local runner and a remote runner.

    Subclasses declare a ``type`` class variable (a plain string) and
    implement ``from_config`` to be discoverable by ``build_transport``.
    """

    # Subclasses set this to the string that appears as ``transport.type``
    # in YAML / dict configs.  The base class has no type so it is never
    # instantiated directly from config.
    type: ClassVar[str | None] = None

    _registry: ClassVar[dict[str, type[RunnerTransport]]] = {}

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        tag = getattr(cls, "type", None)
        if tag is not None:
            RunnerTransport._registry[tag] = cls

    @classmethod
    def from_config(cls, config: dict) -> RunnerTransport:
        """Build an instance from a raw config dict.

        Must be overridden by concrete subclasses.
        """
        raise NotImplementedError(f"from_config not implemented for {cls.__name__}")

    @abstractmethod
    def execute(
        self,
        agent_name: str,
        context: InteractionContext,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Stream events from the remote runner for the given agent."""
        ...

    @abstractmethod
    async def send_result(self, event: BaseEvent) -> None:
        """Send a result event (TOOL_END, LLM_END) back to the remote runner."""
        ...


def register_transport(type_name: str, factory: type[RunnerTransport]) -> None:
    """Register a transport class under *type_name*.

    Prefer declaring ``type = "my_type"`` on the subclass — that self-registers
    automatically.  Use this only when you cannot modify the class (e.g. a
    third-party transport).
    """
    RunnerTransport._registry[type_name] = factory


def build_transport(config: dict) -> RunnerTransport:
    """Build a ``RunnerTransport`` from a raw config dict.

    Resolves ``config["type"]`` (default ``"websocket"``) against the
    auto-populated ``RunnerTransport._registry``.  Any subclass that declares
    a ``type`` class variable is available here as soon as its module has been
    imported.

    Raises ``ValueError`` for unknown types.
    """
    # Ensure built-in transports are imported so they self-register.
    import domyn_agents.runner.sse_transport
    import domyn_agents.runner.websocket_transport  # noqa: F401

    transport_type: str = config.get("type", "websocket")
    cls = RunnerTransport._registry.get(transport_type)
    if cls is None:
        raise ValueError(
            f"Unknown delegate transport type: {transport_type!r}. "
            "Define a RunnerTransport subclass with type='{transport_type}' "
            "and ensure its module is imported before loading the config."
        )
    return cls.from_config(config)
