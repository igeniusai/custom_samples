import os
from copy import deepcopy
from functools import wraps
from typing import Any

from opentelemetry.trace import Tracer

# -------------------------------
# Controllo se OpenTelemetry è installato
# -------------------------------
try:
    from opentelemetry import trace
    from opentelemetry.propagate import inject

    OPENTELEMETRY_AVAILABLE = True
except ImportError:
    OPENTELEMETRY_AVAILABLE = False

# -------------------------------
# Flag enable tracing
# -------------------------------
ENABLE_TRACING = os.getenv("ENABLE_TRACING", "true").lower() in ("true", "1", "yes")


# -------------------------------
# Dummy tracer
# -------------------------------
class DummySpan:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False

    def set_attribute(self, key, value):
        pass

    def record_exception(self, exc):
        pass

    def set_status(self, status):
        pass


class DummyTracer:
    def start_as_current_span(self, name):
        return DummySpan()


def get_safe_tracer(name: str) -> Tracer | DummyTracer:
    if OPENTELEMETRY_AVAILABLE and ENABLE_TRACING:
        return trace.get_tracer(name)
    else:
        return DummyTracer()


# -------------------------------
# Decorator per instrumentation opzionale
# -------------------------------
def instrumented(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        tracer = get_safe_tracer(func.__module__)
        span = None
        if OPENTELEMETRY_AVAILABLE and ENABLE_TRACING:
            span = trace.get_current_span()
            # if no valid span is active we can start a new one
            if span is None or not span.get_span_context().is_valid:
                return func(*args, **kwargs)

        with tracer.start_as_current_span(func.__name__):
            return func(*args, **kwargs)

    return wrapper


def inject_trace_headers(headers: dict[str, Any]) -> dict[str, Any]:
    if OPENTELEMETRY_AVAILABLE and ENABLE_TRACING:
        inject(headers)
    return headers


def add_trace_headers(headers: dict[str, Any]) -> dict[str, Any]:
    _h = deepcopy(headers)
    if OPENTELEMETRY_AVAILABLE and ENABLE_TRACING:
        inject(_h)
    return _h
