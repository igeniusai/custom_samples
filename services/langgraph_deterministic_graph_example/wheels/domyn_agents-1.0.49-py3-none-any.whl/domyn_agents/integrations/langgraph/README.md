# LangGraph integration

Connect a LangGraph compiled graph to the Domyn platform with a single command:

```bash
domyn expose <module>:<symbol> \
    --channel-id <channel_id> \
    --space-id  <space_id> \
    --base-url  <base_url>
```

`domyn expose` opens an outbound WebSocket to the relay, waits for `AGENT_START`
events from the platform, runs your graph, and streams trace events
(`LLM_START` / `TOOL_START` / `TOOL_END` / …) back as Domyn `BaseEvent`s.

## Install

```bash
pip install "domyn-agents[langgraph]"
```

The `langgraph` extra pulls in `langchain-core` and `langgraph` alongside the
core `domyn-agents` package.

## Quickstart — a minimal graph

`ws_react_agent.py`:

```python
from typing import Any, TypedDict

from langchain_core.language_models.fake import FakeListLLM
from langchain_core.tools import tool
from langgraph.graph import END, START, StateGraph

from domyn_agents.integrations.langgraph.utils import input_mapper


class GraphState(TypedDict):
    question: str
    answer: str


@tool
def calculator(expression: str) -> str:
    """Evaluate a simple arithmetic expression like '2+2'."""
    return str(eval(expression, {"__builtins__": {}}, {}))


_llm = FakeListLLM(responses=["It's probably 42."])


def answer(state: GraphState) -> GraphState:
    q = state["question"]
    if any(op in q for op in "+-*/"):
        return {"question": q, "answer": calculator.invoke({"expression": q})}
    return {"question": q, "answer": str(_llm.invoke(q))}


# The platform sends AGENT_START with action.parameters = {"task": "...",
# "user_request": "..."}; @input_mapper translates that dict into whatever
# input shape your compiled graph expects (here: GraphState).
@input_mapper(lambda d: GraphState(question=d.get("task", ""), answer=""))
def build_graph() -> Any:
    builder = StateGraph(GraphState)
    builder.add_node("answer", answer)
    builder.add_edge(START, "answer")
    builder.add_edge("answer", END)
    return builder.compile()


graph = build_graph()
```

Expose it:

```bash
DOMYN_API_KEY=domyn_*** domyn expose ws_react_agent:graph \
    --channel-id <channel_id> \
    --space-id  <space_id> \
    --base-url  <base_url>
```

## Anatomy of the entrypoint

The `MODULE:SYMBOL` argument resolves the runnable two ways:

- `path/to/file.py:symbol` — a file path, loaded ad-hoc.
- `module.path:symbol` — a regular Python import (run from the directory
  containing the module, or with the module on `PYTHONPATH`).

`SYMBOL` may be either a compiled graph **instance** (e.g. `graph` above) or a
zero-arg **factory** (e.g. `build_graph`). For factories, the loader calls
them once at startup. The `@input_mapper` decorator works on either form —
the mapper is recorded both on the factory and on the instance it produces,
so both `:build_graph` and `:graph` resolve it.

In the example above, `ws_react_agent:graph` means: from the file
`ws_react_agent.py`, take the `graph` variable.

## CLI flags

| Flag | What it is |
| --- | --- |
| `--channel-id` | Issued by the platform when you provision a worker. It opens a direct, persistent communication tunnel from your agent process to the platform. |
| `--space-id` | The platform space the agent serves. Specific to the platform deployment you're connecting to. You can find it in the url when opening the platform, after `spaces/` e.g.: `https://example.crystal.io/console/{organization-id}/spaces/{space-id}/agents` |
| `--base-url` | The platform's API host (e.g. `api.devopsdev.crystal.io`). Specific to the platform deployment you're connecting to. The scheme defaults to `https://` if omitted. |
| `--max-concurrency` | Optional. Caps in-flight invocations on this worker (default `8`). |

`DOMYN_API_KEY` must be set in the environment.

## Lifecycle in one paragraph

1. The CLI imports your entrypoint, picks up any `@input_mapper`, and opens a
   WebSocket to `wss://<base-url>/api/relay/v1/ws`.
2. On each `AGENT_START` from the platform, the runtime applies the input
   mapper (if any) to `action.parameters` and calls `graph.ainvoke(...)`.
3. A langchain callback handler attached to the run emits one `BaseEvent`
   per LangGraph callback (`LLM_START`/`LLM_END`, `TOOL_START`/`TOOL_END`,
   etc.); they're streamed back over the same WebSocket.
4. When `ainvoke` returns, the runtime sends a terminal `AGENT_END` carrying
   the result; on exception it sends `ERROR_OCCURRED`.
5. The connection auto-reconnects on drops (full-jitter exponential backoff).

## Platform tools (optional)

Tools hosted on the Domyn platform can be referenced from a node and the
runtime will round-trip their execution over the WebSocket: a `TOOL_START`
goes out, the platform executes the tool, a `TOOL_END` comes back, and the
node resumes. See `examples/ws_graph.py` for an end-to-end example using
`get_platform_tools`.
