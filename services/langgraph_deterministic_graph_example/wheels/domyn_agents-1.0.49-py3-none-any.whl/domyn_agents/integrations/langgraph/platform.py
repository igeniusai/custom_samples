"""Platform tool integration: lets a langgraph runnable call tools hosted on the Domyn platform.

Tools fetched here look like ordinary langchain tools to the graph, but their
execution is delegated: ``_arun`` ships the call over the Runtime's WebSocket
as a TOOL_START BaseEvent and suspends until a matching TOOL_END / TOOL_ERROR
arrives back, keyed by ``ToolAction.call_id``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

import httpx
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field, PrivateAttr, create_model

from domyn_agents.logger import get_logger

if TYPE_CHECKING:
    from domyn_agents.integrations.langgraph.runtime import Runtime

logger = get_logger()

# Marker placed on every PlatformTool's ``tags`` list. The langchain callback
# handler reads this to suppress local trace emission for platform tools — the
# Runtime already sends TOOL_START / TOOL_END for these calls itself, so the
# in-process callbacks would produce duplicates.
PLATFORM_TOOL_TAG = "domyn:platform_tool"

_TYPE_MAP: dict[str, type] = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "list": list,
    "dict": dict,
}


def _fetch_tool_definitions(api_key: str, space_id: str, base_url: str) -> list[dict[str, Any]]:
    # TODO: use the platform sdk once it's available, instead of calling the API directly. For now we want to avoid adding the sdk as a dependency just for this one call.
    response = httpx.post(
        f"{base_url}/api/agents-service/tool/list_from_config",
        headers={"api-key": api_key, "Content-Type": "application/json"},
        json={"space_id": space_id},
        timeout=10.0,
    )
    response.raise_for_status()
    data = response.json()
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("tools", "data", "results"):
            if key in data and isinstance(data[key], list):
                return data[key]
    raise ValueError(f"Unexpected tool list response shape: {type(data)}")


def _build_args_schema(tool_name: str, parameters: list[dict[str, Any]]) -> type[BaseModel]:
    """Build a Pydantic args model from a platform tool's parameter spec.

    Optionality is inferred from two keys (either may appear):
      - ``default``: when present, the field is optional with that value;
      - ``is_required``: when explicitly ``False``, the field is optional and
        defaults to ``None`` (the annotation becomes ``T | None``).

    Fields with neither key are required.
    """
    fields: dict[str, Any] = {}
    for p in parameters:
        name = p["name"]
        py_type = _TYPE_MAP.get(p.get("type", "str"), str)
        description = p.get("description", "")
        if "default" in p:
            fields[name] = (py_type, Field(default=p["default"], description=description))
        elif p.get("is_required") is False:
            fields[name] = (py_type | None, Field(default=None, description=description))
        else:
            fields[name] = (py_type, Field(..., description=description))
    return create_model(f"{tool_name}_args", **fields)


class PlatformRelay:
    """Bridge between PlatformTool calls and the active Runtime's WebSocket.

    A user's module typically calls :func:`get_platform_tools` at import time
    (before the WebSocket exists), which binds tools to a shared default relay.
    The Runtime later binds itself to that relay on startup; calls before
    binding raise.
    """

    def __init__(self) -> None:
        self._runtime: Runtime | None = None

    def bind(self, runtime: Runtime) -> None:
        self._runtime = runtime

    def unbind(self, runtime: Runtime) -> None:
        if self._runtime is runtime:
            self._runtime = None

    async def call_platform_tool(self, name: str, kwargs: dict[str, Any]) -> Any:
        if self._runtime is None:
            raise RuntimeError(f"PlatformRelay is not bound to a Runtime; cannot invoke {name!r}")
        return await self._runtime.call_platform_tool(name, kwargs)


_default_relay = PlatformRelay()


def get_default_relay() -> PlatformRelay:
    return _default_relay


class PlatformTool(BaseTool):
    name: str
    description: str
    args_schema: type[BaseModel]
    _relay: PlatformRelay = PrivateAttr()

    def __init__(self, relay: PlatformRelay, **kwargs: Any) -> None:
        tags = list(kwargs.pop("tags", None) or [])
        if PLATFORM_TOOL_TAG not in tags:
            tags.append(PLATFORM_TOOL_TAG)
        super().__init__(tags=tags, **kwargs)
        self._relay = relay

    def _run(self, **kwargs: Any) -> Any:
        raise NotImplementedError("Platform tools must be invoked asynchronously")

    async def _arun(self, **kwargs: Any) -> Any:
        return await self._relay.call_platform_tool(self.name, kwargs)


class PlatformToolRegistry:
    def __init__(self, tool_defs: list[dict[str, Any]], relay: PlatformRelay) -> None:
        self._registry: dict[str, PlatformTool] = {}
        for t in tool_defs:
            params = t.get("parameters")
            if params is None:
                continue
            schema = _build_args_schema(t["name"], params)
            self._registry[t["name"]] = PlatformTool(
                relay=relay,
                name=t["name"],
                description=t.get("description", ""),
                args_schema=schema,
            )

    def get_tool(self, name: str) -> PlatformTool:
        if name not in self._registry:
            raise KeyError(f"Platform tool {name!r} not found. Available: {list(self._registry)}")
        return self._registry[name]

    def list_tools(self) -> list[str]:
        return list(self._registry)


def get_platform_tools(
    api_key: str | None = None,
    space_id: str | None = None,
    base_url: str | None = None,
    relay: PlatformRelay | None = None,
) -> PlatformToolRegistry:
    """Fetch the platform's tool catalog and return a registry of PlatformTool wrappers.

    Reads ``DOMYN_API_KEY``, ``DOMYN_SPACE_ID``, ``DOMYN_BASE_URL`` from the
    environment when args are omitted. If no relay is provided, the module-level
    default is used — the same one the Runtime binds on startup.
    """
    api_key = api_key or os.environ.get("DOMYN_API_KEY")
    space_id = space_id or os.environ.get("DOMYN_SPACE_ID")
    base_url = base_url or os.environ.get("DOMYN_BASE_URL", "https://api.devopsdev.crystal.io")
    if not api_key:
        raise RuntimeError("DOMYN_API_KEY is required to fetch platform tools")
    if not space_id:
        raise RuntimeError("DOMYN_SPACE_ID is required to fetch platform tools")
    if not base_url.startswith(("http://", "https://")):
        base_url = f"https://{base_url}"
    if base_url.endswith("/"):
        base_url = base_url[:-1]

    relay = relay or _default_relay

    defs = _fetch_tool_definitions(api_key, space_id, base_url)
    registry = PlatformToolRegistry(defs, relay=relay)
    logger.info("loaded %d platform tools: %s", len(registry.list_tools()), registry.list_tools())
    return registry
