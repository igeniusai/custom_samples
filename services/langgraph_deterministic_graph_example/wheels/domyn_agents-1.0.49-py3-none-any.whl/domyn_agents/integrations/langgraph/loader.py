"""Resolve a ``module:symbol`` or ``path/to/file.py:symbol`` entrypoint to a runnable."""

from __future__ import annotations

import importlib
import importlib.util
import sys
from pathlib import Path
from typing import Any

from domyn_agents.integrations.langgraph.utils import InputMapper, get_input_mapper


def load_runnable(entrypoint: str) -> tuple[Any, InputMapper | None]:
    """Load a LangGraph compiled graph from a ``module:symbol`` or ``file.py:symbol`` entrypoint.

    The symbol may be a compiled graph instance or a zero-arg factory that
    returns one. The returned object must have an ``ainvoke(input, config)`` method.

    If the symbol (or, for factories, the resulting runnable) was decorated
    with :func:`domyn_agents.integrations.langgraph.utils.input_mapper`, the
    mapper is returned alongside the runnable so the runtime can translate
    inbound invoke payloads into the graph's expected input shape.
    """
    if ":" not in entrypoint:
        raise ValueError(f"entrypoint must be 'module:symbol', got: {entrypoint!r}")

    module_part, symbol = entrypoint.rsplit(":", 1)

    if "/" in module_part or module_part.endswith(".py"):
        path = Path(module_part)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        spec = importlib.util.spec_from_file_location("_expose_runnable", path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load module from {path}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    else:
        cwd = str(Path.cwd())
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
        mod = importlib.import_module(module_part)

    symbol_obj = getattr(mod, symbol, None)
    if symbol_obj is None:
        raise AttributeError(f"Symbol {symbol!r} not found in {module_part!r}")

    mapper = get_input_mapper(symbol_obj)

    if callable(symbol_obj) and not hasattr(symbol_obj, "ainvoke"):
        runnable = symbol_obj()
    else:
        runnable = symbol_obj

    if mapper is None:
        mapper = get_input_mapper(runnable)

    if not hasattr(runnable, "ainvoke"):
        raise TypeError(
            f"{symbol!r} in {module_part!r} has no ainvoke() method — "
            "expected a compiled LangGraph or an object with ainvoke(input, config)."
        )
    return runnable, mapper
