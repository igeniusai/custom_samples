"""PlatformCallbackHandler: langchain AsyncCallbackHandler that emits BaseEvent over a caller-provided closure."""

from __future__ import annotations

import functools
import time
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from langchain_core.callbacks.base import AsyncCallbackHandler

from domyn_agents.core import BaseEvent, ExecutionEventType, Part, ToolAction
from domyn_agents.integrations.langgraph.platform import PLATFORM_TOOL_TAG
from domyn_agents.integrations.langgraph.run_state import RunRegistry, RunState
from domyn_agents.logger import get_logger

EmitFn = Callable[[BaseEvent], Awaitable[None]]
logger = get_logger()


def _safe(method: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator: ensures no exception escapes an async callback method."""

    method_name = getattr(method, "__name__", repr(method))

    @functools.wraps(method)
    async def wrapper(self: PlatformCallbackHandler, *args: Any, **kwargs: Any) -> None:
        try:
            await method(self, *args, **kwargs)
        except Exception:
            logger.warning("callback %s raised; swallowing", method_name, exc_info=True)

    return wrapper


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return str(value)


def _extract_thought_from_response(response: Any) -> str | None:
    """Mirror tool_use_thought._extract_thought for LangChain LLMResult.

    Priority (first non-empty wins):
    1. ``reasoning_content`` in additional_kwargs  — DeepSeek R1, Kimi, etc.
    2. ``thinking`` block in content list          — Anthropic extended thinking.
    3. Plain-text ``content`` when tool calls are also present — preamble text
       solicited by the system prompt (e.g. "Let me think step by step...").
    4. Synthetic fallback: human-readable tool call lines when no thought at all.
    """
    generations = (
        response.get("generations")
        if isinstance(response, dict)
        else getattr(response, "generations", None)
    )
    if not generations:
        return None

    for batch in generations:
        if not isinstance(batch, list):
            continue
        for gen in batch:
            if isinstance(gen, dict):
                continue
            message = getattr(gen, "message", None)
            if message is None:
                continue

            # 1. reasoning_content in additional_kwargs
            extra = getattr(message, "additional_kwargs", {}) or {}
            rc = extra.get("reasoning_content")
            if rc and isinstance(rc, str):
                return rc

            content = getattr(message, "content", None)
            tool_calls = getattr(message, "tool_calls", None)

            # 2. thinking block in structured content list
            if isinstance(content, list):
                for block in content:
                    block_type = block.get("type") if isinstance(block, dict) else None
                    if block_type in ("thinking", "reasoning"):
                        chunk = (
                            block.get("thinking") or block.get("reasoning") or block.get("text", "")
                        )
                        if chunk:
                            return chunk

            # 3. plain-text preamble when tool calls are present
            if tool_calls and isinstance(content, str) and content.strip():
                return content.strip()

            # 4. synthetic fallback
            if tool_calls:
                lines = []
                for tc in tool_calls:
                    name = (
                        tc.get("name", "tool")
                        if isinstance(tc, dict)
                        else getattr(tc, "name", "tool")
                    )
                    args = tc.get("args", {}) if isinstance(tc, dict) else getattr(tc, "args", {})
                    params_str = ", ".join(f"{k}={v}" for k, v in (args or {}).items())
                    lines.append(
                        f"Calling tool {name} with parameters: {params_str}"
                        if params_str
                        else f"Calling tool {name}"
                    )
                if lines:
                    return "\n".join(lines)

    return None


def _extract_llm_text(response: Any) -> str:
    """Extract plain response text from a LangChain LLMResult.

    Skips thinking/reasoning blocks — those are handled by
    ``_extract_thought_from_response``.
    """
    generations = (
        response.get("generations")
        if isinstance(response, dict)
        else getattr(response, "generations", None)
    )
    if not generations:
        return ""

    text_parts: list[str] = []

    for batch in generations:
        if not isinstance(batch, list):
            continue
        for gen in batch:
            if isinstance(gen, dict):
                if gen.get("text"):
                    text_parts.append(gen["text"])
                continue

            message = getattr(gen, "message", None)
            content = getattr(message, "content", None) if message is not None else None

            if isinstance(content, list):
                for block in content:
                    block_type = block.get("type") if isinstance(block, dict) else None
                    if block_type == "text":
                        chunk = block.get("text", "")
                        if chunk:
                            text_parts.append(chunk)
            else:
                raw_text = getattr(gen, "text", None)
                if raw_text:
                    text_parts.append(raw_text)

    return "\n".join(text_parts)


class PlatformCallbackHandler(AsyncCallbackHandler):
    """Langchain async callback handler that emits ``BaseEvent`` directly.

    Each callback maps to a single :class:`ExecutionEventType` and constructs
    the BaseEvent inline; the caller-provided ``emit`` closure ships it to
    the wire.
    """

    def __init__(
        self,
        *,
        project_id: str,  # Author in BaseEvent
        emit: EmitFn,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> None:
        super().__init__()
        self._project_id = project_id
        self._emit_fn = emit
        self._default_user_id = user_id
        self._default_session_id = session_id
        self._registry = RunRegistry()
        # Tool run_ids whose start was tagged as a platform tool. The Runtime
        # owns the wire-level TOOL_START/TOOL_END for these, so we skip
        # registry tracking and emission on both ends.
        self._platform_tool_runs: set[UUID] = set()
        # Tool-name lookup keyed by run_id, populated at on_tool_start so
        # on_tool_end can rebuild a ToolAction with the matching name.
        self._tool_names: dict[UUID, str] = {}
        # LangGraph node-name lookup: metadata is only passed to on_chain_start,
        # not on_chain_end, so we store run_id → node_name here.
        self._node_names: dict[UUID, tuple[str, dict[str, Any] | None]] = {}

    async def aclose(self) -> None:
        return None

    # ---- helpers ----

    async def _emit(self, event: BaseEvent) -> None:
        await self._emit_fn(event)

    def _resolve_session(self, metadata: dict[str, Any] | None) -> str | None:
        if metadata and metadata.get("session_id"):
            return metadata["session_id"]
        return self._default_session_id

    def _new_event(
        self,
        *,
        event_type: ExecutionEventType,
        metadata: dict[str, Any] | None = None,
        content: list[Part] | None = None,
        action: ToolAction | None = None,
        error_code: str | None = None,
        error_message: str | None = None,
    ) -> BaseEvent:
        return BaseEvent(
            event_type=event_type,
            author=self._project_id,
            event_id=str(uuid4()),
            timestamp=datetime.now(UTC).replace(tzinfo=None),
            interaction_id=self._resolve_session(metadata),
            content=content or [],
            action=action,
            error_code=error_code,
            error_message=error_message,
            conversation_id=metadata.get("conversation_id") if metadata else None,
        )

    async def _maybe_emit_response(self, state: RunState) -> None:
        """If ``state`` is the trace root, emit a terminal RESPONSE event and clean up the subtree."""
        if state.parent_run_id is not None:
            return
        # Drop the whole subtree from the registry; we no longer surface per-step snapshots.
        self._registry.pop_trajectory(state.run_id)
        if state.span_type == "llm":
            text = _extract_llm_text(state.output)
            thought = _extract_thought_from_response(state.output)
        else:
            text, thought = "", None
        if not text:
            text = _stringify(state.output)
        content: list[Part] = []
        if thought:
            content.append(Part(thought=thought))
        if text:
            content.append(Part(text=text))
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.RESPONSE,
                metadata=state.metadata,
                content=content,
            )
        )

    # ---- chain callbacks (LangGraph nodes) ----

    @_safe
    async def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        node_name = (metadata or {}).get("langgraph_node")
        if not node_name:
            return
        self._node_names[run_id] = (node_name, metadata)
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_START,
                metadata=metadata,
                content=[Part(text=f"Running node: {node_name}")],
                action=ToolAction(name=node_name, parameters=None, call_id=str(run_id)),
            )
        )

    @_safe
    async def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        entry = self._node_names.pop(run_id, None)
        if not entry:
            return
        node_name, metadata = entry
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_END,
                metadata=metadata,
                action=ToolAction(
                    name=node_name,
                    parameters=None,
                    call_id=str(run_id),
                    observation=_stringify(outputs.get("result") if isinstance(outputs, dict) and outputs.get("result") else outputs),
                ),
            )
        )

    # ---- LLM callbacks ----

    @_safe
    async def on_llm_start(
        self,
        serialized: dict[str, Any] | None,
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        self._registry.start(
            run_id=run_id,
            parent_run_id=parent_run_id,
            span_type="llm",
            start_time=time.time(),
            inputs={"prompts": prompts},
            metadata=metadata or {},
        )
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.LLM_START,
                metadata=metadata,
                content=[Part(text="Invoking LLM for next action")],
            )
        )

    @_safe
    async def on_chat_model_start(
        self,
        serialized: dict[str, Any] | None,
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        prompts = [repr(msg) for group in messages for msg in group]
        await self.on_llm_start(
            serialized,
            prompts,
            run_id=run_id,
            parent_run_id=parent_run_id,
            metadata=metadata,
            **kwargs,
        )

    @_safe
    async def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state, _ = self._registry.end(run_id=run_id, output=response, end_time=time.time())
        text = _extract_llm_text(response)
        thought = _extract_thought_from_response(response)
        content: list[Part] = []
        if thought:
            content.append(Part(thought=thought))
        content.append(Part(text=text) if text else Part(text="LLM call completed"))
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.LLM_END,
                metadata=state.metadata,
                content=content,
            )
        )
        await self._maybe_emit_response(state)

    @_safe
    async def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state, _ = self._registry.error(run_id=run_id, error=error, end_time=time.time())
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.ERROR_OCCURRED,
                metadata=state.metadata,
                error_code=type(error).__name__,
                error_message=str(error),
            )
        )
        await self._maybe_emit_response(state)

    # ---- chain callbacks ----

    @_safe
    async def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state, _ = self._registry.error(run_id=run_id, error=error, end_time=time.time())
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.ERROR_OCCURRED,
                metadata=state.metadata,
                error_code=type(error).__name__,
                error_message=str(error),
            )
        )
        await self._maybe_emit_response(state)

    # ---- tool callbacks ----

    @_safe
    async def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        tags = kwargs.get("tags") or []
        if PLATFORM_TOOL_TAG in tags:
            self._platform_tool_runs.add(run_id)
            return
        tool_name = (serialized or {}).get("name") or "tool"
        self._tool_names[run_id] = tool_name
        self._registry.start(
            run_id=run_id,
            parent_run_id=parent_run_id,
            span_type="tool",
            start_time=time.time(),
            inputs={"input": input_str},
            metadata=metadata or {},
        )
        parameters = kwargs.get("inputs") if isinstance(kwargs.get("inputs"), dict) else None
        text = f"Invoking tool: {tool_name}"
        if input_str:
            text = f"{text}\nInput: {input_str}"
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_START,
                metadata=metadata,
                content=[Part(text=text)],
                action=ToolAction(
                    name=tool_name,
                    parameters=parameters,
                    call_id=str(run_id),
                ),
            )
        )

    @_safe
    async def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if run_id in self._platform_tool_runs:
            self._platform_tool_runs.discard(run_id)
            return
        state, _ = self._registry.end(run_id=run_id, output=output, end_time=time.time())
        tool_name = self._tool_names.pop(run_id, "tool")
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_END,
                metadata=state.metadata,
                action=ToolAction(
                    name=tool_name,
                    parameters=None,
                    call_id=str(run_id),
                    observation=output,
                ),
            )
        )

    @_safe
    async def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if run_id in self._platform_tool_runs:
            self._platform_tool_runs.discard(run_id)
            return
        state, _ = self._registry.error(run_id=run_id, error=error, end_time=time.time())
        tool_name = self._tool_names.pop(run_id, "tool")
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_ERROR,
                metadata=state.metadata,
                action=ToolAction(name=tool_name, parameters=None, call_id=str(run_id)),
                error_code=type(error).__name__,
                error_message=str(error),
            )
        )

    # ---- retriever callbacks ----

    @_safe
    async def on_retriever_start(
        self,
        serialized: dict[str, Any] | None,
        query: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        retriever_name = (serialized or {}).get("name") or "retriever"
        self._tool_names[run_id] = retriever_name
        self._registry.start(
            run_id=run_id,
            parent_run_id=parent_run_id,
            span_type="retriever",
            start_time=time.time(),
            inputs={"query": query},
            metadata=metadata or {},
        )
        text = f"Invoking tool: {retriever_name}"
        if query:
            text = f"{text}\nInput: {query}"
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_START,
                metadata=metadata,
                content=[Part(text=text)],
                action=ToolAction(
                    name=retriever_name,
                    parameters={"query": query},
                    call_id=str(run_id),
                ),
            )
        )

    @_safe
    async def on_retriever_end(
        self,
        documents: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        docs_serializable = [
            {
                "page_content": getattr(d, "page_content", str(d)),
                "metadata": getattr(d, "metadata", {}),
            }
            for d in (documents or [])
        ]
        state, _ = self._registry.end(run_id=run_id, output=docs_serializable, end_time=time.time())
        retriever_name = self._tool_names.pop(run_id, "retriever")
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_END,
                metadata=state.metadata,
                action=ToolAction(
                    name=retriever_name,
                    parameters=None,
                    call_id=str(run_id),
                    observation=docs_serializable,
                ),
            )
        )

    @_safe
    async def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state, _ = self._registry.error(run_id=run_id, error=error, end_time=time.time())
        retriever_name = self._tool_names.pop(run_id, "retriever")
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_ERROR,
                metadata=state.metadata,
                action=ToolAction(name=retriever_name, parameters=None, call_id=str(run_id)),
                error_code=type(error).__name__,
                error_message=str(error),
            )
        )

    # ---- agent callbacks ----

    @_safe
    async def on_agent_action(
        self,
        action: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state = self._registry.get(run_id)
        metadata = state.metadata if state else None
        tool_input = getattr(action, "tool_input", "")
        parameters: dict[str, Any] | None = (
            tool_input if isinstance(tool_input, dict) else {"input": tool_input}
        )
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_START,  # TODO: handle delegate agents + emit AGENT_CALL, AGENT_START, AGENT_END
                metadata=metadata,
                action=ToolAction(
                    name=getattr(action, "tool", "") or "tool",
                    parameters=parameters,
                    call_id=str(run_id),
                    thought=getattr(action, "log", None) or None,
                ),
            )
        )

    @_safe
    async def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        state = self._registry.get(run_id)
        metadata = state.metadata if state else None
        return_values = getattr(finish, "return_values", {})
        await self._emit(
            self._new_event(
                event_type=ExecutionEventType.TOOL_END,  # TODO: handle delegate agents + emit AGENT_CALL, AGENT_START, AGENT_END
                metadata=metadata,
                action=ToolAction(
                    name="agent_finish",
                    parameters=None,
                    call_id=str(run_id),
                    observation=return_values,
                    message=getattr(finish, "log", None) or None,
                ),
            )
        )
        await self._maybe_emit_response(state)
