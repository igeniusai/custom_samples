import asyncio
from pathlib import Path
from typing import Any

import yaml

from domyn_agents.agents import AgentFactory
from domyn_agents.agents.agent import Agent
from domyn_agents.registry import get_agent_registry
from domyn_agents.runner import _return_subagents


def load_from_file(file_path: str) -> dict[str, Any]:
    """Load configuration from a YAML file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {file_path}")

    with open(path, encoding="utf-8") as f:
        config: dict[str, Any] = yaml.safe_load(f)

    return config


async def load_application_from_config_new(config: dict[str, Any], mcp_init: bool = True) -> Agent:
    version = config.get("version", "1.0")
    match version:
        case "1.0":
            from domyn_agents.loader.config import ConfigurationV1

            cfg = ConfigurationV1.from_dict(config)
        case _:
            raise ValueError(f"Unsupported configuration version: {version}")

    if not cfg.entrypoint and cfg.agents:
        cfg.entrypoint = cfg.agents[-1].name

    # Get the first agent from the configuration
    agent = next(
        filter(lambda a: a.name == cfg.entrypoint, cfg.agents),
        None,
    )
    if agent is None:
        raise ValueError(f"Agent '{cfg.entrypoint}' not found in configuration")

    tasks = []
    for sub_agent in _return_subagents(agent):
        if mcp_init and hasattr(sub_agent, "initialize_mcp_tools"):
            tasks.append(sub_agent.initialize_mcp_tools())

    await asyncio.gather(*tasks)

    return agent


async def load_application_from_file(file_path: str) -> Agent:
    """Load application configuration from a YAML file. Return the root agent."""
    config = load_from_file(file_path)
    return await load_application_from_config_new(config)


def load_application_from_config(
    config: dict[str, Any],
    save_in_registry: bool = True,
) -> Agent:
    version = config.get("version", "1.0")
    match version:
        case "1.0":
            for agent_cfg in config.get("agents", []):
                AgentFactory.from_config(agent_cfg, save_in_registry=save_in_registry)
        case _:
            raise ValueError(f"Unsupported configuration version: {version}")

    entrypoint = config.get("entrypoint")
    if not entrypoint:
        raise ValueError("Entrypoint agent not specified in the configuration.")
    return get_agent_registry().get_agent(entrypoint)


# def load_from_directory(directory: str) -> None:
#     """Load all YAML files from a directory."""
#     path = Path(directory)
#     if not path.exists():
#         raise FileNotFoundError(f"Directory not found: {directory}")

#     for yaml_file in path.glob("*.yaml"):
#         load_from_file(str(yaml_file))

#     for yml_file in path.glob("*.yml"):
#         load_from_file(str(yml_file))
