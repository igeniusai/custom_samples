"""YAML loader for creating agents and tools from configuration files."""


# """Load and register agents/tools from YAML configuration."""

# def __init__(self, registry: RegistryStorage):
#     self.registry = registry


# def _register_agent_from_config(self, config: dict[str, Any]) -> None:
#     """Register an agent from configuration."""
#     required_fields = ["name", "description", "instruction", "llm_provider", "planner_strategy"]
#     for field in required_fields:
#         if field not in config:
#             raise ValueError(f"Missing required field '{field}' in agent config")

#     agent_config = {
#         "name": config["name"],
#         "description": config.get("description", ""),
#         "instruction": config["instruction"],
#         "planner_strategy": config["planner_strategy"],
#         "llm_provider": config["llm_provider"],
#         "memory_provider": config.get("memory_provider", "in_memory"),
#         "tools": config.get("tools", []),
#         "subagents": config.get("subagents", []),
#         "system_prompt": config.get("system_prompt", ""),
#         "model_config": config.get("model_config", {}),
#         "hooks": config.get("hooks", []),
#         "external": config.get("external", False),
#         "endpoint": config.get("endpoint"),  # For external agents
#         "auth": config.get("auth", {}),
#         "pre_hooks": config.get("pre_hooks", []),
#         "post_hooks": config.get("post_hooks", []),
#         **config.get("metadata", {}),
#     }

#     self.registry.register_agent(config["name"], agent_config)

# def _register_tool_from_config(self, config: dict[str, Any]) -> None:
#     """Register a tool from configuration."""
#     required_fields = ["name", "type"]
#     for field in required_fields:
#         if field not in config:
#             raise ValueError(f"Missing required field '{field}' in tool config")

#     tool_config = {
#         "name": config["name"],
#         "description": config.get("description", ""),
#         "tool_type": config["type"],
#         "async_tool": config.get("async", False),
#         "parameters": config.get("parameters", {}),
#         "implementation": config.get("implementation"),
#         "external": config.get("external", False),
#         "endpoint": config.get("endpoint"),
#         "human_in_loop": config.get("human_in_loop", False),
#         **config.get("metadata", {}),
#     }

#     self.registry.register_tool(config["name"], tool_config)

# def _register_hook_from_config(self, config: dict[str, Any]) -> None:
#     """Register a hook from configuration."""
#     required_fields = ["name", "type"]
#     for field in required_fields:
#         if field not in config:
#             raise ValueError(f"Missing required field '{field}' in hook config")

#     hook_config = {
#         "name": config["name"],
#         "hook_type": config["type"],  # pre, post, guardrail
#         "priority": config.get("priority", 0),
#         "implementation": config.get("implementation"),
#         "conditions": config.get("conditions", []),
#         "enabled": config.get("enabled", True),
#         **config.get("metadata", {}),
#     }

#     self.registry.register_hook(config["name"], hook_config)

# def _register_dataset_from_config(self, config: dict[str, Any]) -> None:
#     """Register a dataset from configuration."""
#     required_fields = ["name", "source"]
#     for field in required_fields:
#         if field not in config:
#             raise ValueError(f"Missing required field '{field}' in dataset config")

#     dataset_config = {
#         "name": config["name"],
#         "description": config.get("description", ""),
#         "source": config["source"],
#         "format": config.get("format", "json"),
#         "evaluation_metrics": config.get("evaluation_metrics", []),
#         "tags": config.get("tags", []),
#         **config.get("metadata", {}),
#     }

#     self.registry.register_dataset(config["name"], dataset_config)

# def validate_config(self, config: dict[str, Any]) -> list[str]:
#     """Validate configuration and return list of errors."""
#     errors = []

#     # Validate agents
#     if "agents" in config:
#         for i, agent in enumerate(config["agents"]):
#             errors.extend(self._validate_agent_config(agent, f"agents[{i}]"))

#     # Validate tools
#     if "tools" in config:
#         for i, tool in enumerate(config["tools"]):
#             errors.extend(self._validate_tool_config(tool, f"tools[{i}]"))

#     return errors

# def _validate_agent_config(self, config: dict[str, Any], path: str) -> list[str]:
#     """Validate agent configuration."""
#     errors = []
#     required_fields = ["name", "logic_type"]

#     for field in required_fields:
#         if field not in config:
#             errors.append(f"{path}: Missing required field '{field}'")

#     # Validate logic type
#     valid_logic_types = ["react", "rewoo", "custom"]
#     if "logic_type" in config and config["logic_type"] not in valid_logic_types:
#         errors.append(f"{path}: Invalid logic_type. Must be one of {valid_logic_types}")

#     return errors

# def _validate_tool_config(self, config: dict[str, Any], path: str) -> list[str]:
#     """Validate tool configuration."""
#     errors = []
#     required_fields = ["name", "type"]

#     for field in required_fields:
#         if field not in config:
#             errors.append(f"{path}: Missing required field '{field}'")

#     # Validate tool type
#     valid_tool_types = ["text", "file", "streaming", "multimodal", "async"]
#     if "type" in config and config["type"] not in valid_tool_types:
#         errors.append(f"{path}: Invalid type. Must be one of {valid_tool_types}")

#     return errors
