# Domyn CLI

The `domyn` CLI is the main interface for creating, running, serving, and deploying agents built with the Domyn Agents framework.

## Installation

The CLI is included when you install `domyn-agents`. The `domyn` entry point is available after installation:

```bash
uv add domyn-agents
```

## Global Options

```
domyn [OPTIONS] COMMAND
```

| Option | Default | Description |
|--------|---------|-------------|
| `--log-level TEXT` | `INFO` | Logging verbosity (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`) |
| `--version` | — | Print installed version and exit |

---

## Commands

### `domyn init`

Scaffold a new Domyn Agents project using `uv`.

```bash
domyn init [PROJECT_NAME] [OPTIONS]
```

| Argument / Option | Default | Description |
|-------------------|---------|-------------|
| `PROJECT_NAME` | prompted | Name of the new project |
| `--directory / -d TEXT` | `./<project_name>` | Target directory |
| `--force / -f` | `false` | Overwrite an existing directory |
| `--use-local-index / -l` | `false` | Pull `domyn-agents` from the internal package index (for internal use) |

**What it creates:**

```
<project>/
├── agent.py          # Pre-wired Agent with example tools
├── pyproject.toml    # uv project with domyn-agents dependency
├── Dockerfile        # Ready-to-build production image
├── README.md         # Project-level instructions
└── .gitignore
```

**Example:**

```bash
domyn init my-assistant
cd my-assistant
# Edit agent.py to configure your LLM provider and tools
uv run domyn run agent.py "Hello!"
```

---

### `domyn run`

Load an agent from a `.py` or `.yaml` file and start an interactive conversation in the terminal.

```bash
domyn run FILE PROMPT [OPTIONS]
```

| Argument / Option | Default | Description |
|-------------------|---------|-------------|
| `FILE` (required) | — | Path to a `.py` module or `.yaml` config file |
| `PROMPT` (required) | — | First message sent to the agent |
| `--agent-name / -a TEXT` | auto-detected | Variable name of the agent to run |

**Agent auto-detection** (`.py` files):

1. Exact match on `--agent-name`
2. Root agent — the one that is not a `sub_agent` of any other agent
3. Name-based fallback (`main`, `service`, `customer`)
4. First `Agent` instance found

**Terminal output:**

- Streaming tokens printed as they arrive
- Tool calls shown in yellow (`→ tool_name {params}`)
- Tool results shown in dim (`← observation`)
- Agent handoffs shown in magenta (`↪ / ↩`)

After each response the CLI prompts for the next input. Type `quit`, `exit`, or `bye` to end the session.

**Examples:**

```bash
# Run from a Python file (auto-detects root agent)
domyn run agent.py "What is the weather in Milan?"

# Run a specific agent by variable name
domyn run agent.py "Help me" --agent-name customer_support_agent

# Run from a YAML config
domyn run config.yaml "Summarise the last report"
```

---

### `domyn serve`

Expose an agent as a local HTTP server (REST by default).

```bash
domyn serve FILE [OPTIONS]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--protocol / -p TEXT` | `rest` | Serving protocol (`rest`; `mcp` and `a2a` are planned) |
| `--host TEXT` | `0.0.0.0` | Bind address |
| `--port INTEGER` | `8000` | Bind port |
| `--agent-name TEXT` | auto-detected | Agent to serve |

**REST API endpoints:**

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Health check — returns `{"status": "healthy", "agent": "<name>"}` |
| `GET` | `/agents` | List all agents with name and description |
| `GET` | `/agents/{name}` | Agent detail — name, description, tool list |
| `POST` | `/run` | Run agent synchronously, returns final response text |
| `POST` | `/execute` | Run agent, stream all events via Server-Sent Events (SSE) |

**`POST /run` request / response:**

```jsonc
// Request
{ "text_input": "Hello", "conversation_id": "conv_abc123", "user_id": "user_1" }

// Response
{ "response": "Hi there!", "conversation_id": "conv_abc123", "agent_name": "MyAgent" }
```

**`POST /execute` SSE stream:**

Each line is `data: <BaseEvent JSON>`. The stream ends with `event: end\ndata: {}`.

**Examples:**

```bash
domyn serve agent.py
domyn serve agent.py --port 9000 --host 127.0.0.1
domyn serve config.yaml --protocol rest

# Query the running server
curl -X POST http://localhost:8000/run \
  -H "Content-Type: application/json" \
  -d '{"text_input": "Hello!"}'
```

---

### `domyn dev`

Like `domyn serve`, but with **hot-reload** — the server automatically restarts when source files change. Intended for local development only.

```bash
domyn dev FILE [OPTIONS]
```

| Option | Default | Description |
|--------|---------|-------------|
| `--host TEXT` | `127.0.0.1` | Bind address (localhost by default) |
| `--port INTEGER` | `8000` | Bind port |
| `--agent-name TEXT` | auto-detected | Agent to serve |

The agent file and its parent directory are watched for changes via `uvicorn --reload`.

**Examples:**

```bash
domyn dev agent.py
domyn dev agent.py --port 8080
domyn dev config.yaml --agent-name MyAgent
```

---

### `domyn deploy`

Reserved for future deployment automation. Currently a no-op.

---

## Environment Variables

`domyn dev` sets the following variables before starting uvicorn (do not set them manually):

| Variable | Description |
|----------|-------------|
| `DOMYN_AGENT_FILE` | Absolute path to the agent file |
| `DOMYN_AGENT_NAME` | Agent name to serve (omitted when auto-detecting) |

---

## Module Structure

```
domyn_agents/cli/
├── cli.py                    # Typer app assembly and global options
├── main.py                   # Entry point (calls app())
├── utils.py                  # Version helper, log-level mapping
└── commands/
    ├── init/command.py        # domyn init
    ├── run/command.py         # domyn run (agent loader + conversation loop)
    ├── serve/
    │   ├── command.py         # domyn serve (protocol dispatch)
    │   ├── server.py          # FastAPI app factory + ServerInterface
    │   └── factory.py         # uvicorn factory for hot-reload (domyn dev)
    ├── dev/command.py         # domyn dev
    └── deploy/command.py      # domyn deploy (stub)
```
