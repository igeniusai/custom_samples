import asyncio
import importlib.util
import inspect
import sys
import uuid
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from domyn_agents.agents import Agent
from domyn_agents.core import BaseEvent, ExecutionEventType, Part
from domyn_agents.logger import get_logger
from domyn_agents.runner import Runner

logger = get_logger()
console = Console()


def load_module_from_path(file_path: str) -> Any:
    """Load a Python module from a .py file path."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    if path.suffix not in (".py",):
        raise ValueError(f"Expected a .py file, got: {file_path}")

    spec = importlib.util.spec_from_file_location("user_module", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module from {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules["user_module"] = module
    spec.loader.exec_module(module)
    return module


async def load_agent_from_yaml(file_path: str) -> Agent:
    """Load root agent from a YAML config file."""
    from domyn_agents.loader import load_application_from_file

    return await load_application_from_file(file_path)


def collect_all_agents(module: Any) -> dict[str, Agent]:
    """Collect all Agent instances from the module and its imports.

    Returns a dictionary mapping agent variable names to Agent instances.
    """
    agents: dict[str, Agent] = {}
    visited_modules: set[Any] = set()

    def _collect_from_module(mod: Any, mod_name: str = "") -> None:
        if mod in visited_modules or mod is None:
            return
        visited_modules.add(mod)

        for attr_name in dir(mod):
            if attr_name.startswith("_"):
                continue
            try:
                attr = getattr(mod, attr_name)
                if isinstance(attr, Agent):
                    full_name = f"{mod_name}.{attr_name}" if mod_name else attr_name
                    agents[full_name.lower()] = attr
                    logger.debug(f"Found agent: {full_name}")
            except (AttributeError, ImportError):
                continue

        for attr_name in dir(mod):
            if attr_name.startswith("_"):
                continue
            try:
                attr = getattr(mod, attr_name)
                is_imported_module = inspect.ismodule(attr) and hasattr(attr, "__file__")
                if (
                    is_imported_module
                    and attr.__file__
                    and not attr.__file__.startswith("/usr/")
                    and not attr.__file__.startswith("/opt/")
                    and "site-packages" not in attr.__file__
                ):
                    _collect_from_module(attr, attr_name)
            except (AttributeError, ImportError):
                continue

    _collect_from_module(module)
    return agents


def find_root_agents(agents: dict[str, Agent]) -> dict[str, Agent]:
    """Find agents that are not sub_agents of any other agent."""
    child_agents = {id(sub_agent) for a in agents.values() for sub_agent in a.sub_agents}
    return {name: a for name, a in agents.items() if id(a) not in child_agents}


def find_main_agent(all_agents: dict[str, Agent], agent_name: str | None = None) -> Agent:
    """Find the main agent using dependency tree analysis.

    Priority:
    1. Exact match by --agent-name
    2. Root agent (not a sub_agent of any other)
    3. Name-based fallback ("main", "service", "customer")
    4. First agent found
    """
    if not all_agents:
        raise ValueError("No Agent instances found in the module or its imports")

    logger.debug(f"Found {len(all_agents)} total agents: {list(all_agents.keys())}")

    if agent_name:
        agent_name = agent_name.lower()
        if agent := all_agents.get(agent_name):
            return agent
        matches = [a for a in all_agents if a.endswith(f".{agent_name}") or a == agent_name]
        if matches:
            return all_agents[matches[0]]
        raise ValueError(f"Agent '{agent_name}' not found. Available: {list(all_agents.keys())}")

    root_agents = find_root_agents(all_agents)

    if not root_agents:
        logger.warning("No root agents found. Falling back to name-based detection.")
        for name, agent in all_agents.items():
            if any(k in name.lower() for k in ("main", "service", "customer")):
                return agent
        return next(iter(all_agents.values()))

    if len(root_agents) > 1:
        logger.warning(
            f"Multiple root agents found: {list(root_agents.keys())}. Using: {next(iter(root_agents))}"
        )

    return next(iter(root_agents.values()))


async def run_agent_conversation(agent: Agent, prompt: str) -> None:
    """Run a conversation with the agent, printing all events to the terminal."""
    runner = Runner()
    conversation_id = f"conv_{uuid.uuid4().hex}"
    token_buffer: list[str] = []

    input_event = BaseEvent(
        event_type=ExecutionEventType.USER_INPUT,
        author="user",
        content=[Part(text=prompt)],
    )

    console.print(f"[bold]Agent:[/bold] {agent.name}")
    console.print(f"[bold]Prompt:[/bold] {prompt}")
    console.print("─" * 60)

    while True:
        async for event in runner.run(
            application_name="CLI Agent Runner",
            user_id="user",
            user_input=input_event,
            root=agent,
            entrypoint_name=agent.name,
            entrypoint_visibility=None,
            conversation_id=conversation_id,
            run_config={},
        ):
            if event.event_type == ExecutionEventType.RESPONSE_TOKEN:
                for part in event.content:
                    if part.text:
                        token_buffer.append(part.text)
                        console.print(part.text, end="", highlight=False)

            elif event.event_type == ExecutionEventType.RESPONSE:
                if token_buffer:
                    token_buffer.clear()
                    console.print()
                else:
                    for part in event.content:
                        if part.thought:
                            console.print(f"[dim italic]{part.thought}[/dim italic]")
                        if part.text:
                            console.print(part.text)

                if not event.is_partial:
                    console.print()
                    console.print("[bold]Your input[/bold] (or 'quit' to exit): ", end="")
                    next_input = input()
                    if next_input.lower() in ("quit", "exit", "bye"):
                        console.print("Goodbye!")
                        return
                    input_event = BaseEvent(
                        event_type=ExecutionEventType.USER_INPUT,
                        author="user",
                        content=[Part(text=next_input)],
                    )

            elif event.event_type == ExecutionEventType.TOOL_START:
                if event.action and event.action.thought:
                    console.print(f"[dim italic]{event.action.thought}[/dim italic]")
                if event.action:
                    params = getattr(event.action, "parameters", {})
                    console.print(f"[yellow]→ {event.action.name}[/yellow] {params}")

            elif event.event_type == ExecutionEventType.TOOL_END:
                if event.action and hasattr(event.action, "observation"):
                    console.print(f"[dim]← {event.action.observation}[/dim]")
                for part in event.content:
                    if part.text:
                        console.print(f"[dim]{part.text}[/dim]")

            elif event.event_type == ExecutionEventType.AGENT_CALL:
                if event.action:
                    console.print(f"[magenta]↪ Handoff → {event.action.name}[/magenta]")

            elif event.event_type == ExecutionEventType.AGENT_START:
                pass  # runner-internal start event; handoff already shown via AGENT_CALL

            elif event.event_type == ExecutionEventType.AGENT_END:
                if event.action:
                    console.print(f"[magenta]↩ Return ← {event.action.name}[/magenta]")

            else:
                logger.debug(f"Event: {event.event_type.value}")


def run_command(
    file: Path = typer.Argument(..., help="Path to the .py or .yaml agent config file"),
    prompt: str = typer.Argument(..., help="The prompt to send to the agent"),
    agent_name: str | None = typer.Option(
        None,
        "--agent-name",
        "-a",
        help="Variable name of the agent to run (auto-detected if omitted)",
    ),
) -> None:
    """Run an agent from a .py or .yaml config file with a prompt."""
    path = Path(file)

    try:
        if path.suffix in (".yaml", ".yml"):
            agent = asyncio.run(load_agent_from_yaml(str(path)))
        else:
            module = load_module_from_path(str(path))
            all_agents = collect_all_agents(module)
            agent = find_main_agent(all_agents, agent_name)

        asyncio.run(run_agent_conversation(agent, prompt))

    except Exception as e:
        logger.error(f"Error running agent: {e}")
        typer.echo(f"Error: {e}", err=True)
        sys.exit(1)
