"""Expose command module."""

from .command import expose_command

__all__ = ["expose_command"]
