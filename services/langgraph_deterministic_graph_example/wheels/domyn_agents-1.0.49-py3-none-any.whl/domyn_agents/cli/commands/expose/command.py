"""domyn expose — connects a runnable to the relay and processes invoke requests.

Usage:
    DOMYN_API_KEY='<key>' domyn expose module:symbol \\
        --channel-id <id> --space-id <id> [--base-url <host>] [--max-concurrency <n>]

Opens an outbound WebSocket to the relay, keeps it alive with automatic
reconnection (full-jitter exponential backoff), and processes invoke requests
by delegating to the registered runnable. Trace events are streamed back to
the relay as they are emitted; AGENT_END / ERROR_OCCURRED BaseEvents mark
completion.

The DOMYN_API_KEY environment variable must be set.
"""

from __future__ import annotations

import asyncio
import os
import random

import typer
from rich.console import Console

from domyn_agents.integrations.langgraph import Runtime, load_runnable
from domyn_agents.integrations.langgraph.platform import get_default_relay
from domyn_agents.integrations.langgraph.utils import InputMapper
from domyn_agents.logger import get_logger

logger = get_logger()
console = Console()

RECONNECT_BASE_S = 0.5
RECONNECT_CAP_S = 30.0


def _build_ws_url(base_url: str) -> str:
    localhost = ("localhost", "127.0.0.1", "::1")
    scheme = "ws" if base_url in localhost or base_url.startswith("localhost:") else "wss"
    return f"{scheme}://{base_url}/relay/v1/ws"


async def _run(
    ws_url: str,
    headers: dict[str, str],
    runnable: object,
    max_concurrency: int,
    input_mapper: InputMapper | None,
) -> None:
    try:
        import websockets
    except ImportError as exc:
        console.print(
            "[red]ERROR:[/red] 'websockets' package not found. Run: pip install websockets"
        )
        raise typer.Exit(1) from exc

    attempt = 0
    while True:
        try:
            async with websockets.connect(ws_url, additional_headers=headers) as ws:
                console.print(f"[green]Connected[/green] {ws_url}")
                attempt = 0
                runtime = Runtime(
                    runnable=runnable,
                    ws=ws,
                    max_concurrency=max_concurrency,
                    input_mapper=input_mapper,
                    platform_relay=get_default_relay(),
                )
                await runtime.run()
                # run() returned normally — server closed the connection
                code = getattr(ws, "close_code", None)
                reason = getattr(ws, "close_reason", None) or getattr(ws, "close_message", None)
                console.print(
                    f"[yellow]Connection closed by server[/yellow] (code={code}, reason={reason!r})"
                )
        except OSError as exc:
            console.print(f"[red]Connection failed:[/red] {exc}")
        except Exception as exc:
            if "InvalidStatus" in type(exc).__name__:
                console.print(f"[red]Server rejected connection:[/red] {exc}")
            else:
                logger.error("unexpected error during relay connection: %s", exc, exc_info=True)

        delay = random.uniform(0, min(RECONNECT_CAP_S, RECONNECT_BASE_S * (2**attempt)))
        attempt += 1
        console.print(f"Reconnecting in {delay:.1f}s...")
        await asyncio.sleep(delay)


def expose_command(
    entrypoint: str = typer.Argument(
        ...,
        help="Runnable entrypoint as 'module:symbol' or 'path/to/file.py:symbol'",
        metavar="MODULE:SYMBOL",
    ),
    channel_id: str = typer.Option(..., "--channel-id", help="Relay channel ID"),
    space_id: str = typer.Option(..., "--space-id", help="Relay space ID"),
    base_url: str = typer.Option(
        ...,
        "--base-url",
        help="Relay server hostname",
    ),
    max_concurrency: int = typer.Option(
        8,
        "--max-concurrency",
        help="Max concurrent in-flight invocations before WorkerBusy rejection",
        min=1,
    ),
) -> None:
    """Expose a runnable as a relay-connected worker.

    Connects outbound to the relay and processes invoke requests, streaming
    trace events back over the connection.

    The DOMYN_API_KEY environment variable must be set.
    """
    api_key = os.environ.get("DOMYN_API_KEY", "")
    if not api_key:
        console.print("[red]ERROR:[/red] DOMYN_API_KEY environment variable is not set.")
        raise typer.Exit(1)

    os.environ["DOMYN_SPACE_ID"] = space_id  # for platform tool access within the runnable
    os.environ["DOMYN_BASE_URL"] = base_url  # for platform tool access within the runnable

    try:
        runnable, input_mapper = load_runnable(entrypoint)
    except Exception as exc:
        console.print(f"[red]ERROR:[/red] failed to load runnable: {exc}")
        raise typer.Exit(1) from exc

    ws_url = _build_ws_url(base_url)
    headers = {"channel-id": channel_id, "space-id": space_id, "api-key": api_key}

    console.print(f"[bold]domyn expose[/bold] {entrypoint}")
    console.print(f"  relay           : {ws_url}")
    console.print(f"  channel         : {channel_id}")
    console.print(f"  space           : {space_id}")
    console.print(f"  max_concurrency : {max_concurrency}")
    console.print("Press Ctrl+C to stop.")

    try:
        asyncio.run(_run(ws_url, headers, runnable, max_concurrency, input_mapper))
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped.[/dim]")
