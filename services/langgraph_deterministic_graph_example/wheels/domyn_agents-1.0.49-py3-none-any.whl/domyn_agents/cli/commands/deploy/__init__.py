"""Deploy command module."""

from .command import deploy_command

__all__ = ["deploy_command"]
