def deploy_command() -> None:
    pass
