"""App factory for uvicorn --reload support.

Reads agent configuration from environment variables set by `domyn dev`:
  DOMYN_AGENT_FILE  — path to the .py or .yaml agent file
  DOMYN_AGENT_NAME  — agent name to serve (optional, auto-detected if absent)
"""

import asyncio
import os
from pathlib import Path

from fastapi import FastAPI

from domyn_agents.cli.commands.run.command import (
    collect_all_agents,
    find_main_agent,
    load_agent_from_yaml,
    load_module_from_path,
)
from domyn_agents.cli.commands.serve.server import create_app


def app_factory() -> FastAPI:
    """Load agent from env vars and return a FastAPI app instance."""
    agent_file = os.environ.get("DOMYN_AGENT_FILE")
    if not agent_file:
        raise RuntimeError("DOMYN_AGENT_FILE environment variable is required for domyn dev")

    agent_name = os.environ.get("DOMYN_AGENT_NAME") or None

    path = Path(agent_file)

    if path.suffix in (".yaml", ".yml"):
        main_agent = asyncio.run(load_agent_from_yaml(str(path)))
        all_agents = {main_agent.name: main_agent}
    else:
        module = load_module_from_path(str(path))
        all_agents = collect_all_agents(module)
        main_agent = find_main_agent(all_agents, agent_name)

    return create_app(main_agent, all_agents)
