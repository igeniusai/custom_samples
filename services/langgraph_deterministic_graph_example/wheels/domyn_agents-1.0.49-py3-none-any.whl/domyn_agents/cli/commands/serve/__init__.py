"""Serve command module."""

from .command import serve_command

__all__ = ["serve_command"]
