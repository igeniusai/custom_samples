import asyncio
import enum
import sys
from pathlib import Path

import typer

from domyn_agents.cli.commands.run.command import (
    collect_all_agents,
    find_main_agent,
    load_agent_from_yaml,
    load_module_from_path,
)
from domyn_agents.cli.commands.serve.server import ServerInterface
from domyn_agents.logger import get_logger


class ServingProtocol(enum.Enum):
    REST = enum.auto()
    MCP = enum.auto()
    A2A = enum.auto()


logger = get_logger()


def serve_command(
    file: Path = typer.Argument(..., help="Path to the .py or .yaml agent config file"),
    protocol: str = typer.Option(
        "rest",
        "--protocol",
        "-p",
        help="Serving protocol: rest, mcp, a2a",
    ),
    host: str = typer.Option("0.0.0.0", "--host", help="Bind host (default: 0.0.0.0)"),
    port: int = typer.Option(8000, "--port", help="Bind port (default: 8000)"),
    agent_name: str | None = typer.Option(
        None,
        "--agent-name",
        help="Agent to serve (auto-detected if omitted)",
    ),
) -> None:
    """Serve an agent as a local REST API."""
    try:
        protocol_enum = ServingProtocol[protocol.upper()]
    except KeyError:
        typer.echo(f"Error: Unknown protocol '{protocol}'. Choose: rest, mcp, a2a", err=True)
        sys.exit(1)

    if protocol_enum != ServingProtocol.REST:
        typer.echo(f"Error: '{protocol}' protocol not yet implemented", err=True)
        sys.exit(1)

    path = Path(file)

    try:
        if path.suffix in (".yaml", ".yml"):
            main_agent = asyncio.run(load_agent_from_yaml(str(path)))
            all_agents = {main_agent.name: main_agent}
        else:
            module = load_module_from_path(str(path))
            all_agents = collect_all_agents(module)
            main_agent = find_main_agent(all_agents, agent_name)
    except Exception as e:
        typer.echo(f"Error loading agent from {file}: {e}", err=True)
        sys.exit(1)

    typer.echo(f"Starting REST server for agent '{main_agent.name}' on {host}:{port}")
    try:
        server = ServerInterface(main_agent, all_agents)
        asyncio.run(server.start_async(host=host, port=port))
    except KeyboardInterrupt:
        typer.echo("\nServer stopped.")
    except Exception as e:
        typer.echo(f"Error starting server: {e}", err=True)
        sys.exit(1)
