"""Dev command module."""

from .command import dev_command

__all__ = ["dev_command"]
