import os
import sys
from pathlib import Path

import typer
import uvicorn


def dev_command(
    file: Path = typer.Argument(..., help="Path to the .py or .yaml agent config file"),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host (default: 127.0.0.1)"),
    port: int = typer.Option(8000, "--port", help="Bind port (default: 8000)"),
    agent_name: str | None = typer.Option(
        None,
        "--agent-name",
        help="Agent to serve (auto-detected if omitted)",
    ),
) -> None:
    """Run a local development server with hot-reload on file changes."""
    path = Path(file).resolve()
    if not path.exists():
        typer.echo(f"Error: File not found: {path}", err=True)
        sys.exit(1)

    os.environ["DOMYN_AGENT_FILE"] = str(path)
    if agent_name:
        os.environ["DOMYN_AGENT_NAME"] = agent_name
    elif "DOMYN_AGENT_NAME" in os.environ:
        del os.environ["DOMYN_AGENT_NAME"]

    typer.echo(f"Starting dev server for '{path.name}' on {host}:{port} (reload enabled)")
    typer.echo("Press Ctrl+C to stop.")

    try:
        uvicorn.run(
            "domyn_agents.cli.commands.serve.factory:app_factory",
            host=host,
            port=port,
            reload=True,
            factory=True,
            reload_dirs=[str(path.parent)],
            log_level="info",
        )
    except KeyboardInterrupt:
        typer.echo("\nDev server stopped.")
