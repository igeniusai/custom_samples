from domyn_agents.cli.cli import app


def cli() -> None:
    app()


if __name__ == "__main__":
    cli()
