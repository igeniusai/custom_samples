import logging
from importlib.metadata import PackageNotFoundError, version

package_name = "domyn_agents"  # TODO: replace with actual package name


def get_version() -> str:
    try:
        return version(package_name)
    except PackageNotFoundError:
        return "unknown"


LOG_LEVELS = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}


def setup_logging(log_level: str) -> int:
    lvl = LOG_LEVELS.get(log_level.upper(), logging.INFO)
    logging.basicConfig(level=lvl, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    return lvl
