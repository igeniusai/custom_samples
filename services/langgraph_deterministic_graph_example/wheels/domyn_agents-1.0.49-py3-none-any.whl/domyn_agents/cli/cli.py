import typer

from domyn_agents.cli.commands import (
    deploy_command,
    dev_command,
    expose_command,
    init_command,
    run_command,
    serve_command,
)
from domyn_agents.cli.utils import get_version, package_name
from domyn_agents.logger import get_logger

app = typer.Typer(
    name="cli",
    help="Main entrypoint for the CLI",
    no_args_is_help=True,
    add_completion=False,
)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(get_version())
        raise typer.Exit()


@app.callback()
def cli(
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        help="Set the logging level",
        case_sensitive=False,
    ),
    version: bool | None = typer.Option(
        None, "--version", callback=version_callback, help="Show version and exit"
    ),
) -> None:
    """Main entrypoint for the CLI"""

    logger = get_logger()
    # lvl = setup_logging(log_level)
    # logger.setLevel(lvl)
    logger.info(f"Starting {package_name} CLI version {get_version()} with log level {log_level}")


app.command("init", help="Initialize a new Domyn Agents project")(init_command)
app.command("run", help="Run an agent from a Python file with a prompt")(run_command)
app.command("dev", help="Run (Dev) Server")(dev_command)
app.command("serve", help="Serve an agent from a Python file using the specified protocol")(
    serve_command
)
app.command("deploy", help="Deploy Agents")(deploy_command)
app.command("expose", help="Expose a runnable as a relay-connected worker")(expose_command)
