"""IoC decorators for automatic component registration."""

import inspect
from collections.abc import Callable
from typing import Any, TypeVar

from domyn_agents.agents.agent import Agent
from domyn_agents.agents.wrapped import WrappedAgent
from domyn_agents.core import ApprovalType, ExecutionEventType
from domyn_agents.hooks.base import HookPhase, HookType, InputFields
from domyn_agents.hooks.function_hook import FunctionHook
from domyn_agents.llm.base import BaseLLMProvider
from domyn_agents.registry import (
    get_agent_registry,
    get_hook_registry,
    get_llm_registry,
    get_tool_registry,
)
from domyn_agents.tools import ToolType
from domyn_agents.tools.base import Param
from domyn_agents.tools.function_tool import FunctionTool
from domyn_agents.tools.streamable_function_tool import StreamableFunctionTool

F = TypeVar("F", bound=Callable[..., Any])
T = TypeVar("T", bound=type)


def tool(
    name: str | None = None,
    description: str | None = None,
    type: ToolType = ToolType.FUNCTION,
    config_params: list[Param] | None = None,
    group: str | None = None,  # TODO: remove and include in metadata
    metadata: dict[str, Any] | None = None,
    approval_type: ApprovalType | None = None,
) -> Callable[[F], F]:
    """
    Decorator to register a function as a tool.

    Args:
        name: Override the tool name (defaults to function name)
        description: Override the tool description (defaults to docstring)

    Returns:
        Decorated function that is automatically registered as a tool
    """

    if config_params is None:
        config_params = []

    def decorator(func: F) -> FunctionTool | StreamableFunctionTool:
        # Create FunctionTool and register it
        match type:
            case ToolType.STREAMABLE_FUNCTION:
                if not inspect.isasyncgenfunction(func):
                    raise TypeError(
                        f"Function {func.__name__} must be an async generator for StreamableFunctionTool"
                    )
                function_tool = StreamableFunctionTool(
                    func=func,
                    config_params=config_params,
                    group=group,
                    metadata=metadata,
                    approval_type=approval_type,
                )
            case _:
                function_tool = FunctionTool(
                    func=func,
                    config_params=config_params,
                    group=group,
                    metadata=metadata,
                    approval_type=approval_type,
                )

        # Use provided name or function name
        function_tool.name = name or function_tool.name
        function_tool.description = description or function_tool.description

        # Register the function tool
        registry = get_tool_registry()
        registry.register_tool(function_tool)

        return function_tool

    return decorator


def agent(
    name: str | None = None,
    description: str | None = None,
    # description: str | None = None,
    # instruction: str = "",
    # llm_provider: dict[str, str] | BaseLLMProvider | str = {
    #     "type": "vllm",
    #     "model_name": "Qwen/Qwen3-8B",
    #     "url": "https://gateway-dev.llm.crystal.ai/v1/chat/completions",
    # },
    # planner_strategy: dict[str, str] | BasePlannerStrategy = {},
    # subagents: list[str | Agent] = [],
    *,
    default_execute_agent_function: str = "execute",
    **config_kwargs: Any,
) -> Callable[[type[Agent]], type[Agent]]:
    """
    Decorator to register an agent class.

    Args:
        name: Override the agent name
        description: Override the agent description
        instruction: Override the agent instruction
        llm_provider: Override the LLM provider configuration
        planner_strategy: Override the planner strategy
        subagents: Override the subagents list
        default_execute_agent_function: Override the default execute agent function.
        **config_kwargs: Additional configuration for the agent

    Returns:
        Decorated agent class that is automatically registered
    """

    def decorator(cls: type[T]) -> type[T]:
        # Get registry
        registry = get_agent_registry()

        _name = name or cls.__name__

        built_instance = None

        def _factory_method(*args, **kwargs):
            nonlocal built_instance
            if built_instance is None:
                if inspect.isclass(cls) and issubclass(cls, Agent):
                    # Include name and description from decorator params
                    if name is not None:
                        config_kwargs["name"] = name
                    if description is not None:
                        config_kwargs["description"] = description
                    config_kwargs.update(kwargs)
                    built_instance = cls(**config_kwargs)
                else:
                    if inspect.isclass(cls):
                        built_instance = WrappedAgent(
                            name=_name,
                            description=description or _name,
                            wrapped_object=cls(),
                            default_execute_agent_function=default_execute_agent_function,
                        )
                    else:  # wrapped a function
                        # sig = inspect.signature(cls.__init__)
                        built_instance = WrappedAgent(
                            name=_name,
                            description=description or _name,
                            wrapped_object=cls,
                            default_execute_agent_function="wrapped_object",
                            **config_kwargs,
                        )
                # registry.register_agent(name=name, agent=instance)
            return built_instance

        registry.register_agent(name=_name, agent=_factory_method)
        return _factory_method

    return decorator


def llm_provider(
    name: str | None = None,
    model_name: str | None = None,
    **config_kwargs: Any,
) -> Callable[[type[BaseLLMProvider]], type[BaseLLMProvider]]:
    """
    Decorator to register an LLM provider class.

    Args:
        name: Override the LLM provider name
        model_name: Override the model name
        **config_kwargs: Additional configuration for the LLM provider

    Returns:
        Decorated LLM provider class that is automatically registered
    """

    def decorator(cls: type[T]) -> type[T]:
        # Ensure the class inherits from LLMProvider
        if not issubclass(cls, BaseLLMProvider):
            raise TypeError(f"Class {cls.__name__} must inherit from BaseLLMProvider")

        _name = name or cls.__name__
        _model_name = model_name or _name

        registry = get_llm_registry()

        built_instance = None

        # Set model_name in config
        config_kwargs["model_name"] = _model_name
        config_kwargs["name"] = _name

        def _factory_method(**kwargs) -> BaseLLMProvider:
            nonlocal built_instance
            if built_instance is None:
                config_kwargs.update(kwargs)
                built_instance = cls(**config_kwargs)
            return built_instance

        registry.register_llm_provider(name=_name, provider=_factory_method)
        return _factory_method

    return decorator


def hook(
    trigger: HookPhase,
    name: str | None = None,
    is_listener: bool = False,
    config_params: dict | None = None,
    input_fields: list[InputFields] | None = None,
    metadata: dict[str, Any] | None = None,
    on_event_triggers: list[ExecutionEventType] | None = None,
) -> Callable[[Callable[..., Any]], FunctionHook]:
    if config_params is None:
        config_params = {}
    if metadata is None:
        metadata = {}

    def decorator(
        fun: Callable,
    ) -> FunctionHook:
        hook_name = name or fun.__name__
        hook_object = FunctionHook(
            fun=fun,
            name=hook_name,
            trigger=trigger,
            config_params=config_params,
            input_fields=input_fields,
            metadata=metadata,
            type=HookType.LISTENER if is_listener else HookType.UPDATER,
            on_event_triggers=on_event_triggers,
        )
        get_hook_registry().register(name=hook_name, hook=hook_object)
        return hook_object

    return decorator
