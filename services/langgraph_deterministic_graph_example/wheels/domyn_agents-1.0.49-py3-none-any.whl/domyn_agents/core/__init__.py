# per ora metto tutto qui a cazzo

import uuid
from datetime import datetime
from enum import Enum
from functools import reduce
from operator import or_
from typing import Annotated, Any, ClassVar, Literal

from pydantic import BaseModel, Field, TypeAdapter, ValidationInfo, field_validator


# approval types feedback
class ApprovalType(Enum):
    USER_CONFIRM = "user_confirm"
    PARAMS_UPDATE = "params_update"
    # USER_INPUT = "user_input"  # TODO: da implementare dopo


# Actions


class BaseAction(BaseModel):
    """Azione di base per gli agenti"""

    # register subclasses
    _registry: ClassVar[dict[str, type["BaseAction"]]] = {}
    type: Literal["BaseAction"] = "BaseAction"

    name: str
    thought: str | None = None
    observation: Any | None = None
    message: str | None = None
    parameters: dict[str, Any] | None

    # auto-register sub types
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        tag = getattr(cls, "type", None)
        if tag is not None:
            BaseAction._registry[tag] = cls


class ToolAction(BaseAction):
    """Azione per eseguire un tool"""

    call_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: Literal["ToolAction"] = "ToolAction"


class AgentAction(BaseAction):
    """Azione per chiamare un sub-agent"""

    parameters: dict[str, Any]
    #    input_event: "BaseEvent"  # un evento per invocare un agente
    type: Literal["AgentAction"] = "AgentAction"


class StopAction(BaseAction):
    """Azione per terminare l'esecuzione"""

    type: Literal["StopAction"] = "StopAction"

    # serve tornare altro?


class FeedbackParameters(BaseModel):
    name: str = Field(..., description="Name of the parameter")
    value: Any = Field(..., description="Value of the parameter")
    type: str | None = Field(default=None, description="Type of the parameter")

    @field_validator("type", mode="before")
    @classmethod
    def val_x_before(cls, x):
        if isinstance(x, type):
            return x.__name__
        return x


class FeedbackAction(ToolAction):
    """Azione per fornire un feedback"""

    parameters: list[FeedbackParameters] = Field(default_factory=list)
    approval_type: ApprovalType
    approve: bool = True
    type: Literal["FeedbackAction"] = "FeedbackAction"

    def to_tool_action(self) -> ToolAction:
        params = self.model_dump()
        params.pop("type")
        params["parameters"] = {p.name: p.value for p in self.parameters}
        return ToolAction(**params)


class LLMCallAction(BaseAction):
    """Carries the LLM call payload when the planner delegates execution to the runner.

    Used by DelegateLLMProvider: the planner yields LLM_START with this action
    instead of calling the provider directly. The runner intercepts it, executes
    the LLM call (optionally streaming), and sends back an LLMResponse via asend().
    """

    type: Literal["LLMCallAction"] = "LLMCallAction"
    name: str = "llm_call"
    parameters: dict[str, Any] | None = None
    messages: list[Any]  # list[LLMMessage] — typed Any to avoid circular import
    tools: list[Any] | None = None
    stream: bool = False


ActionsTypes = reduce(or_, (BaseAction, *BaseAction._registry.values()))
Action = TypeAdapter(Annotated[ActionsTypes, Field(discriminator="type")])


# TODO da rivedere questa lista, se ne posso aggiungere altri
class ExecutionEventType(Enum):
    """Tipi di eventi durante l'esecuzione"""

    STARTED = "started"  # mai usato

    USER_INPUT = "user_input"
    # USER_FEEDBACK = "user_feedback" # only internal

    # tools
    TOOL_START = "tool_start"
    TOOL_NEEDS_FEEDBACK = "tool_needs_feedback"  # quello che esce
    TOOL_FEEDBACK = "tool_feedback"  # quello che rientra
    TOOL_ERROR = "tool_error"
    TOOL_END = "tool_end"
    TOOL_UPDATE = "tool_update"  # per tool che supportano aggiornamenti in streaming, ad esempio per indicare il progresso di esecuzione

    # hooks
    HOOK_START = "hook_start"
    HOOK_UPDATE = "hook_update"
    HOOK_END = "hook_end"
    HOOK_ERROR = "hook_error"

    # agents
    AGENT_CALL = "agent_call"
    AGENT_START = "agent_start"
    AGENT_END = "agent_end"

    # llms
    LLM_START = "llm_start"
    LLM_END = "llm_end"

    # response
    RESPONSE = "response"
    RESPONSE_TOKEN = "response_token"

    LLM_PROVIDER_ERROR = "llm_provider_error"  # errori lato llm_provider

    # errors
    ERROR_OCCURRED = "error_occurred"  # forse da rivedere se per i tool farli separati
    END = "end"


class GuardrailResult(BaseModel):
    name: str
    passed: bool
    score: float | None = None
    reason: str | None = None
    error_occurred: bool = False


class Part(BaseModel):
    text: str | None = Field(default=None, description="Text part")
    code: str | None = Field(default=None, description="Code part")
    thought: str | None = Field(default=None, description="Thought part")
    chart: str | None = Field(default=None, description="Chart part")
    metadata: dict | None = Field(default=None, description="Structured data part")
    guardrail_result: GuardrailResult | None = Field(
        default=None, description="Result of a Guardrail check"
    )
    # file_data: str | None = Field(default=None, description="File data part") # serve pure il mimetype e nome file
    # data: str | None = Field(default=None, description="Data part") # serve pure mime type
    # audio
    # immagini auto viaggi fogli di giornale


# Well-known metadata keys for BaseEvent.metadata
METADATA_FORWARD_VERBATIM = "forward_verbatim"
METADATA_FORWARD_VERBATIM_SOURCE_ID = "forward_verbatim_source_id"
METADATA_FORWARD_VERBATIM_SOURCE_KEY = "forward_verbatim_source_key"

# Generic agent-side failure surfaced through ERROR_OCCURRED events.
AGENT_ERROR_CODE = "AGENT_ERROR"
AGENT_ERROR_MESSAGE = "The agent encountered an error while responding."


class BaseEvent(BaseModel):
    event_type: ExecutionEventType
    author: str
    timestamp: datetime = Field(default_factory=datetime.now)
    event_id: str | None = Field(
        default_factory=lambda: f"event_{uuid.uuid4()}", description="Unique event ID"
    )
    conversation_id: str | None = Field(default=None, description="Conversation ID")
    interaction_id: str | None = Field(default=None, description="Interaction ID")
    turn_id: str | None = Field(
        default=None,
        description="Turn ID - uniquely identifies a single user-input turn across all agent transitions",
    )
    content: list[Part] = Field(default_factory=list, description="Event content parts")
    action: ActionsTypes | None = Field(default=None, description="Associated action")  # type: ignore

    # error info
    error_code: str | None = Field(default=None, description="Error code")
    error_message: str | None = Field(default=None, description="Error message")

    # da migliorare quando fermarsi oppure no

    # Per ora solo sugli eventi di tipo RESPONSE

    # is_partial: se True, l evento e' parziale e possiamo continuare il flusso, ad esempio per le risposte streaming
    is_partial: bool = Field(
        default=False, description="If the event is partial. If True, more events will follow"
    )

    # per i feedback, se True, l evento richiede un feedback dall utente (puo essere sia su una response che su un eventuale feedaback su un tool)
    # se false è una risposta finale
    need_feedback: bool = Field(default=False, description="If the event needs feedback from user")

    # other info
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata stored in event."
    )

    def model_post_init(self, context: Any, /) -> None:
        self.event_id = self.event_id or self._create_event_id()

    def to_dict(self) -> dict[str, Any]:
        """Converte l'evento in dizionario per serializzazione"""
        return self.model_dump()

    # factory from dict
    # def from_dict(cls, data: Dict[str, Any]) -> 'BaseEvent':
    #     """Crea un evento da un dizionario"""
    #     if 'event_type' in data and isinstance(data['event_type'], str):
    #         data['event_type'] = ExecutionEventType(data['event_type'])
    #     return cls(**data)
    # TODO: temporanea
    def prompt_print(self):
        content = " ".join([str(part) for part in self.content])
        return f"Author: {self.author} Content: {content} \n Action: {self.action!s}"

    def clone_with_author(self, author: str | None, interaction_id: str | None) -> "BaseEvent":
        e = self.model_copy()
        e.author = author if author else e.author
        e.interaction_id = interaction_id if interaction_id else e.interaction_id
        return e

    @field_validator("action", mode="before")
    def parse_action(cls, v: Any, info: ValidationInfo) -> BaseAction | None:
        if isinstance(v, str):
            return Action.validate_json(v)
        elif isinstance(v, dict):
            return Action.validate_python(v)
        return v


class AgentDescription(BaseModel):
    name: str = Field(..., description="Name of the agent")
    description: str = Field(..., description="Description of the agent")
    invocation_json_schema: dict[str, Any] | None = Field(
        ..., description="JSON schema for invoking the agent"
    )
    invocation_parameters: dict[str, Any] | None = Field(
        ..., description="Example parameters for invoking the agent"
    )


class RelayMessage(BaseModel):
    meta: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata for delegation"
    )
    payload: BaseEvent = Field(..., description="The event to delegate")


__all__ = [
    "AgentDescription",
    "ApprovalType",
    "BaseAction",
    "BaseEvent",
    "ExecutionEventType",
    "LLMCallAction",
    "ToolAction",
]
