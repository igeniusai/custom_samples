import asyncio
import inspect
from collections.abc import AsyncGenerator, Callable
from importlib import machinery, util
from typing import Any


def load_function_from_file(name: str, path: str) -> Callable:
    """Load a function from a Python file."""

    spec = util.spec_from_file_location(name, path, loader=machinery.SourceFileLoader(name, path))
    _module = util.module_from_spec(spec)
    spec.loader.exec_module(_module)
    # path = Path(path).relative_to(Path(domyn_agents.__path__[0]).parent)
    # module_path = str(path).strip(".py").replace("/", ".").replace("\\", ".")
    # _module = getattr(import_module(path), name)
    _module = getattr(_module, name)
    # _module.__module__ = module_path
    if not _module:
        raise ValueError(f"Function {name} not found in {path}")
    return _module


def validate_parameter_keys(fn: Callable, mandatory_keys: set[str]) -> None:
    sig = inspect.signature(fn)
    param_keys = set(sig.parameters.keys())
    if not mandatory_keys.issubset(param_keys):
        missing_keys = mandatory_keys - param_keys
        raise ValueError(f"Function {fn.__name__} is missing expected parameters: {missing_keys}.")


async def execute_async(fn: Callable, **kwargs):
    if not inspect.iscoroutinefunction(fn):
        context = await asyncio.to_thread(fn, **kwargs)
    else:
        context = await fn(**kwargs)
    return context


def wrap_as_async_generator(fn: Callable) -> Callable[..., AsyncGenerator]:
    if inspect.isasyncgenfunction(fn):
        return fn
    elif inspect.iscoroutinefunction(fn):

        async def inner(*args, **kwargs):
            yield await fn(*args, **kwargs)

        inner.__name__ = getattr(fn, "__name__", "inner")
        return inner
    else:

        async def inner(*args, **kwargs):
            yield await asyncio.to_thread(fn, *args, **kwargs)

        inner.__name__ = getattr(fn, "__name__", "inner")
        return inner


def serialize_callable(value: Any) -> dict[str, Any]:
    if hasattr(value, "__module__") and hasattr(value, "__name__"):
        return {
            "type": "function",
            "module": value.__module__,
            "name": value.__name__,
            "qualname": getattr(value, "__qualname__", value.__name__),
            "doc": value.__doc__,
            "path": inspect.getfile(value) if inspect.isfunction(value) else None,
        }
    elif hasattr(value, "__class__"):
        return {
            "type": "callable_object",
            "class": value.__class__.__name__,
            "module": value.__class__.__module__,
            "repr": repr(value),
            "doc": getattr(value, "__doc__", None),
            "path": inspect.getfile(value) if inspect.isfunction(value) else None,
        }
    else:
        return {"type": "unknown_callable", "repr": repr(value), "str": str(value)}


SerializedCallable = dict[str, Any]
