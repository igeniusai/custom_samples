"""Context management for agent interactions."""

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field
from ulid import ULID

from domyn_agents.core import AgentDescription, BaseEvent


class InteractionContext(BaseModel):
    """Context for a single interaction session."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    conversation_id: str
    user_id: str
    interaction_id: str | None = Field(
        default=None, description="Unique interaction ID | Auto generated if not provided"
    )
    turn_id: str | None = Field(
        default=None,
        description="Turn ID - uniquely identifies a single user-input turn across all agent transitions",
    )
    agent_input: BaseEvent = Field(
        description=(
            "Current input/task for this interaction — USER_INPUT for the entrypoint, "
            "AGENT_START for sub-agents and after handoff/tool-feedback"
        )
    )
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)

    interaction_history: list[BaseEvent] = Field(
        default_factory=list, description="tutti gli eventi della interazione"
    )

    conversation_history: list[BaseEvent] = Field(
        default_factory=list, description="tutti gli eventi della conversazione"
    )
    agents_visibility_description: list[AgentDescription] = Field(default_factory=list)
    # parent_agent_name: str | None = Field(default=None, description="Parent agent name if any")

    # Memory provider for key-value storage
    # memory: MemoryProvider = Field(default_factory=InMemoryProvider, exclude=True)

    # TODO: artifact provider

    # Additional metadata
    # metadata: dict[str, Any] = Field(default_factory=dict)

    # deve avere lista di eventi passati
    # oggetto per clonarsi
    # metodo per filtrare dato il nome

    # stato modificabile
    state: dict[str, Any] = Field(default_factory=dict)

    # config read only, TODO: check read only
    run_config: dict[str, Any] = Field(default_factory=dict)

    def model_post_init(self, context: Any, /) -> None:
        if self.interaction_id is None:
            self.interaction_id = self.generate_interaction_id()

    @staticmethod
    def generate_interaction_id() -> str:
        """Generate a unique interaction ID."""
        return f"interaction_{uuid.uuid4().hex}"

    @staticmethod
    def generate_turn_id() -> str:
        """Generate a unique, sortable turn ID using ULID."""
        return str(ULID())

    @property
    def last_event(self) -> BaseEvent | None:
        """Get the last event in the interaction history."""
        return self.interaction_history[-1] if self.interaction_history else None
