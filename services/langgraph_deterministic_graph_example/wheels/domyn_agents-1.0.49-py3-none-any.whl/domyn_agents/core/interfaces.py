"""Interfacce base per evitare import circolari.

Questo modulo contiene solo le classi base e interfacce astratte
senza dipendenze concrete, seguendo il principio di inversione delle dipendenze.
"""

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from pydantic import BaseModel, Field


class BaseHook(ABC, BaseModel):
    """Classe base per tutti gli hook."""

    name: str | None = Field(default=None, description="Unique name of the LLM provider instance")

    @abstractmethod
    async def run(self, *args, **kwargs) -> Any:
        """Esegue l'hook."""
        ...


class BaseUpdaterHook(BaseHook):
    """Classe base per hook che modificano/trasformano dati."""

    @abstractmethod
    async def run(self, *args, **kwargs) -> Any:
        """Esegue l'hook e ritorna dati modificati."""
        ...


class BaseListenerHook(BaseHook):
    """Classe base per hook che ascoltano ma non modificano dati."""

    @abstractmethod
    async def run(self, *args, **kwargs) -> None:
        """Esegue l'hook senza ritornare dati."""
        ...


class BaseAgent(BaseModel):
    """Classe base per tutti gli agenti."""

    type: str = "BaseAgent"

    name: str = Field(..., description="Name of the agent")
    description: str = Field(..., description="Description of the agent")

    sub_agents: list["BaseAgent"] = []  # Lista di nomi degli agenti
    name_string: ClassVar[str] = "name"
    parameters_string: ClassVar[str] = "arguments"
    stream: bool = False


BaseAgent.model_rebuild()
