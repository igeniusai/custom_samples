import json
import time
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import httpx
from pydantic import Field

from domyn_agents.llm.base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    LLMToolCall,
    StructuredOutput,
    StructuredOutputType,
    ToolCallFunction,
)
from domyn_agents.logger import get_logger
from domyn_agents.tracing import inject_trace_headers


class VLLMProvider(BaseLLMProvider):
    """Provider for LLM hosted on vLLM (using openai API)"""

    type: str = "vllm"
    url: str = Field(..., description="URL of the VLLM server")
    api_key: str | None = Field(default=None, description="API key for authentication")
    supported_structured_outputs: list[StructuredOutputType] | None = Field(
        default=[
            StructuredOutputType.LLGUIDANCE,
            StructuredOutputType.GBNF,
        ],
        description="Supported structured output types",
    )

    default_generation_params: ClassVar[dict[str, Any]] = {
        "temperature": 0.7,
        "max_tokens": 2000,
    }

    generation_params: dict[str, Any] = Field(
        default_factory=lambda: {"temperature": 0.7, "max_tokens": 2000},
        description="Generation parameters for the model",
    )

    def model_post_init(self, context: Any, /) -> None:
        if not self.name:
            self.name = self.model_name

    def preprocess_structured_outputs(
        self, structured_outputs: StructuredOutput | None = None
    ) -> dict:
        if structured_outputs is None:
            structured_outputs_params = {}
        else:
            match structured_outputs.type:
                case StructuredOutputType.LLGUIDANCE:
                    structured_outputs_params = {
                        "structured_outputs": {
                            "grammar": structured_outputs.rules,
                            "_backend": "guidance",
                        }
                    }
                case StructuredOutputType.GBNF:
                    structured_outputs_params = {
                        "structured_outputs": {
                            "grammar": structured_outputs.rules,
                            "_backend": "xgrammar",
                        }
                    }
                case StructuredOutputType.JSON_SCHEMA:
                    raise NotImplementedError  # Todo: implementare
                case _:
                    raise ValueError(
                        f"Unsupported structured output type: {structured_outputs.type}"
                    )

        return structured_outputs_params

    async def generate(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call vLLM API"""
        logger = get_logger()

        structured_outputs_params = self.preprocess_structured_outputs(structured_outputs)

        start = time.time()
        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        if self.append_text_system_prompt:
            messages[0].content += "\n" + self.append_text_system_prompt

        if self.append_text_last_message:
            messages[-1].content += "\n" + self.append_text_last_message

        payload = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
        }
        payload = {**payload, **self.generation_params, **kwargs} | structured_outputs_params

        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        # inject trace headers if tracing is enabled
        headers = inject_trace_headers(headers)

        logger.info(f"[Inference Request]: {self.url}", payload=payload)

        # TODO: client iniettato dall esterno
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()

            full_output = data["choices"][0]["message"]["content"]
            token_count = data["usage"]["completion_tokens"]

            tool_calls: list[LLMToolCall] = []
            for tc in data["choices"][0]["message"].get("tool_calls") or []:
                tool_calls.append(
                    LLMToolCall(
                        id=tc["id"],
                        type=tc.get("type", "function"),
                        function=ToolCallFunction(
                            name=tc["function"]["name"],
                            arguments=tc["function"]["arguments"],
                        ),
                    )
                )

            logger.info(
                f"[Inference Response]: {self.url}",
                payload={
                    "response": full_output,
                    "generated_tokens": token_count,
                    "execution_time": time.time() - start,
                    "tool_calls": [tc.model_dump() for tc in tool_calls],
                },
            )
            return LLMResponse(
                content=full_output or "",
                usage=data.get("usage", {}),
                generated_tokens=token_count,
                reasoning_content=data["choices"][0]["message"].get("reasoning_content")
                or data["choices"][0]["message"].get("reasoning", None),
                execution_time=time.time() - start,
                tool_calls=tool_calls,
            )

    async def generate_streaming(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[LLMResponse, None]:
        """Call vLLM API with true token-by-token streaming."""
        logger = get_logger()

        structured_outputs_params = self.preprocess_structured_outputs(structured_outputs)

        start = time.time()
        headers = {
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        payload = {**payload, **self.generation_params, **kwargs} | structured_outputs_params

        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        # inject trace headers if tracing is enabled
        headers = inject_trace_headers(headers)

        logger.info(f"[Inference Stream Request]: {self.url}", payload=payload)

        token_count = 0
        full_output = ""

        # Accumulator for streaming tool-call deltas, keyed by their index.
        # Each entry: {"id": str, "type": str, "name": str, "arguments": str}
        tool_call_acc: dict[int, dict] = {}
        reasoning = ""

        # Use client.stream() so httpx yields chunks as they arrive instead of
        # buffering the entire response body before returning.
        async with (
            httpx.AsyncClient(timeout=60.0) as client,
            client.stream("POST", self.url, headers=headers, json=payload) as response,
        ):
            response.raise_for_status()
            async for chunk in response.aiter_bytes():
                if chunk:
                    for c in chunk.decode("utf-8").split("data:"):
                        c = c.strip()
                        if c and c != "[DONE]":
                            try:
                                data = json.loads(c)
                                if not data["choices"]:
                                    continue
                                delta = data["choices"][0]["delta"]

                                # --- tool-call delta accumulation ---
                                for tc_delta in delta.get("tool_calls") or []:
                                    idx = tc_delta["index"]
                                    if idx not in tool_call_acc:
                                        tool_call_acc[idx] = {
                                            "id": tc_delta.get("id", ""),
                                            "type": tc_delta.get("type", "function"),
                                            "name": tc_delta.get("function", {}).get("name", ""),
                                            "arguments": "",
                                        }
                                    else:
                                        # id/type/name only arrive in the first chunk
                                        if tc_delta.get("id"):
                                            tool_call_acc[idx]["id"] = tc_delta["id"]
                                        if tc_delta.get("type"):
                                            tool_call_acc[idx]["type"] = tc_delta["type"]
                                        if tc_delta.get("function", {}).get("name"):
                                            tool_call_acc[idx]["name"] = tc_delta["function"][
                                                "name"
                                            ]
                                    # arguments arrive in pieces — always concatenate
                                    tool_call_acc[idx]["arguments"] += tc_delta.get(
                                        "function", {}
                                    ).get("arguments", "")

                                # --- reasoning delta accumulation ---
                                if delta.get("reasoning"):
                                    reasoning += delta.get("reasoning")

                                # --- text content ---
                                content = delta.get("content", "").replace("\x00", "")
                                if content:
                                    token_count += 1
                                    full_output += content
                                    yield LLMResponse(
                                        content=content,
                                        usage={},
                                        generated_tokens=token_count,
                                        execution_time=time.time() - start,
                                    )
                            except json.JSONDecodeError:
                                pass

        # Build final LLMToolCall objects from the accumulated deltas
        tool_calls: list[LLMToolCall] = [
            LLMToolCall(
                id=acc["id"],
                type=acc["type"],
                function=ToolCallFunction(
                    name=acc["name"],
                    arguments=acc["arguments"],
                ),
            )
            for acc in tool_call_acc.values()
        ]

        # If there were tool calls, yield one final response carrying them all
        if tool_calls:
            yield LLMResponse(
                content="",
                usage={},
                generated_tokens=token_count,
                execution_time=time.time() - start,
                tool_calls=tool_calls,
                reasoning_content=reasoning or None,
            )

        logger.info(
            f"[Inference Response]: {self.url}",
            payload={
                "response": full_output,
                "generated_tokens": token_count,
                "execution_time": time.time() - start,
                "tool_calls": [tc.model_dump() for tc in tool_calls],
            },
        )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "VLLMProvider":
        required = ["url", "model_name"]
        missing = [k for k in required if k not in config]
        if missing:
            raise ValueError(f"Missing required VLLMProvider config keys: {missing}")
        return cls(
            url=config["url"],
            model_name=config["model_name"],
            generation_params=config.get("generation_params")
            or {"temperature": 0.7, "max_tokens": 2000},
            api_key=config.get("api_key"),
            name=config.get("name") or config["model_name"],
            append_text_last_message=config.get("append_text_last_message"),
            append_text_system_prompt=config.get("append_text_system_prompt"),
        )
