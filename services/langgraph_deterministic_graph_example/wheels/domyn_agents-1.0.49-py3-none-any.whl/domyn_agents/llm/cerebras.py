import asyncio
import json
import os
import time
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import httpx
from pydantic import Field

from domyn_agents.llm.base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    LLMToolCall,
    StructuredOutput,
    StructuredOutputType,
    ToolCallFunction,
)
from domyn_agents.logger import get_logger


class CerebrasProvider(BaseLLMProvider):
    """Provider for LLM hosted on Cerebras"""

    type: str = "cerebras"
    url: str = Field(
        default="https://api.cerebras.ai/v1/chat/completions",
        description="URL of the Cerebras server",
    )
    api_key: str = Field(
        default=os.getenv("CEREBRAS_API_KEY"), description="API key for authentication"
    )

    default_generation_params: ClassVar[dict[str, Any]] = {
        "temperature": 0.7,
        "max_tokens": 8000,
    }

    generation_params: dict[str, Any] = Field(
        default_factory=lambda: {"temperature": 0.7, "max_tokens": 8000},
        description="Generation parameters for the model",
    )

    supported_structured_outputs: list[StructuredOutputType] | None = Field(
        default=None,  # [StructuredOutputType.JSON_SCHEMA], TODO: CEREBRAS STRUCTURED OUTPUTS STOPPED WORKING
        description="Supported structured output types",
    )
    max_retries: int = Field(default=3, description="Maximum number of retries for API calls")

    def model_post_init(self, context: Any, /) -> None:
        if not self.name:
            self.name = self.model_name
        if self.api_key is None:
            raise ValueError(f"API key must be provided for OpenRouterProvider: {self.model_name}")

    @staticmethod
    def preprocess_structured_outputs(
        structured_outputs: StructuredOutput | None,
    ) -> dict[str, Any]:
        if structured_outputs is None:
            structured_outputs_params = {}
        else:
            match structured_outputs.type:
                case StructuredOutputType.JSON_SCHEMA:
                    structured_outputs_params = {
                        "response_format": {
                            "type": "json_schema",
                            "json_schema": {
                                "name": "agent_step",
                                "strict": True,
                                "schema": structured_outputs.rules,
                            },
                        }
                    }
                case _:
                    raise ValueError(
                        f"Structured output type {structured_outputs.type} not supported by CerebrasProvider"
                    )
        return structured_outputs_params

    async def generate(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call vLLM API"""
        logger = get_logger()

        structured_outputs_params = self.preprocess_structured_outputs(
            structured_outputs=structured_outputs
        )

        start = time.time()
        headers = {
            "Content-Type": "application/json",
        }
        headers["Authorization"] = f"Bearer {self.api_key}"

        if self.append_text_system_prompt:
            messages[0].content += "\n" + self.append_text_system_prompt

        if self.append_text_last_message:
            messages[-1].content += "\n" + self.append_text_last_message

        payload: dict[str, Any] = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
        } | structured_outputs_params
        payload = {**payload, **self.generation_params}

        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Request]: {self.url}", payload=payload)

        # TODO: client iniettato dall esterno
        async with httpx.AsyncClient(timeout=60.0) as client:
            count = 0
            while count < self.max_retries:  # fix for cerebras that return invalid json response
                response = await client.post(self.url, headers=headers, json=payload)
                response.raise_for_status()
                data = json.loads(response.text.strip())

                if not data:
                    await asyncio.sleep(0.5)  # wait a bit before retrying
                    count += 1
                    continue

                message_data = data["choices"][0]["message"]
                content = message_data.get("content") or ""

                tool_calls: list[LLMToolCall] = []
                for tc in message_data.get("tool_calls") or []:
                    tool_calls.append(
                        LLMToolCall(
                            id=tc["id"],
                            type=tc.get("type", "function"),
                            function=ToolCallFunction(
                                name=tc["function"]["name"],
                                arguments=tc["function"]["arguments"],
                            ),
                        )
                    )

                if content or tool_calls:
                    logger.info(
                        f"[Inference Response]: {self.url}",
                        payload={
                            "response": content,
                            "generated_tokens": data.get("usage", {}).get("completion_tokens", 0),
                            "execution_time": time.time() - start,
                            "tool_calls": [tc.model_dump() for tc in tool_calls],
                        },
                    )
                    return LLMResponse(
                        content=content,
                        usage=data.get("usage", {}),
                        generated_tokens=data.get("usage", {}).get("completion_tokens", 0),
                        reasoning_content=data["choices"][0]["message"].get("reasoning_content")
                        or data["choices"][0]["message"].get("reasoning", None),
                        execution_time=time.time() - start,
                        tool_calls=tool_calls,
                    )

                count += 1

    async def generate_streaming(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[LLMResponse, None]:
        """Call Cerebras API with streaming support"""
        logger = get_logger()

        structured_outputs_params = self.preprocess_structured_outputs(
            structured_outputs=structured_outputs
        )

        start = time.time()
        headers = {
            "Content-Type": "application/json",
        }
        headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
            "stream": True,
            "stream_options": {"include_usage": True},
        } | structured_outputs_params
        payload = {**payload, **self.generation_params, **kwargs}
        payload.pop(
            "add_generation_prompt", None
        )  # TODO: PICCONATA streaming doesn't support add_generation_prompt?

        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Stream Request]: {self.url}", payload=payload)

        token_count = 0
        full_output = ""

        # Accumulator for streaming tool-call deltas, keyed by their index.
        # Each entry: {"id": str, "type": str, "name": str, "arguments": str}
        tool_call_acc: dict[int, dict] = {}
        reasoning = ""

        # TODO: client iniettato dall esterno
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()
            async for chunk in response.aiter_bytes():
                if chunk:
                    for c in chunk.decode("utf-8").split("data:"):
                        c = c.strip()
                        if c and c != "[DONE]":
                            try:
                                data = json.loads(c)
                                delta = data["choices"][0]["delta"]

                                # --- tool-call delta accumulation ---
                                for tc_delta in delta.get("tool_calls") or []:
                                    idx = tc_delta["index"]
                                    if idx not in tool_call_acc:
                                        tool_call_acc[idx] = {
                                            "id": tc_delta.get("id", ""),
                                            "type": tc_delta.get("type", "function"),
                                            "name": tc_delta.get("function", {}).get("name", ""),
                                            "arguments": "",
                                        }
                                    else:
                                        if tc_delta.get("id"):
                                            tool_call_acc[idx]["id"] = tc_delta["id"]
                                        if tc_delta.get("type"):
                                            tool_call_acc[idx]["type"] = tc_delta["type"]
                                        if tc_delta.get("function", {}).get("name"):
                                            tool_call_acc[idx]["name"] = tc_delta["function"][
                                                "name"
                                            ]
                                    tool_call_acc[idx]["arguments"] += tc_delta.get(
                                        "function", {}
                                    ).get("arguments", "")

                                # --- reasoning delta accumulation ---
                                if delta.get("reasoning"):
                                    reasoning += delta.get("reasoning")

                                # --- text content ---
                                content = delta.get("content", "").replace("\x00", "")
                                if content:
                                    token_count += 1
                                    full_output += content
                                    yield LLMResponse(
                                        content=content,
                                        usage={},
                                        generated_tokens=token_count,
                                        execution_time=time.time() - start,
                                    )
                            except json.JSONDecodeError:
                                pass

        # Build final LLMToolCall objects from the accumulated deltas
        tool_calls: list[LLMToolCall] = [
            LLMToolCall(
                id=acc["id"],
                type=acc["type"],
                function=ToolCallFunction(
                    name=acc["name"],
                    arguments=acc["arguments"],
                ),
            )
            for acc in tool_call_acc.values()
        ]

        # If there were tool calls, yield one final response carrying them all
        if tool_calls:
            yield LLMResponse(
                content="",
                usage={},
                generated_tokens=token_count,
                execution_time=time.time() - start,
                tool_calls=tool_calls,
                reasoning_content=reasoning or None,
            )

        logger.info(
            f"[Inference Response]: {self.url}",
            payload={
                "response": full_output,
                "generated_tokens": token_count,
                "execution_time": time.time() - start,
                "tool_calls": [tc.model_dump() for tc in tool_calls],
            },
        )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "CerebrasProvider":
        required = ["url", "model_name"]
        missing = [k for k in required if k not in config]
        if missing:
            raise ValueError(f"Missing required Cerebras config keys: {missing}")
        return cls(
            url=config["url"],
            model_name=config["model_name"],
            generation_params=config.get("generation_params")
            or {"temperature": 0.7, "max_tokens": 2000},
            api_key=config.get("api_key"),
            name=config.get("name") or config["model_name"],
            append_text_last_message=config.get("append_text_last_message"),
            append_text_system_prompt=config.get("append_text_system_prompt"),
        )
