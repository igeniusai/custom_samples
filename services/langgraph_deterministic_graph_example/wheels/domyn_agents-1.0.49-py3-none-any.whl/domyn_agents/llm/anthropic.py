"""Anthropic LLM Provider implementation using httpx."""

import json
import os
import time
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import httpx
from pydantic import Field

from domyn_agents.llm.base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    LLMToolCall,
    StructuredOutput,
    StructuredOutputType,
    ToolCallFunction,
)
from domyn_agents.logger import get_logger


class AnthropicProvider(BaseLLMProvider):
    """Provider for Anthropic Claude models"""

    type: str = "anthropic"
    url: str = Field(
        default="https://api.anthropic.com/v1/messages",
        description="API endpoint URL",
    )
    api_key: str | None = Field(
        default_factory=lambda: os.getenv("ANTHROPIC_API_KEY"),
        description="API key for Anthropic authentication",
    )

    default_generation_params: ClassVar[dict[str, Any]] = {
        "temperature": 1.0,
        "max_tokens": 4096,
        "top_k": None,
    }

    generation_params: dict[str, Any] = Field(
        default_factory=lambda: {
            "temperature": 1.0,
            "max_tokens": 4096,
            "top_k": None,
        },
        description="Generation parameters for the model",
    )

    supported_structured_outputs: list[StructuredOutputType] | None = Field(
        default=None, description="Supported structured output types"
    )

    def model_post_init(self, context: Any, /) -> None:
        """Initialize the provider after model creation."""
        if not self.name:
            self.name = self.model_name
        if not self.api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY environment variable or api_key parameter is required"
            )

    @staticmethod
    def _convert_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert OpenAI-format tool definitions to Anthropic format."""
        anthropic_tools = []
        for tool in tools:
            func = tool.get("function", {})
            anthropic_tools.append(
                {
                    "name": func.get("name", ""),
                    "description": func.get("description", ""),
                    "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        return anthropic_tools

    def _convert_messages(
        self, messages: list[LLMMessage]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """
        Convert LLMMessage format to Anthropic format.

        Anthropic requires system messages to be separate from the messages list.
        Handles tool-use messages: assistant messages with tool_calls become content
        blocks with type "tool_use", and tool result messages become user messages
        with type "tool_result" content blocks.

        Returns (system_prompt, messages_list)
        """
        system_prompt = None
        anthropic_messages: list[dict[str, Any]] = []

        for msg in messages:
            if msg.role == "system":
                content_str = (
                    msg.content if isinstance(msg.content, str) else str(msg.content or "")
                )
                if system_prompt is None:
                    system_prompt = content_str
                else:
                    system_prompt += "\n\n" + content_str

            elif msg.role == "assistant" and msg.tool_calls:
                # Assistant message with tool calls → Anthropic content blocks
                content_blocks: list[dict[str, Any]] = []
                if msg.content:
                    text = msg.content if isinstance(msg.content, str) else str(msg.content)
                    if text.strip():
                        content_blocks.append({"type": "text", "text": text})
                for tc in msg.tool_calls:
                    args = tc.function.arguments
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc.id,
                            "name": tc.function.name,
                            "input": json.loads(args) if isinstance(args, str) else args,
                        }
                    )
                anthropic_messages.append({"role": "assistant", "content": content_blocks})

            elif msg.role == "tool":
                # Tool result → Anthropic user message with tool_result content block
                content_str = (
                    msg.content if isinstance(msg.content, str) else str(msg.content or "")
                )
                tool_result_block: dict[str, Any] = {
                    "type": "tool_result",
                    "tool_use_id": msg.tool_call_id,
                    "content": content_str,
                }
                # Merge consecutive tool results into a single user message
                if (
                    anthropic_messages
                    and anthropic_messages[-1]["role"] == "user"
                    and isinstance(anthropic_messages[-1]["content"], list)
                    and anthropic_messages[-1]["content"]
                    and anthropic_messages[-1]["content"][0].get("type") == "tool_result"
                ):
                    anthropic_messages[-1]["content"].append(tool_result_block)
                else:
                    anthropic_messages.append(
                        {
                            "role": "user",
                            "content": [tool_result_block],
                        }
                    )

            else:
                # Regular user/assistant message
                if isinstance(msg.content, list):
                    anthropic_messages.append({"role": msg.role, "content": msg.content})
                else:
                    content_str = (msg.content or "").strip()
                    if content_str:
                        anthropic_messages.append({"role": msg.role, "content": content_str})

        return system_prompt, anthropic_messages

    async def generate(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate content using Anthropic API with httpx"""
        logger = get_logger()
        start = time.time()

        # Prepare headers
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

        # Convert messages to Anthropic format
        system_prompt, anthropic_messages = self._convert_messages(messages)

        params = {**self.generation_params}
        params = {k: v for k, v in params.items() if v is not None}

        # Build request parameters
        payload: dict[str, Any] = {
            "model": self.model_name,
            "messages": anthropic_messages,
            **params,
        }

        # Add system prompt if present
        if system_prompt:
            payload["system"] = system_prompt

        # Add tools if present
        if tools:
            payload["tools"] = self._convert_tools(tools)
        if tool_choice is not None:
            if isinstance(tool_choice, str):
                payload["tool_choice"] = {"type": tool_choice}
            else:
                payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Request]: {self.url}", payload=payload)

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()

            # Extract content, tool calls, and thinking blocks from response
            content = ""
            tool_calls: list[LLMToolCall] = []
            thinking_blocks: list[dict[str, Any]] = []

            for block in data.get("content", []):
                block_type = block.get("type")
                if block_type == "text":
                    content += block.get("text", "")
                elif block_type == "tool_use":
                    tool_calls.append(
                        LLMToolCall(
                            id=block["id"],
                            type="function",
                            function=ToolCallFunction(
                                name=block["name"],
                                arguments=json.dumps(block.get("input", {})),
                            ),
                        )
                    )
                elif block_type == "thinking":
                    thinking_blocks.append(
                        {
                            "type": "thinking",
                            "thinking": block.get("thinking", ""),
                        }
                    )

            # Extract usage information
            usage_data = data.get("usage", {})
            usage = {
                "input_tokens": usage_data.get("input_tokens", 0),
                "output_tokens": usage_data.get("output_tokens", 0),
            }

            logger.info(
                f"[Inference Response]: {self.url}",
                payload={
                    "response": content,
                    "generated_tokens": usage_data.get("output_tokens", 0),
                    "execution_time": time.time() - start,
                    "tool_calls": [tc.model_dump() for tc in tool_calls],
                },
            )

            return LLMResponse(
                content=content,
                usage=usage,
                generated_tokens=usage_data.get("output_tokens", 0),
                execution_time=time.time() - start,
                tool_calls=tool_calls,
                thinking_blocks=thinking_blocks if thinking_blocks else None,
            )

    async def generate_streaming(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[LLMResponse, None]:
        """Generate content with streaming using Anthropic API with httpx"""
        logger = get_logger()
        start = time.time()

        # Prepare headers
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

        # Convert messages to Anthropic format
        system_prompt, anthropic_messages = self._convert_messages(messages)

        # TODO: Implement grammar handling
        params = {**self.generation_params}
        params = {k: v for k, v in params.items() if v is not None}

        # Build request parameters
        payload: dict[str, Any] = {
            "model": self.model_name,
            "messages": anthropic_messages,
            "stream": True,
            **params,
        }

        # Add system prompt if present
        if system_prompt:
            payload["system"] = system_prompt

        # Add tools if present (converting from OpenAI format)
        if tools:
            payload["tools"] = self._convert_tools(tools)
        if tool_choice is not None:
            if isinstance(tool_choice, str):
                payload["tool_choice"] = {"type": tool_choice}
            else:
                payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Stream Request]: {self.url}", payload=payload)

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()

            token_count = 0
            usage_info: dict[str, Any] = {}
            event_type = None

            # Accumulator for streaming tool-call deltas, keyed by content-block index.
            # Anthropic sends: content_block_start (id+name), then content_block_delta
            # with input_json_delta (partial arguments JSON string).
            # Each entry: {"id": str, "name": str, "arguments": str}
            tool_call_acc: dict[int, dict] = {}

            try:
                async for line in response.aiter_lines():
                    line = line.strip()

                    # Parse SSE format
                    if line.startswith("event: "):
                        event_type = line[7:]
                    elif line.startswith("data: "):
                        try:
                            data = json.loads(line[6:])

                            # content_block_start → may open a tool_use block
                            if event_type == "content_block_start":
                                block = data.get("content_block", {})
                                idx = data.get("index", 0)
                                if block.get("type") == "tool_use":
                                    tool_call_acc[idx] = {
                                        "id": block.get("id", ""),
                                        "name": block.get("name", ""),
                                        "arguments": "",
                                    }

                            # content_block_delta → text token or arguments fragment
                            elif event_type == "content_block_delta":
                                delta = data.get("delta", {})
                                idx = data.get("index", 0)

                                if delta.get("type") == "text_delta":
                                    text = delta.get("text", "").replace("\x00", "")
                                    if text:
                                        token_count += 1
                                        yield LLMResponse(
                                            content=text,
                                            usage=usage_info,
                                            generated_tokens=token_count,
                                            execution_time=time.time() - start,
                                        )

                                elif delta.get("type") == "input_json_delta":
                                    # Accumulate partial JSON for the tool call at this index
                                    if idx in tool_call_acc:
                                        tool_call_acc[idx]["arguments"] += delta.get(
                                            "partial_json", ""
                                        )

                            # message_delta → usage stats
                            elif event_type == "message_delta":
                                usage = data.get("usage", {})
                                if usage:
                                    usage_info["output_tokens"] = usage.get("output_tokens", 0)

                        except json.JSONDecodeError:
                            # Skip malformed JSON
                            pass

            except Exception as ex:
                raise ex

        # Build final LLMToolCall objects from the accumulated deltas
        tool_calls: list[LLMToolCall] = [
            LLMToolCall(
                id=acc["id"],
                type="function",
                function=ToolCallFunction(
                    name=acc["name"],
                    arguments=acc["arguments"],
                ),
            )
            for acc in tool_call_acc.values()
        ]

        # If there were tool calls, yield one final response carrying them all
        if tool_calls:
            yield LLMResponse(
                content="",
                usage=usage_info,
                generated_tokens=token_count,
                execution_time=time.time() - start,
                tool_calls=tool_calls,
            )

        logger.info(
            f"[Inference Response]: {self.url}",
            payload={
                "generated_tokens": token_count,
                "execution_time": time.time() - start,
                "tool_calls": [tc.model_dump() for tc in tool_calls],
            },
        )
