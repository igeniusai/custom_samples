"""LLM provider system for domyn agents framework."""

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from enum import StrEnum, auto
from typing import Any, ClassVar

from pydantic import BaseModel, Field, model_validator


class StructuredOutputType(StrEnum):
    JSON_SCHEMA = auto()
    LARK = auto()
    GBNF = auto()
    LLGUIDANCE = auto()


class StructuredOutput(BaseModel):
    type: StructuredOutputType
    rules: dict | str


class ToolCallFunction(BaseModel):
    """Function details within a tool call."""

    name: str = Field(..., description="Name of the function to call")
    arguments: str = Field(..., description="JSON-encoded arguments for the function")


class LLMToolCall(BaseModel):
    """A tool call request from the LLM."""

    id: str = Field(..., description="Unique identifier for this tool call")
    type: str = Field(default="function", description="Type of tool call")
    function: ToolCallFunction = Field(..., description="Function to call")


class LLMMessage(BaseModel):
    """Message structure for LLM communication."""

    role: str = Field(..., description="Role of the message sender (system, user, assistant, tool)")
    content: str | list[dict[str, Any]] | None = Field(
        default=None, description="Content of the message"
    )
    tool_calls: list[LLMToolCall] | None = Field(
        default=None, description="Tool calls made by the assistant"
    )
    tool_call_id: str | None = Field(
        default=None, description="ID of the tool call this message is a result for"
    )
    name: str | None = Field(default=None, description="Tool name for tool result messages")

    def to_dict(self) -> dict[str, Any]:
        """Convert message to a dictionary format suitable for LLM input."""
        result: dict[str, Any] = {"role": self.role}
        if self.content is not None:
            result["content"] = self.content
        if self.tool_calls:
            result["tool_calls"] = [call.model_dump() for call in self.tool_calls]
        if self.tool_call_id is not None:
            result["tool_call_id"] = self.tool_call_id
        if self.name is not None:
            result["name"] = self.name
        return result


class LLMResponse(BaseModel):
    """Response from LLM provider."""

    content: str = Field(..., description="Generated content")
    usage: dict[str, Any] = Field(default_factory=dict, description="Usage statistics")
    generated_tokens: int
    execution_time: float  # in seconds
    tool_calls: list[LLMToolCall] = Field(
        default_factory=list, description="Tool calls requested by the LLM"
    )
    reasoning_content: str | None = Field(
        default=None, description="Reasoning content (DeepSeek R1, Kimi)"
    )
    thinking_blocks: list[dict[str, Any]] | None = Field(
        default=None, description="Thinking blocks (Anthropic extended thinking)"
    )


class BaseLLMProvider(BaseModel, ABC):
    """Abstract base class for LLM providers."""

    type: str = "base"
    name: str | None = Field(default=None, description="Unique name of the LLM provider instance")
    model_name: str = Field(..., description="Name of the LLM model")

    # Subclasses should define this as a class variable with default generation params
    default_generation_params: ClassVar[dict[str, Any]] = {}
    supported_structured_outputs: list[StructuredOutputType] | None

    append_text_system_prompt: str | None = Field(
        default=None, description="System prompt text to append to each request"
    )
    append_text_last_message: str | None = Field(
        default=None, description="Text to append to the last user message"
    )

    @model_validator(mode="before")
    @classmethod
    def merge_generation_params(cls, data: Any) -> Any:
        """Merge provided generation_params with default values from the class."""
        if isinstance(data, dict) and "generation_params" in data:
            # Get the default generation params from the class
            defaults = cls.default_generation_params.copy()
            # Merge with provided params (provided params take precedence)
            provided_params = data.get("generation_params")
            if provided_params is not None:
                defaults.update(provided_params)
            data["generation_params"] = defaults
        return data

    @abstractmethod
    async def generate(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Generate content from messages."""

    @abstractmethod
    async def generate_streaming(
        self, messages: list[LLMMessage], **kwargs: Any
    ) -> AsyncGenerator[LLMResponse, None]:
        """Asynchronously generate content from messages."""

    def validate_config(self) -> bool:
        """Validate provider configuration."""
        return True


__all__ = [
    "BaseLLMProvider",
    "LLMMessage",
    "LLMResponse",
    "LLMToolCall",
    "StructuredOutputType",
    "ToolCallFunction",
]
