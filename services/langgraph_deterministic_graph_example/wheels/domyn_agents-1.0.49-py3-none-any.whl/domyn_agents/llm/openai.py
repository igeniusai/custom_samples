import json
import os
import time
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import httpx
from pydantic import Field, computed_field

from domyn_agents.llm.base import (
    BaseLLMProvider,
    LLMMessage,
    LLMResponse,
    LLMToolCall,
    StructuredOutput,
    StructuredOutputType,
    ToolCallFunction,
)
from domyn_agents.logger import get_logger

MODELS_SUPPORT_REASONING_EFFORT = ["o1", "o1-mini", "o3-mini", "gpt-5", "gpt-5-mini", "gpt-5-nano"]
MODELS_SUPPORT_TEMPERATURE = ["gpt-5-mini", "gpt-5-nano", "gpt-5", "gpt-4o", "gpt-4o-mini"]


class OpenAIProvider(BaseLLMProvider):
    """Provider for OpenAI models"""

    type: str = "openai"
    url: str = Field(
        default="https://api.openai.com/v1/chat/completions", description="API endpoint URL"
    )

    # TODO: senza api key dovrebbe dare errore
    api_key: str = Field(
        default=os.getenv("OPENAI_API_KEY"), description="API key for authentication"
    )
    supported_structured_outputs: list[StructuredOutputType] = Field(
        default_factory=lambda: [StructuredOutputType.JSON_SCHEMA],
        description="List of supported structured output types",
    )

    default_generation_params: ClassVar[dict[str, Any]] = {
        "frequency_penalty": 0.0,
        "n": 1,
        "presence_penalty": 0.0,
        "reasoning_effort": "medium",  # low, medium, high
        "service_tier": "auto",
        "temperature": 1,
        "max_completion_tokens": 4000,
    }

    generation_params: dict[str, Any] = Field(
        default_factory=lambda: {
            "frequency_penalty": 0.0,
            "n": 1,
            "presence_penalty": 0.0,
            "reasoning_effort": "medium",  # low, medium, high
            "service_tier": "auto",
            "temperature": 1,
            "max_completion_tokens": 4000,
        },
        description="Generation parameters for the model",
    )

    @computed_field
    @property
    def compute_generation_params(self) -> dict[str, Any]:
        gen_params = self.generation_params.copy()

        if self.model_name not in ["o1", "o1-mini", "o3-mini", "gpt-5", "gpt-5-mini", "gpt-5-nano"]:
            gen_params.pop("reasoning_effort", None)
        if self.model_name not in MODELS_SUPPORT_TEMPERATURE:
            gen_params.pop("temperature", None)
        return gen_params

    def model_post_init(self, context: Any, /) -> None:
        if not self.name:
            self.name = self.model_name

    @staticmethod
    def _serialize_messages(messages: list[LLMMessage]) -> list[dict[str, Any]]:
        """Serialize LLMMessages to OpenAI-compatible dicts, omitting None fields.

        OpenAI requires:
        - assistant messages have ``content`` as a string (not null)
        - None fields must be omitted entirely, not sent as null
        """
        result = []
        for msg in messages:
            d: dict[str, Any] = {"role": msg.role}
            if msg.content is not None:
                d["content"] = msg.content
            if msg.tool_calls is not None:
                d["tool_calls"] = [tc.model_dump() for tc in msg.tool_calls]
            if msg.tool_call_id is not None:
                d["tool_call_id"] = msg.tool_call_id
            if msg.name is not None:
                d["name"] = msg.name
            result.append(d)
        return result

    @staticmethod
    async def preprocess_structured_outputs(structured_outputs: StructuredOutput | None) -> dict:
        if structured_outputs is None:
            structured_outputs_params = {}
        else:
            match structured_outputs.type:
                case StructuredOutputType.JSON_SCHEMA:
                    structured_outputs_params = {
                        "response_format": {
                            "type": "json_schema",
                            "json_schema": {
                                "name": "agent_step",
                                "strict": True,
                                "schema": structured_outputs.rules,
                            },
                        }
                    }
                case _:
                    raise ValueError(
                        f"Structured output type {structured_outputs.type} not supported by OpenAIProvider"
                    )
        return structured_outputs_params

    async def generate(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Call OpenAI API"""
        logger = get_logger()

        structured_outputs_params = await self.preprocess_structured_outputs(structured_outputs)

        start = time.time()
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload: dict[str, Any] = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
        } | structured_outputs_params
        payload = {**payload, **self.compute_generation_params}

        # Add tools if present
        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Request]: {self.url}", payload=payload)

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()

            message_data = data["choices"][0]["message"]

            # Parse tool calls from response
            tool_calls: list[LLMToolCall] = []
            for tc in message_data.get("tool_calls") or []:
                tool_calls.append(
                    LLMToolCall(
                        id=tc["id"],
                        type=tc.get("type", "function"),
                        function=ToolCallFunction(
                            name=tc["function"]["name"],
                            arguments=tc["function"]["arguments"],
                        ),
                    )
                )

            logger.info(
                f"[Inference Response]: {self.url}",
                payload={
                    "response": message_data.get("content") or "",
                    "generated_tokens": data.get("usage", {}).get("completion_tokens", 0),
                    "execution_time": time.time() - start,
                    "tool_calls": [tc.model_dump() for tc in tool_calls],
                },
            )

            return LLMResponse(
                content=message_data.get("content") or "",
                usage=data.get("usage", {}),
                generated_tokens=data.get("usage", {}).get("completion_tokens", 0),
                reasoning_content=data["choices"][0]["message"].get("reasoning_content")
                or data["choices"][0]["message"].get("reasoning", None),
                execution_time=time.time() - start,
                tool_calls=tool_calls,
            )

    async def generate_streaming(
        self,
        messages: list[LLMMessage],
        structured_outputs: StructuredOutput | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[LLMResponse, None]:
        """Call OpenAI API with streaming support"""
        logger = get_logger()
        structured_outputs_params = await self.preprocess_structured_outputs(structured_outputs)
        start = time.time()
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model_name,
            "messages": [message.to_dict() for message in messages],
            "stream": True,
        }
        payload = {
            **payload,
            **self.compute_generation_params,
            **kwargs,
        } | structured_outputs_params
        payload.pop(
            "add_generation_prompt", None
        )  # TODO: PICCONATA streaming doesn't support add_generation_prompt?

        if tools:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        logger.info(f"[Inference Stream Request]: {self.url}", payload=payload)

        token_count = 0
        full_output = ""

        # Accumulator for streaming tool-call deltas, keyed by their index.
        # Each entry: {"id": str, "type": str, "name": str, "arguments": str}
        tool_call_acc: dict[int, dict] = {}
        reasoning = ""

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(self.url, headers=headers, json=payload)
            response.raise_for_status()
            async for chunk in response.aiter_bytes():
                if chunk:
                    for c in chunk.decode("utf-8").split("data:"):
                        c = c.strip()
                        if c and c != "[DONE]":
                            try:
                                data = json.loads(c)
                                delta = data["choices"][0]["delta"]

                                # --- tool-call delta accumulation ---
                                for tc_delta in delta.get("tool_calls") or []:
                                    idx = tc_delta["index"]
                                    if idx not in tool_call_acc:
                                        tool_call_acc[idx] = {
                                            "id": tc_delta.get("id", ""),
                                            "type": tc_delta.get("type", "function"),
                                            "name": tc_delta.get("function", {}).get("name", ""),
                                            "arguments": "",
                                        }
                                    else:
                                        if tc_delta.get("id"):
                                            tool_call_acc[idx]["id"] = tc_delta["id"]
                                        if tc_delta.get("type"):
                                            tool_call_acc[idx]["type"] = tc_delta["type"]
                                        if tc_delta.get("function", {}).get("name"):
                                            tool_call_acc[idx]["name"] = tc_delta["function"][
                                                "name"
                                            ]
                                    tool_call_acc[idx]["arguments"] += tc_delta.get(
                                        "function", {}
                                    ).get("arguments", "")

                                # --- reasoning delta accumulation ---
                                if delta.get("reasoning"):
                                    reasoning += delta.get("reasoning")

                                # --- text content ---
                                content = delta.get("content", "").replace("\x00", "")
                                if content:
                                    token_count += 1
                                    full_output += content
                                    yield LLMResponse(
                                        content=content,
                                        usage={},
                                        generated_tokens=token_count,
                                        execution_time=time.time() - start,
                                    )
                            except json.JSONDecodeError:
                                pass

        # Build final LLMToolCall objects from the accumulated deltas
        tool_calls: list[LLMToolCall] = [
            LLMToolCall(
                id=acc["id"],
                type=acc["type"],
                function=ToolCallFunction(
                    name=acc["name"],
                    arguments=acc["arguments"],
                ),
            )
            for acc in tool_call_acc.values()
        ]

        # If there were tool calls, yield one final response carrying them all
        if tool_calls:
            yield LLMResponse(
                content="",
                usage={},
                generated_tokens=token_count,
                execution_time=time.time() - start,
                tool_calls=tool_calls,
                reasoning_content=reasoning or None,
            )

        logger.info(
            f"[Inference Response]: {self.url}",
            payload={
                "response": full_output,
                "generated_tokens": token_count,
                "execution_time": time.time() - start,
                "tool_calls": [tc.model_dump() for tc in tool_calls],
            },
        )
