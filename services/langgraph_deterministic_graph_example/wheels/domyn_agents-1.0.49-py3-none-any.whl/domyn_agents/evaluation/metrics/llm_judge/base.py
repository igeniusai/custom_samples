import asyncio
import copy
from typing import Any, ClassVar, Generic, TypeVar

import numpy as np
from httpx import HTTPStatusError
from pydantic import BaseModel

from domyn_agents.evaluation.metrics.llm_judge.templates.prompting import (
    JudgeVerdict,
    QuestionJudgePrompt,
)
from domyn_agents.llm import BaseLLMProvider
from domyn_agents.llm.base import LLMMessage


# TODO: VALIDATE THAT ALL THE ANSWERS HAVE THE SAME QUESTIONS
class RepeatedJudgeResults(BaseModel):
    verdicts: list[JudgeVerdict]

    @property
    def valid_verdicts(self) -> list[JudgeVerdict]:
        return [v for v in self.verdicts if not v.error]

    @property
    def average_scores(self) -> dict[str, float]:
        if self.valid_verdicts:
            final_scores = {key: [] for key in self.valid_verdicts[0].questions}
            for answer in self.valid_verdicts:
                for key, value in answer.results.items():
                    final_scores[key].append(value)
            out = {
                key: np.mean([v for v in value if v is not None]).item()
                for key, value in final_scores.items()
            }
        else:
            out = {}
        return out

    @property
    def repeated_scores(self) -> dict[str, list[float]]:
        if self.valid_verdicts:
            final_scores = {key: [] for key in self.valid_verdicts[0].questions}
            for answer in self.valid_verdicts:
                for key, value in answer.results.items():
                    final_scores[key].append(value)
        else:
            final_scores = {}
        return final_scores

    @property
    def explanations(self) -> dict[str, list[str]]:
        if self.valid_verdicts:
            explanations = {key: [] for key in self.valid_verdicts[0].questions}
            for answer in self.valid_verdicts:
                for key in answer.thoughts:
                    explanations[key].append(answer.thoughts.get(key))
        else:
            explanations = {}
        return explanations


P = TypeVar("P", bound=QuestionJudgePrompt)


class LLMJudge(BaseModel, Generic[P]):
    explanation_key: ClassVar[str] = "explanation"
    llm_provider: BaseLLMProvider
    prompting: P
    n_repetition: int = 5
    max_retries: int = 3

    async def generate_with_retry(
        self,
        messages: list[LLMMessage],
        generation_params: dict[str, Any],
        structured_outputs: dict[str, Any] | None = None,
    ) -> JudgeVerdict:
        messages = copy.deepcopy(messages)
        current_retry = 0
        while current_retry < self.max_retries:
            try:
                response = await self.llm_provider.generate(
                    messages=messages,
                    generation_params=generation_params,
                    structured_outputs=structured_outputs,
                )
            except HTTPStatusError:
                current_retry += 1
                continue
            validated_answer = self.prompting.validate_answer(response.content)
            if not validated_answer.error:
                return validated_answer
            else:
                messages += (LLMMessage(role="assistant", content=response.content),)
                messages += (
                    LLMMessage(
                        role="user",
                        content=f"Your previous answer raised an error {validated_answer.error_message}. Please fix it.",
                    ),
                )
                current_retry += 1
        validated_answer = JudgeVerdict(error=True, error_message="Max retries exceeded")
        return validated_answer

    async def __call__(
        self,
        request: str,
        generation_params: dict[str, Any],
        shuffle_questions: bool,
        structured_outputs: dict[str, Any] | None = None,
        **kwargs,
    ) -> JudgeVerdict:
        system_prompt = self.prompting.format(shuffle_questions=shuffle_questions, **kwargs)
        messages = [
            LLMMessage(role="system", content=system_prompt),
            LLMMessage(role="user", content=request),
        ]
        response = await self.generate_with_retry(
            messages=messages,
            generation_params=generation_params,
            structured_outputs=structured_outputs,
        )
        return response

    async def repeat_judges(
        self,
        request: str,
        generation_params: dict[str, Any],
        shuffle_questions: bool = True,
        structured_outputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> RepeatedJudgeResults:
        coroutines = [
            self(
                request=request,
                generation_params=generation_params,
                shuffle_questions=shuffle_questions,
                structured_outputs=structured_outputs,
                **kwargs,
            )
            for _ in range(self.n_repetition)
        ]
        repeated_judges = await asyncio.gather(*coroutines)

        return RepeatedJudgeResults(verdicts=repeated_judges)
