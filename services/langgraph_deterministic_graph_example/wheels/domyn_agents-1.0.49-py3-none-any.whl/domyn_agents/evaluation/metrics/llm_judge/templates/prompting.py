import datetime
import json
from typing import ClassVar, Self

from pydantic import BaseModel, model_validator

from domyn_agents.evaluation.metrics.llm_judge.templates.base import FormattableTemplate
from domyn_agents.evaluation.metrics.llm_judge.templates.questions import JudgeQuestions


class JudgeVerdict(BaseModel):
    error: bool
    questions: list[str] | None = None
    thoughts: dict[str, str] | None = None
    results: dict[str, float] | None = None
    error_message: str | None = None

    @model_validator(mode="after")
    def validate_keys(self) -> Self:
        if self.results is not None:
            if (self.thoughts is None) or (set(self.results.keys()) != set(self.thoughts.keys())):
                raise ValueError("Results and thoughts must have the same keys.")
            if self.questions is None:
                self.questions = list(self.results.keys())
            else:
                if set(self.questions) != set(self.results.keys()):
                    raise ValueError("Questions must match the keys in results and thoughts.")
        return self


class QuestionJudgePrompt(FormattableTemplate):
    questions: JudgeQuestions
    format_fields: ClassVar[set[str]] = {
        "questions_instructions",
        "format_specification",
        "current_date",
    }
    reference_date: str | None = None

    def format(self, shuffle_questions: bool, **kwargs) -> str:
        if shuffle_questions:
            self.questions.shuffle_questions()
        questions_instructions = self.questions.format_questions_instructions(**kwargs)
        format_specification = self.questions.format_specification()
        reference_date = (
            datetime.datetime.now().strftime("%d/%m/%Y")
            if self.reference_date is None
            else self.reference_date
        )
        expanded_kwargs = kwargs | {
            "questions_instructions": questions_instructions,
            "format_specification": format_specification,
            "current_date": reference_date,
        }
        return super().format(**expanded_kwargs)

    def validate_answer(self, answer: str) -> JudgeVerdict:
        names = {q.name for q in self.questions.questions}
        try:
            dict_obj = json.loads(answer)
            for q_name in names:
                if not isinstance(dict_obj[q_name], dict):
                    return JudgeVerdict(
                        error=True,
                        error_message=f"Expected a JSON object for question '{q_name}', got: {type(dict_obj[q_name]).__name__}",
                    )
        except json.JSONDecodeError as e:
            return JudgeVerdict(error=True, error_message=f"JSON decode error: {e!s}")

        if missing := (set(names) - set(dict_obj.keys())):
            return JudgeVerdict(
                error=True,
                error_message=f"Missing scores for questions: {', '.join(missing)}. Please add them to the results.",
            )
        thoughts = {}
        results = {}
        for q_name in names:
            thoughts[q_name] = dict_obj[q_name].get(self.questions.thought_key, "")
            q_score = dict_obj[q_name].get(self.questions.score_key, None)
            if q_score is None:
                return JudgeVerdict(
                    error=True,
                    error_message=f"Missing score for question '{q_name}'. Please provide a score.",
                )
            try:
                results[q_name] = float(q_score)
            except (TypeError, ValueError) as e:
                return JudgeVerdict(
                    error=True,
                    error_message=f"Error converting scores to float: {e!s}",
                )
        return JudgeVerdict(
            error=False,
            questions=list(names),
            thoughts=thoughts,
            results=results,
        )


class GroundTruthComparisonPrompt(QuestionJudgePrompt):
    format_fields: ClassVar[set[str]] = {
        "questions_instructions",
        "format_specification",
        "current_date",
        "ground_truth",
        "user_request",
    }
