from typing import ClassVar

from pydantic import Field

from domyn_agents.core import ExecutionEventType
from domyn_agents.evaluation.base import SystemDescription
from domyn_agents.evaluation.metrics.base import TrajectoryMetric
from domyn_agents.evaluation.metrics.llm_judge.base import LLMJudge
from domyn_agents.evaluation.results import Result
from domyn_agents.evaluation.trajectory import Trajectory


class TrajectoryLLMJudge(TrajectoryMetric):
    metric_name: ClassVar[str] = "trajectory_llm_judge"
    llm_judge: LLMJudge
    generation_params: dict = Field(default_factory=dict)
    system_description: SystemDescription | None

    @staticmethod
    def build_trajectory_representation(trajectory: Trajectory) -> str:
        trajectory_representation = ""
        for event in trajectory.events:
            match event.event_type:
                case ExecutionEventType.USER_INPUT:
                    trajectory_representation += f"<user>REQUEST: {event.content[0].text}</user>\n"
                case ExecutionEventType.RESPONSE:
                    trajectory_representation += (
                        f"<{event.author}>ANSWER: {event.content[0].text}</{event.author}>\n"
                    )
                case ExecutionEventType.AGENT_END:
                    trajectory_representation += (
                        f"<{event.author}> ending agent execution </{event.author}>\n"
                    )
                case ExecutionEventType.AGENT_CALL:
                    trajectory_representation += (
                        f"<{event.author}>Calling agent: {event.action.name}"
                    )
                    task = event.action.parameters.get("task")
                    if task:
                        trajectory_representation += f" with task: {task}</{event.author}>\n"
                    else:
                        trajectory_representation += f"</{event.author}>\n"
                case ExecutionEventType.TOOL_END:
                    action = event.action
                    thought = action.thought if action else None
                    trajectory_representation += f"<{event.author}>\nThought:{thought}\nAction: {action.name}\nParameters:{action.parameters}\n</{event.author}>\n"
                    if event.action and event.action.observation:
                        trajectory_representation += (
                            f"<observation>{event.action.observation}</observation>\n"
                        )
                case ExecutionEventType.TOOL_ERROR:
                    action = event.action
                    thought = action.thought if action else None
                    trajectory_representation += f"<{event.author}>\nThought:{thought}\nAction: {action.name}\nParameters:{action.parameters}\n</{event.author}>\n"
                    trajectory_representation += f"<error>{event.action.observation}</error>\n"
        return trajectory_representation

    def build_message(
        self, trajectory: Trajectory, previous_trajectories: list[Trajectory] | None
    ) -> str:
        if self.system_description:
            message_str = (
                "Consider the following Multi-agent System:\n---MULTI AGENTS SYSTEM---\n"
                + str(self.system_description)
                + "---\n\n"
            )
        else:
            message_str = ""
        if previous_trajectories:
            message_str += "Given the previous history of the conversation:\n"
            for i, traj in enumerate(previous_trajectories):
                message_str += f"***MESSAGE {i + 1}***"
                message_str += self.build_trajectory_representation(traj)
                message_str += "***\n\n"
        message_str += "Evaluate the following interaction:\n"
        message_str += self.build_trajectory_representation(trajectory)
        return message_str

    async def compute(
        self,
        trajectory: Trajectory,
        previous_trajectories: list[Trajectory] | None = None,
        **kwargs,
    ) -> list[Result]:
        request = self.build_message(
            trajectory=trajectory, previous_trajectories=previous_trajectories
        )
        results = await self.llm_judge.repeat_judges(
            request=request, generation_params=self.generation_params, shuffle_questions=True
        )
        average_scores = results.average_scores
        repeated_scores = results.repeated_scores
        explanations = results.explanations
        return [
            Result(
                name=self.metric_name + "_" + question,
                value=score,
                additional_info={
                    "question": question,
                    "verdicts": repeated_scores,
                    "explanations": explanations,
                },
            )
            for question, score in average_scores.items()
        ]
