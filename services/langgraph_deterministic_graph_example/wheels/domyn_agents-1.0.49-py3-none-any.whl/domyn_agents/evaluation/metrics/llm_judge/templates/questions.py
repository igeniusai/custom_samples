import json
import random
import re
from abc import ABC
from typing import ClassVar

from pydantic import BaseModel, field_validator

from domyn_agents.evaluation.metrics.llm_judge.templates.base import (
    FormattableTemplate,
    get_formattable_fields,
)


class EvalQuestion(FormattableTemplate, ABC):
    name: str
    values_specification: str
    options: list[str] | None


class StaticQuestion(EvalQuestion):
    format_fields: ClassVar[set[str]] = set()


class GroundTruthQuestion(EvalQuestion):
    format_fields: ClassVar[set[str]] = {"ground_truth"}

    def format(self, **kwargs) -> str:
        return super().format(**kwargs)


class JudgeQuestions(BaseModel):
    score_key: ClassVar[str] = "score"
    questions: list[EvalQuestion]
    # question_enum_template: str = "Question {index}"
    instruction: str = "Please evaluate the following aspects:"
    thought_key: str = "explanation"
    json_format_instruction: str = 'Provide your answer evaluating each required aspect using the following JSON format:\n{{{{"<aspect>": {{"{thought_key}":"your thoughts and explanation", "{score_key}":"<score>"}}, ...}}}}\n'

    # @field_validator("question_enum_template", mode="before")
    # @classmethod
    # def validate_enum_template(cls, template: str) -> str:
    #    if get_formattable_fields(template) != {"index"}:
    #        raise ValueError(
    #            f"question_enum_template must contain exactly one field placeholder: 'index'. Found: {template}"
    #        )
    #    return template

    @field_validator("json_format_instruction", mode="before")
    @classmethod
    def validate_enum_template(cls, template: str) -> str:
        if get_formattable_fields(template) != {"thought_key", "score_key"}:
            raise ValueError(
                f"question_enum_template must contain exactly the field placeholders: 'thought_key', 'score_key'. Got: {template}"
            )
        return template

    def shuffle_questions(self, seed: int = 42) -> None:
        """
        Shuffle the questions and their corresponding weights using the provided seed.
        """
        random.Random(seed).shuffle(self.questions)

    def format_questions_instructions(self, **kwargs) -> str:
        """
        Returns the instruction for the questions.
        """
        out = (
            self.json_format_instruction.format(
                thought_key=self.thought_key, score_key=self.score_key
            )
            + self.instruction
        )

        instructions_format = {q.name: q.format(**kwargs) for q in self.questions}

        return out + "\n" + json.dumps(instructions_format)

    def format_specification(self) -> str:
        """
        Returns a string that describes the format of the answers for each question.
        """
        # TODO: RANDOMIZE VALUES SPECIFICATION ORDER
        questions_format = {q.name: q.values_specification for q in self.questions}
        return json.dumps(questions_format)

    @property
    def option_regexes(self) -> list[str]:
        regexes = []
        for i, q in enumerate(self.questions):
            escaped_options = []
            for opt in q.options:
                # Do the escaping only if the option is not an integer or a decimal number
                if re.match(r"^\d+(\.\d+)?$", str(opt)):
                    escaped_options.append(str(opt))
                else:
                    escaped_options.append(re.escape(opt))
            # Sort by length to ensure longer options are matched first
            # This prevents partial matches when one option is a substring of another (e.g "0" and "0.5")
            escaped_options.sort(key=len, reverse=True)
            options_pattern = "|".join(escaped_options)
            regexes.append(
                rf"{re.escape(self.question_enum_template.format(index=i))}:\s*({options_pattern})"
            )
        return regexes
