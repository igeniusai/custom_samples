from typing import Any, ClassVar

import numpy as np

from domyn_agents.evaluation.metrics.base import GroundTruthMetric
from domyn_agents.evaluation.metrics.llm_judge.base import LLMJudge
from domyn_agents.evaluation.results import Result


# TODO: SKIP LLM JUDGE FOR EXACTLY COMPARABLE GROUND TRUTHS FOR SPEED? (KEEP ONLY FOR FREE TEXT?)
class LLMJudgeFinalAnswerComparison(GroundTruthMetric):
    metric_name: ClassVar[str] = "LLM_judge_final_answer"
    allowed_types: ClassVar[set[str]] = {"all"}
    check_types: ClassVar[bool] = False
    llm_judge: LLMJudge
    question_prompt: str = "Provide the scores for the following response:\n'{response}'"
    generation_params: dict[str, Any]
    shuffle_questions: bool = True

    @staticmethod
    def cast_value(value: Any) -> str:
        return str(value)

    @classmethod
    def _aggregate_metrics(cls, results: list[Result]) -> list[Result]:
        clustered_results: dict[str, list[Result]] = {}
        for r in results:
            key = r.additional_info["question"]
            if key not in clustered_results:
                clustered_results[key] = []
            clustered_results[key].append(r)
        results: list[Result] = []
        for question, res_list in clustered_results.items():
            values = [r.value for r in res_list if r.value is not None]
            explanations = []
            for r in res_list:
                explanations.extend(r.additional_info.get("explanations", {}).get(question, []))
            repeated_scores = []
            for r in res_list:
                repeated_scores.extend(r.additional_info.get("verdicts", {}).get(question, []))
            average_score = np.mean(values).item() if values else None
            results.append(
                Result(
                    name=cls.metric_name + "_" + question,
                    value=average_score,
                    additional_info={
                        "question": question,
                        "average_score": average_score,
                        "repeated_scores": repeated_scores,
                        "explanations": explanations,
                    },
                )
            )
        return results

    async def _compute_ground_truth_metric(self, extracted_facts: Any) -> list[Result] | None:
        if (extracted_value := extracted_facts.get(self.name)) is None:
            return None
        else:
            results = await self.llm_judge.repeat_judges(
                request=self.question_prompt.format(response=extracted_value),
                ground_truth=self.value,
                generation_params=self.generation_params,
                shuffle_questions=self.shuffle_questions,
            )
            average_scores = results.average_scores
            repeated_scores = results.repeated_scores
            explanations = results.explanations
        return [
            Result(
                name=self.metric_name + "_" + question,
                value=score,
                additional_info={
                    "name": self.name,
                    "question": question,
                    "verdicts": repeated_scores,
                    "explanations": explanations,
                },
            )
            for question, score in average_scores.items()
        ]
