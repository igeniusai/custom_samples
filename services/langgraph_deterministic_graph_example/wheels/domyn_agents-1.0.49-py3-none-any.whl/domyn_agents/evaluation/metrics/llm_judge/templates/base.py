import string
from typing import ClassVar

from pydantic import BaseModel, model_validator


def get_formattable_fields(template: str) -> set[str]:
    formatter = string.Formatter()
    fields = [field_name for _, field_name, _, _ in formatter.parse(template) if field_name]
    return set(fields)


class FormattableTemplate(BaseModel):
    format_fields: ClassVar[set[str]]
    template: str

    @model_validator(mode="after")
    def validate_template(self):
        """Validate that the prompt template is formattable"""
        if self.formattable_fields != self.format_fields:
            raise ValueError(
                f"LLMJudgePrompt's prompt_template must contain exactly these fields placeholders: {self.format_fields}"
            )
        return self

    def format(self, **kwargs) -> str:
        # Skip None values
        reduced_kwargs = {
            k: v for k, v in kwargs.items() if ((k in self.format_fields) and (v is not None))
        }
        return self.template.format(**reduced_kwargs)

    @property
    def formattable_fields(self) -> set[str]:
        return get_formattable_fields(self.template)
