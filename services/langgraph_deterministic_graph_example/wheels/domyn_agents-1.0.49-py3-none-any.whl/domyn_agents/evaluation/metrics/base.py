from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Any, ClassVar, Self

from pydantic import BaseModel, field_validator

from domyn_agents.core import BaseEvent
from domyn_agents.evaluation.base import GroundTruth
from domyn_agents.evaluation.results import Result
from domyn_agents.evaluation.trajectory import MultiTurnTrajectory, Trajectory


class MetricScope(StrEnum):
    STEP = "step"
    TRAJECTORY = "trajectory"
    MULTITURN = "multiturn"
    GROUND_TRUTH = "ground_truth"
    MULTIRUN = "multirun"


class Metric(ABC, BaseModel):
    metric_name: ClassVar[str | None]
    scope: ClassVar[MetricScope]
    _registry: ClassVar[dict[str, type]] = {}

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if getattr(cls, "metric_name", None):
            cls._registry[cls.metric_name] = cls

    @abstractmethod
    def compute(self, *args, **kwargs) -> list[Result] | None: ...


class StepLevelMetric(Metric, ABC):
    scope: ClassVar[MetricScope] = MetricScope.STEP

    @abstractmethod
    async def compute(
        self, event: BaseEvent, previous_events: list[BaseEvent] | None = None, **kwargs
    ) -> list[Result] | None: ...


class TrajectoryMetric(Metric, ABC):
    scope: ClassVar[MetricScope] = MetricScope.TRAJECTORY

    @abstractmethod
    async def compute(
        self,
        trajectory: Trajectory,
        previous_trajectories: list[Trajectory] | None = None,
        **kwargs,
    ) -> list[Result] | None: ...


class MultiTurnMetric(Metric, ABC):
    scope: ClassVar[MetricScope] = MetricScope.MULTITURN

    @abstractmethod
    async def compute(
        self, multiturn_trajectory: MultiTurnTrajectory, **kwargs
    ) -> list[Result] | None: ...


class MultiRunMetric(Metric, ABC):
    scope: ClassVar[MetricScope] = MetricScope.MULTIRUN

    @abstractmethod
    async def compute(
        self, run_trajectories: list[MultiTurnTrajectory], run_group_name: str, **kwargs
    ) -> list[Result] | None: ...


class GroundTruthMetric(Metric, ABC):
    scope: ClassVar[MetricScope] = MetricScope.GROUND_TRUTH
    allowed_types: ClassVar[set[str]]
    type_mapping: ClassVar[dict[str, list[type]]] = {}
    check_types: ClassVar[bool] = True
    answer_obtained_suffix: ClassVar[str] = "_answer_obtained"
    name: str
    value: Any
    value_type: str
    guidelines: str
    trajectory_id: int | None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        for allowed_type in cls.allowed_types:
            if allowed_type in cls.type_mapping:
                cls.type_mapping[allowed_type].append(cls)
            else:
                cls.type_mapping[allowed_type] = [cls]

    @field_validator("value_type", mode="before")
    @classmethod
    def validate_field(cls, value_type: str) -> str:
        if cls.check_types and (value_type not in cls.allowed_types):
            raise ValueError(
                f"Unknown type: {value_type}. Only allowed types for ground truth {cls.__name__} are: {cls.allowed_types}"
            )
        return value_type

    @field_validator("value", mode="before")
    @classmethod
    def format_value(cls, value: Any) -> Any:
        return cls.cast_value(value)

    async def compute(self, extracted_facts: Any) -> Any:
        if self.value is None:
            out = None
        elif extracted_facts is None:
            out = Result(name=self.metric_name + self.answer_obtained_suffix, value=0)
        else:
            out = await self._compute_ground_truth_metric(extracted_facts)
        return out

    @classmethod
    def aggregate_results(cls, results: list[Any]) -> list[Result]:
        """
        Aggregate the results of the metric computation.
        This method should be implemented by subclasses.
        """
        valid_results = [r for r in results if r is not None]
        if not valid_results:
            return [Result(name=cls.metric_name, value=float("NaN"))]
        return cls._aggregate_metrics(results)

    @classmethod
    def auto_dispatch(
        cls, ground_truth: GroundTruth, trajectory_id: int | None, **kwargs
    ) -> list[Self]:
        subclasses = cls.type_mapping.get(ground_truth.value_type, []) + cls.type_mapping.get(
            "all", []
        )
        return [
            subclass(
                name=ground_truth.name,
                value=ground_truth.value,
                value_type=ground_truth.value_type,
                guidelines=ground_truth.guidelines,
                trajectory_id=trajectory_id,
                **kwargs,
            )
            for subclass in subclasses
        ]

    @classmethod
    @abstractmethod
    def _aggregate_metrics(cls, results: list[Result]) -> list[Result]:
        """
        Aggregate the results of the metric computation.
        This method should be implemented by subclasses.
        """
        raise NotImplementedError

    @staticmethod
    @abstractmethod
    def cast_value(value: Any) -> Any:
        """
        Cast the value to the desired one for comparison after validation.
        This method should be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    async def _compute_ground_truth_metric(
        self, extracted_facts: Any
    ) -> Result | list[Result] | None:
        raise NotImplementedError
