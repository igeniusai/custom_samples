from typing import ClassVar

from domyn_agents.core import BaseEvent, ExecutionEventType
from domyn_agents.evaluation.metrics.base import MetricScope, Result, StepLevelMetric


class ToolCallsMetrics(StepLevelMetric):
    scope: ClassVar[MetricScope] = MetricScope.STEP
    metric_name: ClassVar[str] = "tool_calls_metrics"

    async def compute(self, event: BaseEvent, **kwargs) -> list[Result]:
        # TODO: ADD MORE METRICS
        if event.event_type == ExecutionEventType.TOOL_ERROR:
            error_message = (
                event.content[0].error_message
                if event.content and event.content[0].error_message
                else ""
            )
            result = Result(
                name="tool_error", value=1, additional_info={"error_message": error_message}
            )
        else:
            result = Result(name="tool_error", value=0)
        return [result]
