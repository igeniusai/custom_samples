from typing import Any, ClassVar

import numpy as np

from domyn_agents.evaluation.metrics.base import GroundTruthMetric
from domyn_agents.evaluation.results import Result


class LiteralGroundTruth(GroundTruthMetric):
    allowed_types: ClassVar[set[str]] = {"literal"}
    metric_name: ClassVar[str] = "literal_matches_ratio"

    @classmethod
    def _aggregate_metrics(cls, results: list[Result]) -> list[Result]:
        values = []
        obtained_answers = []
        info = {"names": [], "extracted_values": [], "ground_truths": []}
        for r in results:
            if r.name == cls.metric_name:
                if r.value is not None:
                    values.append(r.value)
                info["names"].append(r.additional_info["name"])
                info["extracted_values"].append(r.additional_info.get("extracted"))
                info["ground_truths"].append(r.additional_info.get("ground_truth"))
            elif r.name == cls.metric_name + cls.answer_obtained_suffix:
                obtained_answers.append(r.value)
        sanitized_values = [v for v in values if v is not None]
        sanitized_obtained = [a for a in obtained_answers if a is not None]
        mean_value = np.mean(sanitized_values).item() if sanitized_values else None
        mean_obtained = np.mean(sanitized_obtained).item() if sanitized_obtained else None
        return (
            [
                Result(name=cls.metric_name, value=mean_value, additional_info=info),
                Result(
                    name=cls.metric_name + cls.answer_obtained_suffix,
                    value=mean_obtained,
                ),
            ]
            if results
            else []
        )

    @staticmethod
    def cast_value(value: Any) -> str | None:
        if value is not None:
            value = str(value).strip().lower()
        return value

    async def _compute_ground_truth_metric(self, extracted_facts: dict[str, Any]) -> list[Result]:
        """
        Check if the formatted answer matches the value of this entity.
        """
        extracted = extracted_facts.get(self.name)
        if extracted is not None:
            extracted = self.cast_value(extracted)
            return [
                Result(
                    name=self.metric_name,
                    value=(extracted == self.value),
                    additional_info={
                        "name": self.name,
                        "extracted": extracted,
                        "ground_truth": self.value,
                    },
                ),
                Result(name=self.metric_name + self.answer_obtained_suffix, value=1),
            ]
        else:
            return [
                Result(
                    name=self.metric_name,
                    value=False,
                    additional_info={
                        "name": self.name,
                        "extracted": extracted,
                        "ground_truth": self.value,
                    },
                ),
                Result(name=self.metric_name + self.answer_obtained_suffix, value=0),
            ]
