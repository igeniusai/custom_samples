from typing import Any, ClassVar

from domyn_agents.evaluation.metrics.base import GroundTruthMetric
from domyn_agents.evaluation.results import Result


class FreeTextGroundTruth(GroundTruthMetric):
    allowed_types: ClassVar[set[str]] = {"string"}
    metric_name: ClassVar[None] = None

    @classmethod
    def _aggregate_metrics(cls, results: list[Result]) -> list[Result]:
        return []

    @staticmethod
    def cast_value(value: str | None) -> str | None:
        if value is not None:
            value = str(value)
        return value

    async def _compute_ground_truth_metric(self, extracted_facts: dict[str, Any]) -> None:
        return None
