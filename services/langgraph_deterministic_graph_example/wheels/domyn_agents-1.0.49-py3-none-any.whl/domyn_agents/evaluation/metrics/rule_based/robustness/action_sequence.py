import itertools
from collections.abc import Callable
from typing import ClassVar

import numpy as np

from domyn_agents.evaluation.distances import DamerauLevenshteinDistance
from domyn_agents.evaluation.metrics.base import MultiRunMetric
from domyn_agents.evaluation.results import Result
from domyn_agents.evaluation.trajectory import (
    ActionComparisonMode,
    ComparableAction,
    MultiTurnTrajectory,
)


class ActionSequencePairwiseDistance(MultiRunMetric):
    metric_name: ClassVar[str] = "avg_actions_pairwise_distance"
    comparison_mode: ActionComparisonMode = ActionComparisonMode.ACTION_NAME
    distance_fn: Callable[[list[ComparableAction], list[ComparableAction]], float] = (
        DamerauLevenshteinDistance()
    )

    async def compute(
        self, run_trajectories: list[MultiTurnTrajectory], run_group_name: str, **kwargs
    ) -> list[Result] | None:
        actions = [
            m.merge_turn_trajectories()
            .change_comparison_mode(comparison_mode=self.comparison_mode)
            .actions
            for m in run_trajectories
        ]
        # The sum of the pairwise distances of a variable X should be equal to 2N^2*\sigma^2(X) for Euclidean metric, think about it for other metrics
        results = []
        for pair in itertools.combinations(actions, 2):
            results.append(self.distance_fn(*pair))
        avg_pairwise_distance = np.mean(
            results
        ).item()  # normalize as the sum of combinations grows ~ n^2
        prefix = run_group_name + "_" if run_group_name else ""
        return [
            Result(
                name=prefix + "avg_actions_pairwise_distance",
                value=avg_pairwise_distance,
                additional_info={"distances": results},
            )
        ]
