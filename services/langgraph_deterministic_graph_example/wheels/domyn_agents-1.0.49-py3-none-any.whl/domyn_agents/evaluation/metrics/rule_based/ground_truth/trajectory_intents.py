from collections.abc import Callable, Iterator
from typing import ClassVar

import numpy as np

from domyn_agents.evaluation.distances import DamerauLevenshteinDistance
from domyn_agents.evaluation.metrics.base import GroundTruthMetric
from domyn_agents.evaluation.results import Result
from domyn_agents.evaluation.trajectory import ComparableAction

# TODO: RIVEDERE TUTTA


class TrajectoryIntentsGroundTruth(GroundTruthMetric):
    allowed_types: ClassVar[set[str]] = {"trajectory_intents"}
    metric_name: ClassVar[str] = "intents_distance"
    distance_metric: Callable[[list[ComparableAction], list[ComparableAction]], float] = (
        DamerauLevenshteinDistance()
    )

    @staticmethod
    def cast_value(value: Iterator[str] | None) -> list[ComparableAction] | None:
        if value is not None:
            value = [ComparableAction.from_intents([intent]) for intent in value]
        return value

    async def _compute_ground_truth_metric(self, structured_facts: list[ComparableAction]) -> float:
        distance = self.distance_metric(structured_facts, self.value)
        return distance

    @classmethod
    def _aggregate_metrics(cls, results: list[int]) -> list:
        results_list = (
            [Result(name=cls.metric_name, value=np.mean(results).item())] if results else []
        )
        return results_list
