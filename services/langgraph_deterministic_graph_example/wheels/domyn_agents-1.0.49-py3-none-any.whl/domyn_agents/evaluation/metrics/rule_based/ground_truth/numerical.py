from typing import Any, ClassVar

import numpy as np

from domyn_agents.evaluation.metrics.base import GroundTruthMetric
from domyn_agents.evaluation.results import Result
from domyn_agents.evaluation.utils import relative_absolute_error


class NumericalGroundTruth(GroundTruthMetric):
    allowed_types: ClassVar[set[str]] = {"int", "float"}
    metric_name: ClassVar[str] = "average_numerical_rae"
    match_name: ClassVar[str] = "numerical_match"
    tolerance: float = 1e-6

    @classmethod
    def _aggregate_metrics(cls, results: list[Result]) -> list[Result]:
        values = []
        obtained_answers = []
        matches = []
        info = {"names": [], "extracted_values": [], "ground_truths": []}
        for r in results:
            if r.name == cls.metric_name:
                if r.value is not None:
                    values.append(r.value)
                info["names"].append(r.additional_info["name"])
                info["extracted_values"].append(r.additional_info["extracted_value"])
                info["ground_truths"].append(r.additional_info["ground_truth"])
            elif r.name == cls.metric_name + cls.answer_obtained_suffix:
                obtained_answers.append(r.value)
            elif r.name == cls.match_name:
                matches.append(r.value)

        sanitized_values = [v for v in values if v is not None]
        sanitized_obtained = [a for a in obtained_answers if a is not None]
        sanitized_matches = [m for m in matches if m is not None]
        mean_value = np.mean(sanitized_values).item() if sanitized_values else None
        mean_obtained = np.mean(sanitized_obtained).item() if sanitized_obtained else None
        avg_matches = np.mean(sanitized_matches).item() if sanitized_matches else None
        return (
            [
                Result(name=cls.metric_name, value=mean_value, additional_info=info),
                Result(
                    name=cls.metric_name + cls.answer_obtained_suffix,
                    value=mean_obtained,
                ),
                Result(name=cls.match_name, value=avg_matches, additional_info=info),
            ]
            if results
            else []
        )

    @staticmethod
    def cast_value(value: int | float | str | None) -> float | None:
        if value is not None:
            value = float(value)
        return value

    async def _compute_ground_truth_metric(self, extracted_facts: dict[str, Any]) -> list[Result]:
        """
        Calculate the Relative Absolute Error (RAE) for numerical values.
        """
        extracted = extracted_facts.get(self.name)
        if extracted is None:
            return [
                Result(
                    name=self.match_name,
                    value=False,
                    additional_info={
                        "name": self.match_name,
                        "ground_truth": self.value,
                    },
                ),
                Result(
                    name=self.metric_name + self.answer_obtained_suffix,
                    value=0,
                    additional_info={
                        "name": self.name,
                        "ground_truth": self.value,
                    },
                ),
            ]
        else:
            try:
                formatted_value = self.cast_value(extracted)
            except TypeError:
                formatted_value = None
            if formatted_value is None:
                result = None
                match = False
            else:
                result = relative_absolute_error(formatted_value, self.value)
                match = np.abs(result) < self.tolerance
        return [
            Result(
                value=result,
                name=self.metric_name,
                additional_info={
                    "name": self.name,
                    "extracted_value": extracted,
                    "ground_truth": self.value,
                },
            ),
            Result(
                value=match,
                name=self.match_name,
                additional_info={
                    "name": self.match_name,
                    "extracted_value": extracted,
                    "ground_truth": self.value,
                },
            ),
            Result(name=self.metric_name + self.answer_obtained_suffix, value=1),
        ]
