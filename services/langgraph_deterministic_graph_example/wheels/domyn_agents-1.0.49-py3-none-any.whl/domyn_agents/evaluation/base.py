from typing import Any, Self

from pydantic import BaseModel, ConfigDict, model_validator


class GroundTruth(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str
    value_type: str | None
    value: Any = None
    guidelines: str | None = None
    extractor: str | None = None

    @model_validator(mode="after")
    def check_type(self) -> Self:
        if (self.value is not None) and (self.value_type is None):
            raise ValueError(
                f"Type must be specified for ground truth entity '{self.name}' when value is provided."
            )
        return self

    @property
    def formatted_guidelines(self) -> str:
        return f"Guidelines:{self.guidelines}. Cast as type: {self.value_type}."


class ToolDescription(BaseModel):
    name: str
    description: str
    parameters: dict[str, Any] | None

    def __str__(self) -> str:
        return f"---Tool {self.name}---\n description: {self.description}\n parameters:{self.parameters}\n---\n"


class AgentDescription(BaseModel):
    name: str
    description: str
    tools: list[str]
    subagents: list[str]

    def __str__(self) -> str:
        return f"---Agent {self.name}---\n description: {self.description}\n tools:{self.tools}\n subagents:{self.subagents}\n---\n"


class SystemDescription(BaseModel):
    agents: dict[str, AgentDescription]
    tools: dict[str, ToolDescription]

    @model_validator(mode="after")
    def check_maps(self) -> Self:
        for agent in self.agents:
            for subagent_name in self.agents[agent].subagents:
                if subagent_name not in self.agents:
                    raise ValueError(
                        f"Subagent '{subagent_name}' used by agent '{self.agents[agent].name}' is not defined in the system agents."
                    )
            for tool in self.agents[agent].tools:
                if tool not in self.tools:
                    name_match = any(tool == t.name for t in self.tools.values())
                    if not name_match:
                        raise ValueError(
                            f"Tool '{tool}' used by agent '{self.agents[agent].name}' is not defined in the system tools."
                        )
        return self

    def __str__(self) -> str:
        agents_str = "Available agents:\n" + "\n".join([str(self.agents[a]) for a in self.agents])
        tools_str = "Available tools:\n" + "\n".join([str(self.tools[t]) for t in self.tools])
        return agents_str + "\n" + tools_str
