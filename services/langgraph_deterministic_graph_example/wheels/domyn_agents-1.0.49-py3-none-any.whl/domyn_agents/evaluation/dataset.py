import time
import uuid
from functools import cached_property
from typing import Self

from pydantic import BaseModel, model_validator

from domyn_agents.evaluation.base import GroundTruth
from domyn_agents.evaluation.extractors import AnswerStructurer, FactExtractor
from domyn_agents.evaluation.metrics.base import GroundTruthMetric, Metric
from domyn_agents.llm import BaseLLMProvider


class EvaluationDataPoint(BaseModel):
    messages: list[str]
    ground_truths: list[list[GroundTruth]]
    rephrased_messages: list[list[str]] | None = None
    n_repeats: int | None
    test_id: str | None = None
    repeated_id: int | None = None
    rephrased_id: int | None = None
    test_config: dict = {}
    point_metrics: list[Metric] = []
    point_extractors: list[FactExtractor] = []

    @model_validator(mode="after")
    def assign_id(self) -> Self:
        if self.test_id is None:
            self.test_id = f"datapoint_{uuid.uuid4().hex}"
        return self

    @model_validator(mode="after")
    def check_lengths(self) -> Self:
        if len(self.ground_truths) != len(self.messages):
            raise ValueError(
                f"Mismatched ground truths length for datapoint {self.test_id}. Length of ground_truths ({len(self.ground_truths)}) must match length of messages ({len(self.messages)})."
            )
        if self.rephrased_messages is not None:
            for n, rephrased in enumerate(self.rephrased_messages):
                if len(rephrased) != len(self.messages):
                    raise ValueError(
                        f"Mismatched rephrased messages length for datapoint {self.test_id} at rephrasing {n}. Length of rephrased_messages ({len(rephrased)}) must match length of messages ({len(self.messages)})."
                    )
        return self

    @property
    def conversation_id(self) -> str | None:
        return self.test_config.get("conversation_id")

    def get_single_conv(
        self, messages: list[str], rephrased_id: int | None, repeated_id: int | None
    ) -> Self:
        conv_id = self.test_config.get("conversation_id")
        if conv_id is None:
            # Assign a new conversation id if not present to avoid duplications
            conv_id = f"conv_{uuid.uuid4()}_{time.time_ns()}"
            self.test_config["conversation_id"] = conv_id
        if rephrased_id is not None:
            conv_id = f"{conv_id}_rephrased_{rephrased_id}"
        if repeated_id is not None:
            conv_id = f"{conv_id}_repeated_{repeated_id}"
        test_config = {**self.test_config, "conversation_id": conv_id}

        update_data = {
            "messages": messages,
            "rephrased_messages": None,
            "n_repeats": None,
            "rephrased_id": rephrased_id,
            "repeated_id": repeated_id,
            "test_config": test_config,
        }

        return self.model_copy(deep=True, update=update_data)

    @property
    def flattened(self) -> list[Self]:
        flattened = [
            self.get_single_conv(messages=self.messages, rephrased_id=None, repeated_id=None)
        ]

        rephrased_messages = self.rephrased_messages if self.rephrased_messages is not None else []
        for i, rephrased in enumerate(rephrased_messages):
            flattened.append(
                self.get_single_conv(messages=rephrased, rephrased_id=i, repeated_id=None)
            )
        n_repeats = self.n_repeats if self.n_repeats is not None else 0
        for j in range(n_repeats):
            flattened.append(
                self.get_single_conv(messages=self.messages, rephrased_id=None, repeated_id=j)
            )
        return flattened

    # TODO: SKIP LLM JUDGE FOR EXACTLY COMPARABLE GROUND TRUTHS FOR SPEED? (KEEP ONLY FOR FREE TEXT?)
    def get_ground_truth_metrics(self, **kwargs) -> list[GroundTruthMetric]:
        metrics = []
        for i, gts in enumerate(self.ground_truths):
            for gt in gts:
                try:
                    gt_metrics = GroundTruthMetric.auto_dispatch(
                        ground_truth=gt, trajectory_id=i, **kwargs
                    )
                    metrics.extend(gt_metrics)
                except NotImplementedError:
                    continue
        return metrics

    def get_default_extractors(
        self, llm_provider: BaseLLMProvider, generation_params: dict | None
    ) -> list[FactExtractor]:
        if generation_params is None:
            generation_params = {}
        extractors = []
        for i, gts in enumerate(self.ground_truths):
            gt_references = [gt for gt in gts if gt.extractor == AnswerStructurer.name]
            if gt_references:
                extractors.append(
                    FactExtractor.from_name(
                        name=AnswerStructurer.name,
                        trajectory_id=i,
                        ground_truths_references=gt_references,
                        llm_provider=llm_provider,
                        generation_params=generation_params,
                    )
                )
        return extractors


class EvaluationDataset(BaseModel):
    data_points: list[EvaluationDataPoint]

    @cached_property
    def flattened_data(self) -> Self:
        flattened_points = []
        for dp in self.data_points:
            flattened_points.extend(dp.flattened)
        return EvaluationDataset(data_points=flattened_points)

    @classmethod
    def from_json(
        cls,
        json_data: list[dict],
        n_repeats: int,
        point_metrics: list[list[Metric]] | None = None,
        point_extractors: list[list[FactExtractor]] | None = None,
    ) -> Self:
        if point_metrics is None:
            point_metrics = [[]] * len(json_data)
        if point_extractors is None:
            point_extractors = [[]] * len(json_data)
        data_points = [
            EvaluationDataPoint(
                point_extractors=point_extractors[i],
                point_metrics=point_metrics[i],
                n_repeats=n_repeats,
                **dp,
            )
            for i, dp in enumerate(json_data)
        ]
        return cls(data_points=data_points)
