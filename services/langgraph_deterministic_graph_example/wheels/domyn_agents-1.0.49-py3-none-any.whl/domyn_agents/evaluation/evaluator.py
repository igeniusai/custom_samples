import asyncio
from typing import Any

from pydantic import BaseModel

from domyn_agents.core import BaseEvent
from domyn_agents.evaluation.extractors import FactExtractor
from domyn_agents.evaluation.metrics.base import (
    GroundTruthMetric,
    Metric,
    MetricScope,
    MultiRunMetric,
    MultiTurnMetric,
    StepLevelMetric,
    TrajectoryMetric,
)
from domyn_agents.evaluation.results import (
    MultiTurnEvaluation,
    Result,
    StepEvaluation,
    TurnEvaluation,
)
from domyn_agents.evaluation.trajectory import ActionComparisonMode, MultiTurnTrajectory


class ConversationEvaluator(BaseModel):
    metrics: list[Metric]
    _multiturn_level_metrics: list[MultiTurnMetric] = []
    _trajectory_level_metrics: list[TrajectoryMetric] = []
    _step_level_metrics: list[StepLevelMetric] = []
    _ground_truth_metrics: list[GroundTruthMetric] = []

    def model_post_init(self, context: Any) -> None:
        for m in self.metrics:
            match m.scope:
                case MetricScope.STEP:
                    self._step_level_metrics.append(m)
                case MetricScope.TRAJECTORY:
                    self._trajectory_level_metrics.append(m)
                case MetricScope.MULTITURN:
                    self._multiturn_level_metrics.append(m)
                case MetricScope.GROUND_TRUTH:
                    self._ground_truth_metrics.append(m)
                case _:
                    pass

    async def evaluate_trajectory(
        self,
        multiturn_trajectory: MultiTurnTrajectory,
    ) -> MultiTurnEvaluation:
        # TODO: EXECUTE METRICS CONCURRENTLY WITH GATHER
        multiturn_results = await asyncio.gather(
            *[
                metric.compute(multiturn_trajectory=multiturn_trajectory)
                for metric in self._multiturn_level_metrics
            ]
        )
        turn_evaluations = []
        previous_trajectories = []
        for trajectory_id, trajectory in enumerate(multiturn_trajectory):
            trajectory_results = []
            # EVALUATE GROUND TRUTH
            ground_truth_results = {}
            for gt_metric in self._ground_truth_metrics:
                if (gt_metric.trajectory_id is not None) and (
                    gt_metric.trajectory_id != trajectory_id
                ):
                    continue
                computed = await gt_metric.compute(extracted_facts=trajectory.extracted_facts)
                if computed is not None:
                    if type(gt_metric) not in ground_truth_results:
                        ground_truth_results[type(gt_metric)] = []
                    if isinstance(computed, list):
                        ground_truth_results[type(gt_metric)].extend(computed)
                    else:
                        ground_truth_results[type(gt_metric)].append(computed)
            # Aggregate ground truth results
            for gt_metric_type, results in ground_truth_results.items():
                aggregated_results = gt_metric_type.aggregate_results(results)
                trajectory_results.extend(aggregated_results)

            # EVALUATE TRAJECTORY
            for trajectory_metric in self._trajectory_level_metrics:
                computed = await trajectory_metric.compute(
                    trajectory=trajectory, previous_trajectories=previous_trajectories
                )
                previous_trajectories.append(trajectory)
                if computed is not None:
                    trajectory_results.extend(computed)
            # ADD EXTRACTED FACTS TO TRAJECTORY RESULTS
            trajectory_results.append(
                Result(name="extracted_facts", value=trajectory.extracted_facts)
            )
            # EVALUATE STEPS
            step_results = []
            previous_steps = []
            for step_metric in self._step_level_metrics:
                for i, event in enumerate(trajectory):
                    metric_results = await step_metric.compute(event=event)
                    if metric_results is not None:
                        step_results.append(StepEvaluation(step_id=i, results=metric_results))
                        previous_steps.append(event)

            turn_evaluations.append(
                TurnEvaluation(
                    turn_id=trajectory_id,
                    step_level_evaluations=step_results,
                    results=trajectory_results,
                )
            )
        return MultiTurnEvaluation(
            turn_level_evaluations=turn_evaluations,
            results=multiturn_results,
        )

    async def evaluate_events(
        self,
        events: list[BaseEvent],
        fact_extractors: list[FactExtractor],
        intents_map: dict[str, str] | None,
        comparison_mode: ActionComparisonMode,
    ) -> MultiTurnEvaluation:
        multiturn_trajectory = await MultiTurnTrajectory.from_conversation(
            conversation_events=events,
            fact_extractors=fact_extractors,
            intents_map=intents_map,
            comparison_mode=comparison_mode,
        )
        evaluation = await self.evaluate_trajectory(multiturn_trajectory=multiturn_trajectory)
        return evaluation


class RobustnessEvaluator(BaseModel):
    metrics: list[MultiRunMetric]

    async def evaluate_runs(
        self,
        original_trajectory: MultiTurnTrajectory,
        repeated_trajectories: list[MultiTurnTrajectory],
        rephrased_trajectories: list[MultiTurnTrajectory],
    ) -> list[Result]:
        repeated_results = await asyncio.gather(
            *[
                metric.compute(
                    run_trajectories=[*repeated_trajectories, original_trajectory],
                    run_group_name="repeated",
                )
                for metric in self.metrics
            ]
        )

        rephrased_results = await asyncio.gather(
            *[
                metric.compute(
                    run_trajectories=[*rephrased_trajectories, original_trajectory],
                    run_group_name="rephrased",
                )
                for metric in self.metrics
            ]
        )

        flattened_results = []
        for result_list in repeated_results + rephrased_results:
            if result_list:
                flattened_results.extend(result_list)

        return flattened_results
