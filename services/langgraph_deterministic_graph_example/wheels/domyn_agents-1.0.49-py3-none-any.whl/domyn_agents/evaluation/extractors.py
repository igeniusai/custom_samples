import json
from abc import ABC, abstractmethod
from typing import Any, ClassVar, Self

from pydantic import BaseModel, ConfigDict

from domyn_agents.core import BaseEvent, ExecutionEventType
from domyn_agents.evaluation.base import GroundTruth
from domyn_agents.evaluation.utils import retry_on_exception_async
from domyn_agents.llm import BaseLLMProvider
from domyn_agents.llm.base import LLMMessage

# TODO: MOVE AGAIN TO LANGFUSE
SYSTEM_PROMPT = """You are an expert assistant extracting and structuring information from a textual answer. You are give a query, a textual answer to the query produced by an AI assistant, and a series of values to extract from the answer. To help you with the extraction, you are given a json template of the form {"entity_1":"rules about the format", ...} with the entities to extract and guidelines for the format (including type) you should use when extracting them. If the information is present in the answer with a different format and or type, you should cast it to the specified format and type. \n If a value is not present in the answer, fill the corresponding entity with null. You should return a json answer with the form: {"entity_1":"value_1", ...} where the entities are exactly the same provided in the template and the values follow the prescribed format.\n"""
MESSAGE = """Given the query: <query>{query}</query>\n and the proposed answer: <answer>{answer}</answer>\n Extract the following values (if present) from the answer:{guidelines}"""


class FactExtractor(ABC, BaseModel):
    name: ClassVar[str]
    _registry: ClassVar[dict[str, type]] = {}
    trajectory_id: int | None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._registry[cls.name] = cls

    @classmethod
    def from_name(cls, name: str, trajectory_id: int | None = None, *args, **kwargs) -> Self:
        if name not in cls._registry:
            raise ValueError(
                f"{cls.__name__} with name '{name}' not registered. Make sure you have imported the corresponding subclass."
            )
        extractor_cls = cls._registry[name]
        return extractor_cls(*args, trajectory_id=trajectory_id, **kwargs)

    @abstractmethod
    async def extract_generated_facts(self, events: list[BaseEvent]) -> dict[str, Any]:
        pass


class AnswerStructurer(FactExtractor):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: ClassVar[str] = "answer_structurer"
    llm_provider: BaseLLMProvider
    ground_truths_references: list[GroundTruth]
    generation_params: dict[str, Any] = {}

    def validate_extraction(self, extracted: dict[str, Any]) -> None:
        to_extract = {gt.name for gt in self.ground_truths_references}
        extracted_keys = set(extracted.keys())
        if to_extract != extracted_keys:
            missing = to_extract - extracted_keys
            extra = extracted_keys - to_extract
            error_msg = ""
            if missing:
                error_msg += f"Missing keys in extraction: {missing}. "
            if extra:
                error_msg += f"Extra keys in extraction: {extra}."
            raise ValueError(error_msg)

    @retry_on_exception_async(max_retries=5, delay=0.5, exponential_backoff_rate=2)
    async def format_answer(
        self,
        query: str,
        answer: str,
    ) -> dict[str, Any]:
        guidelines = {gt.name: gt.formatted_guidelines for gt in self.ground_truths_references}
        messages = [
            LLMMessage(role="system", content=SYSTEM_PROMPT),
            LLMMessage(
                role="user",
                content=MESSAGE.format(query=query, answer=answer, guidelines=guidelines),
            ),
        ]
        response = await self.llm_provider.generate(
            messages=messages, **self.generation_params
        )  # TODO: GRAMMAR
        formatted_dict = json.loads(response.content)
        self.validate_extraction(formatted_dict)
        return formatted_dict

    async def extract_generated_facts(self, events: list[BaseEvent]) -> dict[str, Any]:
        query = None
        answer = None
        for event in events:
            if (query is None) and (event.event_type == ExecutionEventType.USER_INPUT):
                query = event.content[0].text
            if (answer is None) and (event.event_type == ExecutionEventType.RESPONSE):
                if not event.content[0].text:
                    continue
                answer = event.content[0].text
        if (query is not None) and (answer is not None):
            facts = await self.format_answer(query=query, answer=answer)
        else:
            facts = {}
        return facts
