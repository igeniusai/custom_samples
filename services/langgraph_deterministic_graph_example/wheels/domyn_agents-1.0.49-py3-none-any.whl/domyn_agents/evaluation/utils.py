import asyncio
import logging

from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.evaluation.base import AgentDescription, SystemDescription, ToolDescription
from domyn_agents.logger import get_logger


def relative_absolute_error(v1: int | float, v2: int | float) -> float:
    """
    Compute the relative absolute error between two values.
    """
    if v1 == 0 and v2 == 0:
        return 0.0
    if v2 == 0:
        return float("inf")  # Avoid division by zero
    return abs((v1 - v2) / v2)


def retry_on_exception_async(
    max_retries: int,
    delay: float | None = None,
    exponential_backoff_rate: float = 1.0,
    raise_on_error: bool = False,
    logger: logging.Logger = get_logger(),
):
    """
    Decorator to retry an async function on exception.
    """

    def decorator(func):
        async def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    logger.error(
                        f"Error executing '{func.__module__}:{func.__name__}'. {type(e)}:{e}. Retrying {retries + 1}/{max_retries}..."
                    )
                    if delay:
                        await asyncio.sleep(delay * (exponential_backoff_rate**retries))
                        retries += 1
            message = (
                f"Function '{func.__module__}:{func.__name__}' failed after {max_retries} retries."
            )
            if raise_on_error:
                raise Exception(message)

            logger.error(message)
            return None

        return wrapper

    return decorator


# TODO: HANDLE TOOLS WITH DUPLICATED NAMES, WHICH FIELD IS THE UNIQUE IDENTIFIER?
def get_system_description_from_root(root_agent: BaseAgent) -> SystemDescription:
    tools = root_agent.tools
    tools_descriptions = {
        t.declaration.name: ToolDescription(
            name=t.declaration.name,
            description=t.declaration.description,
            parameters={
                p.name: {"description": p.description, "type": p.type}
                for p in t.declaration.parameters
            },
        )
        for t in tools
    }
    agents_descriptions = {}
    to_check = [root_agent]
    checked = []
    while to_check:
        agent = to_check.pop(-1)
        if agent in checked:
            continue
        to_check.extend(agent.sub_agents)
        checked.append(agent)

        agents_descriptions[agent.name] = AgentDescription(
            name=agent.name,
            description=agent.description,
            tools=[t.declaration.name for t in agent.tools],
            subagents=[a.name for a in agent.sub_agents],
        )
        for tool in agent.tools:
            tools_descriptions[tool.declaration.name] = ToolDescription(
                name=tool.declaration.name,
                description=tool.declaration.description,
                parameters={
                    p.name: {"description": p.description, "type": p.type}
                    for p in tool.declaration.parameters
                },
            )

    return SystemDescription(tools=tools_descriptions, agents=agents_descriptions)
