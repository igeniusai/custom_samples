import json
import math
from typing import Any

import pandas as pd
from pydantic import BaseModel

from domyn_agents.evaluation.trajectory import MultiTurnTrajectory


class Result(BaseModel):
    name: str
    value: Any
    additional_info: dict = {}


def flatten_results(results: list[Result]) -> dict[str, Any]:
    flattened = {}
    for result in results:
        flattened[result.name] = result.value
        if len(result.additional_info) > 0:
            flattened[f"{result.name}_info"] = result.additional_info
    return flattened


# THE EVALUATIONS BELOW ARE JUST A WAY TO ORGANIZE THE RESULTs SO THAT IT IS EASY TO GO FROM A NESTED STRUCTURE TO A "FLAT" RELATIONAL STRUCTURE


class StepEvaluation(BaseModel):
    step_id: int
    results: list[Result]

    def to_row(self, test_id: str, turn_id: int, run_n: str) -> dict[str, Any]:
        sk = turn_id
        row = {
            "step_id": self.step_id,
            "test_id": test_id,
            "trajectory_id": sk,
            "run": run_n,
        }
        row = row | flatten_results(self.results)
        return row


class TurnEvaluation(BaseModel):
    turn_id: int
    step_level_evaluations: list[StepEvaluation]
    results: list[Result]

    def get_rows(self, test_id: str, run_n: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        traj_row = {
            "trajectory_id": self.turn_id,
            "test_id": test_id,
            "run": run_n,
        } | flatten_results(self.results)
        steps_rows = [
            s.to_row(turn_id=self.turn_id, test_id=test_id, run_n=run_n)
            for s in self.step_level_evaluations
        ]
        return traj_row, steps_rows


class MultiTurnEvaluation(BaseModel):
    turn_level_evaluations: list[TurnEvaluation]
    results: list[Result]
    conversation_config: dict | None = None

    def get_rows(
        self, test_id: str, run_id: str
    ) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
        test_row: dict[str, Any] = {"test_id": test_id, "run": run_id} | flatten_results(
            self.results
        )
        if self.conversation_config is not None:
            test_row["conversation_config"] = self.conversation_config
        traj_rows = []
        steps_rows = []
        for turn_eval in self.turn_level_evaluations:
            traj_row, steps_row = turn_eval.get_rows(test_id=test_id, run_n=run_id)
            traj_rows.append(traj_row)
            steps_rows.extend(steps_row)
        return test_row, traj_rows, steps_rows


class TestEvaluation(BaseModel):
    test_id: str
    global_results: list[Result] = []
    original_conversation_evaluation: MultiTurnEvaluation
    original_multiturn_trajectory: MultiTurnTrajectory
    repeated_conversation_evaluations: list[MultiTurnEvaluation]
    repeated_multiturn_trajectories: list[MultiTurnTrajectory]
    rephrased_conversation_evaluations: list[MultiTurnEvaluation]
    rephrased_multiturn_trajectories: list[MultiTurnTrajectory]

    def append_jsonl(self, filename: str):
        with open(filename, "a+") as f:
            f.write(json.dumps(self.model_dump()) + "\n")

    def global_result_row(self) -> dict[str, Any]:
        return {"test_id": self.test_id} | flatten_results(self.global_results)

    def get_rows(
        self,
    ) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        test_row, traj_rows, step_rows = self.original_conversation_evaluation.get_rows(
            test_id=self.test_id, run_id="original"
        )
        test_rows = [test_row]
        steps_rows = step_rows
        for i, multi_turn_eval in enumerate(self.repeated_conversation_evaluations):
            test_row, traj_row, steps_row = multi_turn_eval.get_rows(
                test_id=self.test_id, run_id=f"repeated_{i}"
            )
            test_rows.append(test_row)
            traj_rows.extend(traj_row)
            steps_rows.extend(steps_row)
        for i, multi_turn_eval in enumerate(self.rephrased_conversation_evaluations):
            test_row, traj_row, steps_row = multi_turn_eval.get_rows(
                test_id=self.test_id, run_id=f"rephrased_{i}"
            )
            test_rows.append(test_row)
            traj_rows.extend(traj_row)
            steps_rows.extend(steps_row)
        global_rows = self.global_result_row()
        return global_rows, test_rows, traj_rows, steps_rows

    def get_dataframes(self) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        global_rows, test_rows, traj_rows, step_rows = self.get_rows()
        step_df = pd.DataFrame(step_rows)
        if step_df.empty:
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
        step_df = step_df.groupby(
            ["step_id", "test_id", "trajectory_id", "run"], as_index=False
        ).first()
        traj_df = pd.DataFrame(traj_rows)
        traj_df = traj_df.groupby(["test_id", "trajectory_id", "run"], as_index=False).first()
        test_df = pd.DataFrame(test_rows)
        test_df = test_df.groupby(["test_id", "run"], as_index=False).first()
        global_df = pd.DataFrame([global_rows])
        return global_df, test_df, traj_df, step_df


def get_tests_tables(
    tests_results: list[TestEvaluation],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    all_global_rows = []
    all_test_rows = []
    all_traj_rows = []
    all_step_rows = []
    for test_eval in tests_results:
        global_df, test_df, traj_df, step_df = test_eval.get_dataframes()
        if not test_df.empty:
            all_test_rows.append(test_df)
        if not traj_df.empty:
            all_traj_rows.append(traj_df)
        if not step_df.empty:
            all_step_rows.append(step_df)
        if not global_df.empty:
            all_global_rows.append(global_df)
    multirun_df = (
        pd.concat(all_global_rows, ignore_index=True) if all_global_rows else pd.DataFrame()
    )
    final_test_df = pd.concat(all_test_rows, ignore_index=True) if all_test_rows else pd.DataFrame()
    final_traj_df = pd.concat(all_traj_rows, ignore_index=True) if all_traj_rows else pd.DataFrame()
    final_step_df = pd.concat(all_step_rows, ignore_index=True) if all_step_rows else pd.DataFrame()
    return multirun_df, final_test_df, final_traj_df, final_step_df


def iqr_outliers(series: pd.Series) -> pd.Series:
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    return pd.Series((series < lower_bound) | (series > upper_bound))


def aggregate_and_outliers(
    data: pd.DataFrame, filter_outliers: bool = False
) -> None | pd.DataFrame:
    aggregated = []
    for col in data.select_dtypes(include="number").columns:
        col_data = data[col].dropna()  # consider only non-null values
        if filter_outliers:
            outliers = iqr_outliers(col_data)
            filtered_data = col_data[~outliers]
            n_outliers = outliers.sum()
        else:
            filtered_data = col_data
            n_outliers = iqr_outliers(col_data).sum()
        mean = filtered_data.mean()
        std = filtered_data.std()
        se = (std / math.sqrt(len(filtered_data))) if len(filtered_data) > 0 else None
        col_results = pd.Series(
            {col: mean, f"{col}_STD": std, f"{col}_SE": se, f"{col}_n_outliers": n_outliers}
        )
        aggregated.append(col_results)
    return pd.concat(aggregated) if aggregated else None


def compute_intra_test_std(
    df: pd.DataFrame, test_id_col: str = "test_id", run_col: str = "run"
) -> pd.Series:
    numerical_cols = [c for c in df.columns if c not in [test_id_col, run_col]]
    numerical_cols = df[numerical_cols].select_dtypes(include="number").columns.tolist()

    variance_results = []

    for col in numerical_cols:
        # Intra-test variance: variance across runs for each test, then average
        intra_variances = df.groupby(test_id_col)[col].std(ddof=1)
        mean_intra_var = intra_variances.mean()
        variance_results.append(pd.Series({f"{col}_STD_intra": mean_intra_var}))
    return pd.concat(variance_results) if variance_results else pd.Series()


def preprocess_for_aggregation(df: pd.DataFrame) -> pd.DataFrame:
    numerical_test_cols = df.select_dtypes(include="number").columns.tolist()
    abs_df = df[numerical_test_cols].abs()
    return abs_df


# TODO: ABSTRACT ALL THIS SMALL AGGREGATION FUNCTIONS
def average_step_table_on_trajectory(step_df: pd.DataFrame) -> pd.DataFrame:
    abs_step_df = preprocess_for_aggregation(step_df)
    filtered_steps_df = pd.concat([abs_step_df, step_df[["test_id", "run"]]], axis=1).drop(
        "step_id", axis=1
    )
    traj_averaged_step_table = (
        filtered_steps_df.groupby(["test_id", "run", "trajectory_id"]).mean().reset_index()
    )
    return traj_averaged_step_table


def average_step_table_on_runs(traj_averaged_step_table: pd.DataFrame) -> pd.DataFrame:
    run_averaged_step_table = (
        traj_averaged_step_table.drop("trajectory_id", axis=1)
        .groupby(["test_id", "run"])
        .mean()
        .reset_index()
    )
    return run_averaged_step_table


def average_step_table_on_tests(
    run_averaged_step_table: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.Series]:
    test_averaged_step_table = (
        run_averaged_step_table.drop(["run"], axis=1).groupby("test_id").mean().reset_index()
    )
    intra_step_variance = compute_intra_test_std(
        run_averaged_step_table, test_id_col="test_id", run_col="run"
    )
    return test_averaged_step_table, intra_step_variance


def average_traj_table_on_runs(traj_df: pd.DataFrame) -> pd.DataFrame:
    abs_traj_df = preprocess_for_aggregation(traj_df)
    filtered_traj_df = pd.concat([abs_traj_df, traj_df[["test_id", "run"]]], axis=1)
    run_averaged_traj_table = (
        filtered_traj_df.groupby(["test_id", "run"])
        .mean()
        .reset_index()
        .drop(["trajectory_id"], axis=1)
    )
    return run_averaged_traj_table


def average_traj_table_on_tests(
    run_averaged_traj_table: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.Series]:
    test_averaged_traj_table = (
        run_averaged_traj_table.drop("run", axis=1).groupby("test_id").mean().reset_index()
    )
    intra_test_variance = compute_intra_test_std(
        run_averaged_traj_table, test_id_col="test_id", run_col="run"
    )
    return test_averaged_traj_table, intra_test_variance


def average_run_results(
    multirun_df: pd.DataFrame, test_df: pd.DataFrame, traj_df: pd.DataFrame, step_df: pd.DataFrame
) -> dict[str, float]:
    #!!!DEPRECATED!!!
    results = []
    abs_test_df = preprocess_for_aggregation(test_df)
    filtered_test_df = pd.concat([abs_test_df, test_df[["test_id", "run"]]], axis=1)
    abs_multirun_df = preprocess_for_aggregation(multirun_df)
    filtered_multirun_df = pd.concat([abs_multirun_df, multirun_df[["test_id"]]], axis=1)
    traj_averaged_step_table = average_step_table_on_trajectory(step_df)
    run_averaged_step_table = average_step_table_on_runs(traj_averaged_step_table)
    test_averaged_step_table, intra_step_variance = average_step_table_on_tests(
        run_averaged_step_table
    )
    results.append(aggregate_and_outliers(test_averaged_step_table))

    run_averaged_traj_table = average_traj_table_on_runs(traj_df)
    test_averaged_traj_table, intra_traj_variance = average_traj_table_on_tests(
        run_averaged_traj_table
    )
    results.append(aggregate_and_outliers(test_averaged_traj_table))
    results.append(aggregate_and_outliers(filtered_test_df))
    results.append(aggregate_and_outliers(filtered_multirun_df))

    # Compute intra-test variances
    results.append(intra_traj_variance)
    results.append(intra_step_variance)

    return pd.concat([r for r in results if r is not None]).sort_index().to_dict()


def average_evaluation_results(
    multirun_df: pd.DataFrame,
    conversation_df: pd.DataFrame,
    traj_df: pd.DataFrame,
    step_df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    abs_test_df = preprocess_for_aggregation(conversation_df)
    filtered_test_df = pd.concat([abs_test_df, conversation_df[["test_id", "run"]]], axis=1)
    abs_multirun_df = preprocess_for_aggregation(multirun_df)
    filtered_multirun_df = pd.concat([abs_multirun_df, multirun_df[["test_id"]]], axis=1)
    traj_averaged_steps_results = average_step_table_on_trajectory(step_df=pd.DataFrame(step_df))
    run_averaged_steps_results = average_step_table_on_runs(
        traj_averaged_step_table=traj_averaged_steps_results
    )
    test_averaged_steps_results, intra_test_step_variance = average_step_table_on_tests(
        run_averaged_step_table=run_averaged_steps_results
    )
    run_averaged_trajectory_results = average_traj_table_on_runs(traj_df=pd.DataFrame(traj_df))
    test_averaged_trajectory_results, intra_test_traj_variance = average_traj_table_on_tests(
        run_averaged_traj_table=run_averaged_trajectory_results
    )

    aggregated_test_table = filtered_multirun_df.merge(
        test_averaged_steps_results, on=["test_id"], how="outer"
    ).merge(test_averaged_trajectory_results, on=["test_id"], how="outer")
    aggregated_run_table = conversation_df.merge(
        run_averaged_steps_results, on=["test_id", "run"], how="outer"
    ).merge(run_averaged_trajectory_results, on=["test_id", "run"], how="outer")

    aggregated_traj_table = traj_df.merge(
        traj_averaged_steps_results, on=["test_id", "run", "trajectory_id"], how="outer"
    )
    results = [
        aggregate_and_outliers(test_averaged_steps_results),
        aggregate_and_outliers(test_averaged_trajectory_results),
        aggregate_and_outliers(filtered_test_df),
        aggregate_and_outliers(multirun_df),
        intra_test_step_variance,
        intra_test_traj_variance,
    ]
    aggregated_results = pd.concat([r for r in results if r is not None]).sort_index()
    return (
        aggregated_results,
        aggregated_test_table,
        aggregated_run_table,
        aggregated_traj_table,
        step_df,
    )
