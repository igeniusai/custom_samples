import numpy as np

from domyn_agents.evaluation.trajectory import ComparableAction


class DamerauLevenshteinDistance:
    @staticmethod
    def get_alphabet(
        t1: list[ComparableAction], t2: list[ComparableAction]
    ) -> list[ComparableAction]:
        found = []
        for a in t1 + t2:
            if a not in found:
                found.append(a)
        return found

    def __call__(self, t1: list[ComparableAction], t2: list[ComparableAction]) -> float:
        # Using pseudocode from https://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance#Distance_with_adjacent_transpositions
        # it seems there is a mistake in the pseudocode, da seems to be a mapping from the "letters" of the alphabet to
        # integer values. This only accounts for adjacent transpositions
        # TODO: CHECK CAREFULLY
        alphabet = self.get_alphabet(t1, t2)
        da = np.zeros(shape=len(alphabet), dtype=int)
        d = np.zeros(shape=(len(t1) + 2, len(t2) + 2), dtype=int)
        # d indices are shifted by 1 to the left (i.e. 0->-1, add +1) while trajectory and da indices are shifted by
        # 1 to the right (i.e. 0->1, add -1)
        maxdist = len(t1) + len(t2)
        d[0, 0] = maxdist

        d[1:, 0] = maxdist
        d[1:, 1] = np.arange(len(t1) + 1)

        d[0, 1:] = maxdist
        d[1, 1:] = np.arange(len(t2) + 1)

        for i in range(1, len(t1) + 1):
            db = 0
            for j in range(1, len(t2) + 1):
                k = da[alphabet.index(t2[j - 1])]
                last_match = db
                if t1[i - 1] == t2[j - 1]:
                    cost = 0
                    db = j
                else:
                    cost = 1
                d[i + 1, j + 1] = np.min(
                    [
                        d[i, j] + cost,  # substitution
                        d[i + 1, j] + 1,  # insertion
                        d[i, j + 1] + 1,  # deletion
                        d[k, last_match] + (i - k - 1) + 1 + (j - last_match - 1),  # transposition
                    ]
                )
            da[alphabet.index(t1[i - 1])] = i
        return d[-1, -1].item()
