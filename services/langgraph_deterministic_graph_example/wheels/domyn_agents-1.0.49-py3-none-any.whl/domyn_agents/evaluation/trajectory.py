import asyncio
import copy
from collections.abc import Iterator
from enum import StrEnum, auto
from typing import Any, ClassVar, Self

from pydantic import BaseModel, ConfigDict, model_validator

from domyn_agents.core import BaseAction, BaseEvent, ExecutionEventType
from domyn_agents.evaluation.extractors import FactExtractor


class ActionComparisonMode(StrEnum):
    ACTION_NAME = auto()
    INTENTS = auto()
    PARAMETERS = auto()


class ComparableAction(BaseAction):
    name: str | None
    intents: list[str] | None
    comparison_mode: ActionComparisonMode

    @model_validator(mode="after")
    def check_not_null(self) -> Self:
        if (self.intents is None) and ((self.name is None) or (self.parameters is None)):
            raise ValueError(
                "If intents are not provided, name, parameters and user_request must be provided."
            )
        return self

    @model_validator(mode="after")
    def validate_intents_comparison(self) -> Self:
        if (self.comparison_mode == ActionComparisonMode.INTENTS) and (self.intents_map is None):
            raise ValueError(
                f"If comparison mode is set to {ActionComparisonMode.INTENTS} intents can't be None"
            )
        return self

    def __eq__(self, other: "ComparableAction") -> bool:
        """Custom equality between two actions. If one has intents than only the corresponding intents are considered,
        otherwise the action names and parameters are compared."""

        if not isinstance(other, ComparableAction):
            raise ValueError("Can only compare a ComparableAction with another ComparableAction.")

        if self.comparison_mode != other.comparison_mode:
            raise ValueError("The two actions have mismatching comparison modes.")
        match self.comparison_mode:
            case ActionComparisonMode.PARAMETERS:
                result = (self.name == other.name) and (self.parameters == other.parameters)
            case ActionComparisonMode.ACTION_NAME:
                result = self.name == other.name
            case ActionComparisonMode.INTENTS:
                result = len(set(self.intents).intersection(set(other.intents))) > 0
            case _:
                raise ValueError(f"Unknown comparison mode {self.comparison_mode}")
        return result

    @classmethod
    def from_event(
        cls,
        event: BaseEvent,
        intents_map: dict[str, list[str]] | None,
        comparison_mode: ActionComparisonMode,
    ) -> Self:
        action_name = event.action.name
        tag = None if intents_map is None else intents_map.get(action_name, None)
        return cls(
            name=action_name,
            parameters=event.action.parameters,
            thought=event.action.thought,
            observation=event.action.observation,
            message=event.action.message,
            intents=tag,
            comparison_mode=comparison_mode,
        )

    @classmethod
    def from_intents(cls, intents: list[str]) -> Self:
        """Create a ComparableTool from a list of intents to be associated with."""
        return cls(
            name=None,
            parameters=None,
            thought=None,
            observation=None,
            message=None,
            intents=intents,
            comparison_mode=ActionComparisonMode.INTENTS,
        )


class Trajectory(BaseModel):
    _action_event_types: ClassVar[list[ExecutionEventType]] = [
        ExecutionEventType.AGENT_CALL,
        ExecutionEventType.TOOL_END,
        ExecutionEventType.TOOL_ERROR,
    ]
    model_config = ConfigDict(arbitrary_types_allowed=True)
    user_request: str
    events: list[BaseEvent]
    intents_map: dict[str, list[str]] | None
    comparison_mode: ActionComparisonMode
    extracted_facts: dict[str, Any] = {}
    _action_events: list[BaseEvent] = []

    @model_validator(mode="after")
    def validate_intents_comparison(self) -> Self:
        if (self.comparison_mode == ActionComparisonMode.INTENTS) and (self.intents_map is None):
            raise ValueError(
                f"If comparison mode is set to {ActionComparisonMode.INTENTS} intents_map can't be None"
            )
        return self

    @model_validator(mode="after")
    def extract_intents(self) -> Self:
        if self.intents_map is not None:
            # Extract intents map from events
            self.extracted_facts["intents"] = [intent for intent in self.intents if intent]
        return self

    def model_post_init(self, context: Any) -> None:
        # Filter only events specifying actions, at the moment only TOOL_END and AGENT_START
        self._action_events = [
            ev for ev in self.events if ev.event_type in self._action_event_types
        ]

    def change_comparison_mode(self, comparison_mode: ActionComparisonMode) -> Self:
        copied = copy.deepcopy(self)
        copied.comparison_mode = comparison_mode
        return copied

    @property
    def actions(self) -> list[ComparableAction]:
        return [
            ComparableAction.from_event(
                event=event, intents_map=self.intents_map, comparison_mode=self.comparison_mode
            )
            for event in self._action_events
        ]

    @property
    def intents(self) -> list[list[str]]:
        return [action.intents for action in self.actions]

    def __len__(self) -> int:
        return len(self._action_events)

    def __eq__(self, other: Any) -> bool:
        """Compare the comparable actions."""
        if (type(self) is type(other)) and (len(self) == len(other)):
            out = self.actions == other.actions
        else:
            out = False
        return out

    def __getitem__(self, item: int) -> BaseEvent:  # ReactStep:
        return self._action_events[item]

    def __iter__(self) -> Iterator[BaseEvent]:
        return iter(self._action_events)

    @classmethod
    async def from_events(
        cls,
        events: list[BaseEvent],
        intents_map: dict[str, list[str]] | None,
        comparison_mode: ActionComparisonMode,
        fact_extractors: list[FactExtractor],
    ) -> Self:
        # Extract user request from the first USER_INPUT event
        user_request = ""
        for event in events:
            if event.event_type == ExecutionEventType.USER_INPUT:
                user_request = event.content[0].text
                break
        # Extract generated facts using the provided fact extractors
        extractions = await asyncio.gather(
            *[extractor.extract_generated_facts(events=events) for extractor in fact_extractors]
        )
        extracted_facts = {}
        for facts in extractions:
            if facts:
                extracted_facts |= facts

        return cls(
            user_request=user_request,
            events=events,
            intents_map=intents_map,
            comparison_mode=comparison_mode,
            extracted_facts=extracted_facts,
        )


class MultiTurnTrajectory(BaseModel):
    trajectories: list[Trajectory]

    @model_validator(mode="after")
    def check_for_intents_consistency(self) -> Self:
        if len(self.trajectories) > 0:
            intents = self.trajectories[0].intents_map
            for t in self.trajectories[1:]:
                if t.intents_map != intents:
                    raise ValueError("The given trajectories have different intents maps.")
        return self

    def __len__(self):
        return len(self.trajectories)

    def __eq__(self, other: Any) -> bool:
        """Compare the trajectories."""
        if (type(self) is type(other)) and (len(self) == len(other)):
            out = self.trajectories == other.trajectories
        else:
            out = False
        return out

    def __getitem__(self, item: int) -> Trajectory:
        return self.trajectories[item]

    def __iter__(self) -> Iterator[Trajectory]:
        return iter(self.trajectories)

    def assign_intent_map(self, intents_map: dict[str, list[str]] | None) -> None:
        for t in self.trajectories:
            t.intents_map = intents_map

    def merge_turn_trajectories(self) -> Trajectory:
        events = []
        queries = ""
        for i, t in enumerate(self.trajectories):
            events.extend(t.events)
            queries += f"\nUser query {i + 1}: {t.user_request}"
        return Trajectory(
            user_request=queries,
            events=events,
            intents_map=self.trajectories[0].intents_map if self.trajectories else None,
            comparison_mode=self.trajectories[0].comparison_mode
            if self.trajectories
            else ActionComparisonMode.ACTION_NAME,
        )

    @staticmethod
    def group_extractors_by_id(
        fact_extractors: list[FactExtractor],
    ) -> dict[int | None, list[FactExtractor]]:
        extractors_by_id = {}
        for extractor in fact_extractors:
            if extractor.trajectory_id in extractors_by_id:
                extractors_by_id[extractor.trajectory_id].append(extractor)
            else:
                extractors_by_id[extractor.trajectory_id] = [extractor]
        return extractors_by_id

    @classmethod
    async def from_conversation(
        cls,
        conversation_events: list[BaseEvent],
        intents_map: dict[str, Any] | None,
        comparison_mode: ActionComparisonMode,
        fact_extractors: list[FactExtractor],
    ) -> Self:
        trajectories = []
        current_events = []
        extractors_by_traj_id = cls.group_extractors_by_id(fact_extractors)
        for event in conversation_events:
            if (event.event_type == ExecutionEventType.USER_INPUT) and current_events:
                # Consider trajectory specific extractors plus the generic ones
                extractors = extractors_by_traj_id.get(
                    len(trajectories), []
                ) + extractors_by_traj_id.get(None, [])
                trajectories.append(
                    await Trajectory.from_events(
                        events=current_events,
                        intents_map=intents_map,
                        comparison_mode=comparison_mode,
                        fact_extractors=extractors,
                    )
                )
                current_events = [event]
            else:
                current_events.append(event)
        # APPEND REMAINING TRAJECTORY
        # Consider trajectory specific extractors plus the generic ones
        extractors = extractors_by_traj_id.get(len(trajectories), []) + extractors_by_traj_id.get(
            None, []
        )
        if current_events:
            trajectories.append(
                await Trajectory.from_events(
                    events=current_events,
                    intents_map=intents_map,
                    comparison_mode=comparison_mode,
                    fact_extractors=extractors,
                )
            )
        return cls(trajectories=trajectories)
