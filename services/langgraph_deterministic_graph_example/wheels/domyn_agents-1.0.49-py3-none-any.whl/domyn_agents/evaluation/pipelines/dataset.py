import asyncio
import copy
from typing import Self

from pydantic import BaseModel, model_validator

from domyn_agents.evaluation.dataset import EvaluationDataset
from domyn_agents.evaluation.evaluator import RobustnessEvaluator
from domyn_agents.evaluation.extractors import FactExtractor
from domyn_agents.evaluation.metrics.base import Metric, MetricScope
from domyn_agents.evaluation.metrics.llm_judge.base import LLMJudge
from domyn_agents.evaluation.pipelines.conversation import (
    ConversationEvaluation,
    ConversationEvaluationPipeline,
)
from domyn_agents.evaluation.results import TestEvaluation
from domyn_agents.llm import BaseLLMProvider


async def group_results_by_ids(
    results: list[ConversationEvaluation],
    test_ids: list[str | None],
    repeated_ids: list[int | None],
    rephrased_ids: list[int | None],
    robustness_evaluator: RobustnessEvaluator | None,
) -> list[TestEvaluation]:
    # Group results by test_id
    grouped_data = {}

    for result, test_id, repeated_id, rephrased_id in zip(
        results, test_ids, repeated_ids, rephrased_ids, strict=True
    ):
        if test_id is None:
            continue

        if test_id not in grouped_data:
            grouped_data[test_id] = {
                "original_evaluation": None,
                "original_trajectory": None,
                "repeated_evaluations": {},
                "repeated_trajectories": {},
                "rephrased_evaluations": {},
                "rephrased_trajectories": {},
                "max_repeated_id": -1,
                "max_rephrased_id": -1,
            }

        evaluation = result.evaluation
        trajectory = result.trajectory

        # Classify as original, repeated, or rephrased based on IDs
        if repeated_id is None and rephrased_id is None:
            # Original data
            grouped_data[test_id]["original_evaluation"] = evaluation
            grouped_data[test_id]["original_trajectory"] = trajectory
        elif repeated_id is not None:
            # Repeated data - store at specific position
            grouped_data[test_id]["repeated_evaluations"][repeated_id] = evaluation
            grouped_data[test_id]["repeated_trajectories"][repeated_id] = trajectory
            grouped_data[test_id]["max_repeated_id"] = max(
                grouped_data[test_id]["max_repeated_id"], repeated_id
            )
        elif rephrased_id is not None:
            # Rephrased data - store at specific position
            grouped_data[test_id]["rephrased_evaluations"][rephrased_id] = evaluation
            grouped_data[test_id]["rephrased_trajectories"][rephrased_id] = trajectory
            grouped_data[test_id]["max_rephrased_id"] = max(
                grouped_data[test_id]["max_rephrased_id"], rephrased_id
            )

    # Convert to TestEvaluation instances
    test_evaluations = []
    for test_id, data in grouped_data.items():
        # Ensure we have original data for each test
        if data["original_evaluation"] is None or data["original_trajectory"] is None:
            raise ValueError(f"Missing original evaluation or trajectory for test_id: {test_id}")

        # Convert dictionaries to ordered lists with proper positioning
        repeated_evaluations = []
        repeated_trajectories = []
        if data["max_repeated_id"] >= 0:
            for i in range(data["max_repeated_id"] + 1):
                repeated_evaluations.append(data["repeated_evaluations"].get(i))
                repeated_trajectories.append(data["repeated_trajectories"].get(i))

        rephrased_evaluations = []
        rephrased_trajectories = []
        if data["max_rephrased_id"] >= 0:
            for i in range(data["max_rephrased_id"] + 1):
                rephrased_evaluations.append(data["rephrased_evaluations"].get(i))
                rephrased_trajectories.append(data["rephrased_trajectories"].get(i))
        robustness_results = (
            await robustness_evaluator.evaluate_runs(
                original_trajectory=data["original_trajectory"],
                repeated_trajectories=repeated_trajectories,
                rephrased_trajectories=rephrased_trajectories,
            )
            if robustness_evaluator
            else []
        )
        test_evaluation = TestEvaluation(
            test_id=test_id,
            global_results=robustness_results,
            original_conversation_evaluation=data["original_evaluation"],
            original_multiturn_trajectory=data["original_trajectory"],
            repeated_conversation_evaluations=repeated_evaluations,
            repeated_multiturn_trajectories=repeated_trajectories,
            rephrased_conversation_evaluations=rephrased_evaluations,
            rephrased_multiturn_trajectories=rephrased_trajectories,
        )
        test_evaluations.append(test_evaluation)

    return test_evaluations


class DatasetEvaluationPipeline(BaseModel):
    conversation_eval_pipeline: str
    _conversation_pipeline: ConversationEvaluationPipeline = None

    @model_validator(mode="after")
    def init_conversation_pipeline(self) -> Self:
        self._conversation_pipeline = ConversationEvaluationPipeline.from_name(
            name=self.conversation_eval_pipeline
        )
        return self

    async def evaluate_dataset(
        self,
        eval_dataset: EvaluationDataset,
        metrics: list[Metric],
        fact_extractors: list[FactExtractor],
        intents_map: dict[str, list[str]] | None = None,
        batch_size: int | None = None,
        extractors_llm_provider: BaseLLMProvider | None = None,
        extractors_generation_params: dict | None = None,
        ground_truth_llm_judge: LLMJudge | None = None,
        ground_truth_judge_generation_params: dict | None = None,
        add_default_extractors: bool = True,
        add_default_metrics: bool = True,
        *args,
        **kwargs,
    ) -> list[TestEvaluation]:
        if extractors_generation_params is None:
            extractors_generation_params = {}
        if ground_truth_judge_generation_params is None:
            ground_truth_judge_generation_params = {}
        semaphore = None if batch_size is None else asyncio.Semaphore(batch_size)
        flattened_data = eval_dataset.flattened_data
        single_run_metrics = []
        multi_run_metrics = []
        for metric in metrics:
            if metric.scope == MetricScope.MULTIRUN:
                multi_run_metrics.append(metric)
            else:
                single_run_metrics.append(metric)
        pipelines_coroutines = []
        test_ids = []
        repeated_ids = []
        rephrased_ids = []
        for data_point in flattened_data.data_points:
            data_point_metrics = (
                single_run_metrics
                + data_point.get_ground_truth_metrics(
                    llm_judge=ground_truth_llm_judge,
                    generation_params=ground_truth_judge_generation_params,
                )
                + data_point.point_metrics
                if add_default_metrics
                else copy.deepcopy(metrics) + data_point.point_metrics
            )
            data_point_fact_extractors = (
                fact_extractors
                + data_point.get_default_extractors(
                    llm_provider=extractors_llm_provider,
                    generation_params=extractors_generation_params,
                )
                + data_point.point_extractors
                if add_default_extractors
                else copy.deepcopy(fact_extractors) + data_point.point_extractors
            )
            pipeline_coroutine = self._conversation_pipeline(
                *args,
                messages=data_point.messages,
                metrics=data_point_metrics,
                fact_extractors=data_point_fact_extractors,
                semaphore=semaphore,
                intents_map=intents_map,
                **data_point.test_config,
                **kwargs,
            )
            pipelines_coroutines.append(pipeline_coroutine)
            test_ids.append(data_point.test_id)
            repeated_ids.append(data_point.repeated_id)
            rephrased_ids.append(data_point.rephrased_id)
        results = await asyncio.gather(*pipelines_coroutines)
        for i, r in enumerate(results):
            r.evaluation.conversation_config = flattened_data.data_points[i].test_config
        robustness_evaluator = (
            RobustnessEvaluator(metrics=multi_run_metrics) if multi_run_metrics else None
        )
        grouped_results = await group_results_by_ids(
            results,
            test_ids,
            repeated_ids,
            rephrased_ids,
            robustness_evaluator=robustness_evaluator,
        )
        return grouped_results
