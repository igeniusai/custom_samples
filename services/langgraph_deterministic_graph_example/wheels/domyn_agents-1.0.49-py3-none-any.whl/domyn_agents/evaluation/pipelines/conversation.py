import asyncio
import contextlib
import uuid
from abc import ABC, abstractmethod
from typing import ClassVar, Self

from pydantic import BaseModel

from domyn_agents.agents import Agent
from domyn_agents.core import BaseEvent, ExecutionEventType, FeedbackAction, Part
from domyn_agents.evaluation.evaluator import ConversationEvaluator
from domyn_agents.evaluation.extractors import FactExtractor
from domyn_agents.evaluation.metrics.base import Metric
from domyn_agents.evaluation.results import MultiTurnEvaluation, Result
from domyn_agents.evaluation.trajectory import ActionComparisonMode, MultiTurnTrajectory
from domyn_agents.runner import Runner


class ConversationEvaluation(BaseModel):
    evaluation: MultiTurnEvaluation
    trajectory: MultiTurnTrajectory


class ConversationEvaluationPipeline(ABC, BaseModel):
    name: ClassVar[str]
    _registry: ClassVar[dict[str, type[Self]]] = {}
    failure_result: str = "failed_conversation"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        value = getattr(cls, "name", None)
        if not isinstance(value, str) or not value:
            raise TypeError(f"{cls.__name__}.name must be a non-empty str ClassVar")
        cls._registry[value] = cls

    @abstractmethod
    async def get_conversation(self, *args, **kwargs) -> list[BaseEvent]:
        """Retrieve or generate a conversation and return the list of events."""
        ...

    async def __call__(
        self,
        metrics: list[Metric],
        fact_extractors: list[FactExtractor],
        intents_map: dict[str, list[str]] | None = None,
        comparison_mode: ActionComparisonMode = ActionComparisonMode.ACTION_NAME,
        semaphore: asyncio.Semaphore | None = None,
        *args,
        **kwargs,
    ) -> ConversationEvaluation:
        """Execute the evaluation pipeline and return the evaluation results."""
        if semaphore is None:
            semaphore = contextlib.nullcontext()
        async with semaphore:  # TODO: IF NEEDED THIS COULD BE SPLIT INTO TWO SEMAPHORES ONE FOR GETTING THE CONVERSATION AND ONE FOR THE EVALUATION
            events = await self.get_conversation(*args, **kwargs)
            if events:
                evaluator = ConversationEvaluator(metrics=metrics)
                multiturn_trajectory = await MultiTurnTrajectory.from_conversation(
                    conversation_events=events,
                    fact_extractors=fact_extractors,
                    intents_map=intents_map,
                    comparison_mode=comparison_mode,
                )
                evaluation = await evaluator.evaluate_trajectory(
                    multiturn_trajectory=multiturn_trajectory
                )
                evaluation.results.append(Result(name=self.failure_result, value=0))
            else:
                multiturn_trajectory = MultiTurnTrajectory(trajectories=[])
                evaluation = MultiTurnEvaluation(
                    results=[Result(name=self.failure_result, value=1)], turn_level_evaluations=[]
                )
        return ConversationEvaluation(evaluation=evaluation, trajectory=multiturn_trajectory)

    @classmethod
    def from_name(cls, name: str, *args, **kwargs) -> Self:
        if name not in cls._registry:
            raise ValueError(
                f"{cls.__name__} with name '{name}' not registered. Make sure you have imported the corresponding subclass."
            )
        pipeline_cls = cls._registry[name]
        return pipeline_cls(*args, **kwargs)


class PresetConversationEvaluationPipeline(ConversationEvaluationPipeline):
    name: ClassVar[str] = "preset_conversation"

    async def get_conversation(
        self,
        runner: Runner,
        root_agent: Agent,
        messages: list[str],
        conversation_id: str | None = None,
        user_id: str | None = None,
        run_config: dict | None = None,
        application_name: str = "Default eval application",
        verbose: bool = True,
    ) -> list[BaseEvent]:
        if run_config is None:
            run_config = {}
        if conversation_id is None:
            conversation_id = str(uuid.uuid4())
        if user_id is None:
            user_id = str(uuid.uuid4())

        for message in messages:
            input_event = BaseEvent(
                event_type=ExecutionEventType.USER_INPUT,
                author="user",
                content=[Part(text=message)],
            )
            stop = False
            while True:
                need_feedback = False
                async for event in runner.run(
                    application_name=application_name,
                    user_id=user_id,
                    root=root_agent,
                    user_input=input_event,
                    conversation_id=conversation_id,
                    run_config=run_config,
                ):
                    if event.event_type == ExecutionEventType.RESPONSE:
                        for content in event.content:
                            if content.thought:
                                print(f"\033[94mThought ({event.author}): {content.thought}")
                            if content.text:
                                print(f"\033[94mTo user ({event.author}):\033[0m {content.text}")
                        stop = True
                        break

                    elif event.event_type == ExecutionEventType.TOOL_START and verbose:
                        print(f"\033[33mThought: {event.action.thought}\033[0m")
                        print(
                            f"Action:{event.action.name} with parameters {event.action.parameters!s}"
                        )
                    elif event.event_type == ExecutionEventType.TOOL_END and verbose:
                        print(f"\033[91mAction result: {event.action.observation}\033[0m")
                        if event.action:
                            print(f"Tool END -({event.author}): {event.action}")
                    elif event.event_type == ExecutionEventType.TOOL_NEEDS_FEEDBACK:
                        print(f"Tool NEED FEEDBACK -({event.author}): {event.action}")
                        need_feedback = True
                    elif event.event_type in (
                        ExecutionEventType.AGENT_CALL,
                        ExecutionEventType.AGENT_START,
                    ):
                        print(f"\033[95m{event}\033[0m")
                    else:
                        if verbose:
                            print("Other event:")
                            print(event)
                    if verbose:
                        print()
                if stop:
                    break
                # runner chiude connessione
                print("----- END OF ITERATION -----")
                input_event = None
                if need_feedback:
                    if event.event_type == ExecutionEventType.TOOL_NEEDS_FEEDBACK:
                        feedback_action: FeedbackAction = event.action
                        # AUTOAPPROVE TOOLS WITHOUT CHANGING THE PARAMETERS
                        feedback_action.approve = True
                        input_event = BaseEvent(
                            event_type=ExecutionEventType.TOOL_FEEDBACK,
                            author="user",
                            action=feedback_action,
                        )

                    else:
                        print("\033[92mYour input (The agent want a Feedback): \033[0m", end="")
                else:
                    print("\033[92mYour input: \033[0m", end="")

                if input_event is None:
                    next_input = input()
                    input_event = BaseEvent(
                        event_type=ExecutionEventType.USER_INPUT,
                        author="user",
                        content=[Part(text=next_input)],
                    )

        conversation = await runner.conversation_manager.get_conversation(
            application_name=application_name, conversation_id=conversation_id, user_id=user_id
        )
        return conversation.events_history
