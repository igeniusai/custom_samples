import inspect
from collections.abc import AsyncGenerator
from typing import Any, TypeVar

from pydantic import Field

from domyn_agents.agents import HandoffVisibility
from domyn_agents.core import AgentDescription, BaseEvent
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.hooks.function_hook import FunctionHook

T = TypeVar("T")


class WrappedAgent(BaseAgent):
    """A class that wraps another class like an Agent"""

    type: str = "WrappedAgent"

    name: str = Field(..., description="Name of the agent")
    description: str = Field(..., description="Description of the agent")

    wrapped_object: T

    default_execute_agent_function: str = Field(
        default="execute", description="Default execute agent function"
    )

    max_iterations: int = Field(default=3, description="Maximum number of iterations")
    pre_hooks: list[FunctionHook] = Field(
        default_factory=list, description="Hooks to be executed before the agent execution"
    )
    post_hooks: list[FunctionHook] = Field(
        default_factory=list, description="Hooks to be executed after the agent execution"
    )
    handoff_visibility: HandoffVisibility = Field(
        default=HandoffVisibility.STANDARD, description="Handoff visibility level"
    )

    # classe per usare direttamente i metodi del wrapped object
    def __getattr__(self, name):
        # Only delegate to wrapped_object if the attribute doesn't exist in this class
        if hasattr(self.wrapped_object, name):
            return getattr(self.wrapped_object, name)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    @property
    def invocations_parameters(self) -> dict[str, Any]:
        """Default parameters for agent invocation as function."""
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The specific task to perform by the agent",
                },
            },
            "required": ["task"],
        }

    @property
    def invocation_json_schema(self) -> dict:
        schema = {
            "properties": {
                self.name_string: {"const": self.name, "type": "string"},
                self.parameters_string: self.invocations_parameters,
            },
            "required": [self.parameters_string],
            "description": self.description,
        }
        return schema

    def get_agent_description(self) -> str:
        return AgentDescription(
            name=self.name,
            description=self.description,
            invocation_json_schema=self.invocation_json_schema,
            invocation_parameters=self.invocations_parameters,
        )

    async def execute(self, context: InteractionContext) -> AsyncGenerator[BaseEvent, None]:
        if inspect.isfunction(self.wrapped_object):
            async for event in self.wrapped_object(context):
                yield event

        if execute_func_name := getattr(self, "default_execute_agent_function", "_execute"):
            # Call the default execute function
            arguments = {
                "interaction_context": context,
                "context": context,
                "run_config": context.run_config,
                "state": context.state,
            }

            fun = getattr(self.wrapped_object, execute_func_name)

            async for event in fun(
                **{
                    k: v
                    for k, v in arguments.items()
                    if k in list(inspect.signature(fun).parameters.keys())
                }
            ):
                yield event

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "WrappedAgent":
        """Create a WrappedAgent from a configuration dictionary.

        Supported config forms:
            Minimal function wrapper:
                {
                    "name": "MyFuncAgent",
                    "description": "Wraps a function",
                    "callable": "package.module:function_name",
                    "default_execute_agent_function": "execute"  # optional override
                }

            Object wrapper:
                {
                    "name": "MyObjAgent",
                    "description": "Wraps an object",
                    "object": {
                        "class": "package.module:ClassName" | "package.module.ClassName",
                        "init": {"param": "value"}  # optional
                    },
                    "default_execute_agent_function": "custom_execute"  # optional
                }

            Direct object/function:
                {
                    "name": "X",
                    "description": "...",
                    "wrapped_object": existing_callable_or_object
                }
        """
        raise NotImplementedError("WrappedAgent.from_config not implemented yet")


WrappedAgent.model_rebuild()  # type: ignore
