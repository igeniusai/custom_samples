"""Base classes for agents in the domyn agents framework."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


@dataclass
class FunctionCall:
    """Function call representation."""

    name: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class Content:
    """Content representation."""

    role: str  # "user", "assistant", "system", "tool"
    parts: list[str | FunctionCall] = field(default_factory=list)


class HandoffVisibility(Enum):
    """Enum for handoff visibility levels."""

    GLOBAL = "global"
    PEERS = "peers"
    STANDARD = "standard"


__all__ = [
    "Content",
    "FunctionCall",
    "HandoffVisibility",
]
