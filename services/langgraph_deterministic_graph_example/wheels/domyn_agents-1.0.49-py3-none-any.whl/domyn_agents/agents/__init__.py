"""Agents package for domyn agents framework."""

from collections.abc import Callable
from typing import Any

from domyn_agents.agents.agent import Agent
from domyn_agents.agents.base import HandoffVisibility
from domyn_agents.agents.delegate_agent import DelegateAgent

# ---------------------------------------------------------------------------
# Agent-type plugin registry
# ---------------------------------------------------------------------------


def _build_delegate(config: dict[str, Any], _save: bool) -> "Agent | DelegateAgent":
    return DelegateAgent.model_validate(config)


def _build_agent(config: dict[str, Any], save_in_registry: bool) -> "Agent | DelegateAgent":
    return Agent.from_config(config, save_in_registry=save_in_registry)


_AGENT_TYPE_REGISTRY: dict[str, Callable[[dict[str, Any], bool], "Agent | DelegateAgent"]] = {
    "delegate": _build_delegate,
    "agent": _build_agent,
    None: _build_agent,  # type: ignore[dict-item]  # None key = no type specified
}


def register_agent_type(
    type_name: str,
    factory: Callable[[dict[str, Any], bool], "Agent | DelegateAgent"],
) -> None:
    """Register a custom agent type for use in YAML/dict configs.

    Parameters
    ----------
    type_name:
        The string that appears as ``type`` in an agent config dict.
    factory:
        A callable ``(config, save_in_registry) -> Agent | DelegateAgent``.

    Example (in your external service, before loading any config)::

        from domyn_agents.agents import register_agent_type
        from my_package import MyDelegateAgent

        register_agent_type("my_delegate", lambda cfg, save: MyDelegateAgent.model_validate(cfg))
    """
    _AGENT_TYPE_REGISTRY[type_name] = factory


class AgentFactory:
    @staticmethod
    def from_config(config: dict[str, Any], save_in_registry: bool) -> "Agent | DelegateAgent":
        """Create an agent from configuration."""
        agent_type = config.get("type")
        factory = _AGENT_TYPE_REGISTRY.get(agent_type)
        if factory is None:
            raise ValueError(
                f"Unknown agent type: {agent_type!r}. "
                "Register a custom factory with domyn_agents.agents.register_agent_type()."
            )
        obj: Agent | DelegateAgent = factory(config, save_in_registry)

        if save_in_registry:
            from domyn_agents.registry import get_agent_registry

            get_agent_registry().register_agent(obj.name, obj)

        return obj


__all__ = ["Agent", "AgentFactory", "DelegateAgent", "HandoffVisibility", "register_agent_type"]
