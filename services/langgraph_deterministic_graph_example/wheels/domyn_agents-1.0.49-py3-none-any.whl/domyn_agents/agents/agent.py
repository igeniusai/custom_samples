from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator, Awaitable, Coroutine
from typing import Any, cast

from pydantic import ConfigDict, Field, field_serializer, field_validator

from domyn_agents.agents.base import HandoffVisibility
from domyn_agents.agents.delegate_agent import DelegateAgent
from domyn_agents.core import AgentDescription, BaseEvent
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.hooks import HookFactory
from domyn_agents.hooks.base import HookPhase, HookType
from domyn_agents.hooks.function_hook import FunctionHook
from domyn_agents.llm import LLMProviderFactory
from domyn_agents.llm.base import BaseLLMProvider
from domyn_agents.logger import get_logger
from domyn_agents.memory.managers import BaseMemoryManager, MemoryExecutionMode
from domyn_agents.planner_strategy import PlannerStrategyFactory
from domyn_agents.planner_strategy.base import BasePlannerStrategy
from domyn_agents.planner_strategy.context_management.full_messages import FullMessageContext
from domyn_agents.planner_strategy.prompting.structural_tags_prompting import (
    StructuralTagMessagePrompting,
)
from domyn_agents.tools import Tool
from domyn_agents.tools.base import ConfigParam
from domyn_agents.tools.delegate_tool import DelegateTool
from domyn_agents.tools.function_tool import FunctionTool
from domyn_agents.tools.mcp.mcp_config import MCPServerStreamableHTTPConfig
from domyn_agents.tools.mcp.mcp_tool import MCPTool
from domyn_agents.tools.streamable_function_tool import (
    StreamableFunctionTool,
)


def _default_planner_factory():
    """Factory per creare ReactPlannerStrategy con lazy import."""
    from domyn_agents.planner_strategy.react import ReactPlannerStrategy

    return ReactPlannerStrategy(
        context_manager=FullMessageContext(
            prompting=StructuralTagMessagePrompting(),
            narrow_non_visible_agents=True,
            name="default_full_message_context",
        )
    )


class Agent(BaseAgent):
    """Base class for all agents - serves as a resource container."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    type: str = "Agent"

    name: str = Field(..., description="Name of the agent", min_length=1, max_length=30)
    planner: BasePlannerStrategy = Field(
        default_factory=_default_planner_factory,
        description="Planning strategy for the agent, React rewoo or others",
    )
    description: str = Field(..., description="Description of the agent", max_length=1000)
    instruction: str | Awaitable[str] = Field(
        ..., description="Instruction for the agent", max_length=2000
    )
    llm_provider: BaseLLMProvider = Field(..., description="LLM provider")
    tools: list[FunctionTool | DelegateTool] = Field(
        default_factory=list, description="Available tools"
    )
    sub_agents: list[Agent | DelegateAgent | str] = Field(
        default_factory=list, description="Sub-agents"
    )  # type: ignore[assignment]
    max_iterations: int = Field(default=3, description="Maximum number of iterations")
    mcp_servers: list[MCPServerStreamableHTTPConfig] = Field(
        default_factory=list,
        description="MCP server configurations for auto-fetching tools",
    )
    hooks: list[FunctionHook] = Field(
        default_factory=list, description="Hooks to be executed during the agent execution"
    )
    # output model
    handoff_visibility: HandoffVisibility = Field(
        default=HandoffVisibility.STANDARD, description="Handoff visibility level"
    )
    memory_manager: BaseMemoryManager | None = None

    default_execute_agent_function: str = Field(
        default="_execute", description="Default execute agent function"
    )

    def model_post_init(self, __context: Any) -> None:
        """Called after model initialization to add custom tools."""
        if self.memory_manager:
            if self.memory_manager.execution_mode == MemoryExecutionMode.AGENTIC:
                memory_tool = FunctionTool(
                    name="remember",
                    description="Store relevant information to the agent's memory for future use. Use this proactively whenever the user reveals information about themselves, their preferences, interests, or opinions — even if mentioned in passing.",
                    func=self.memory_manager.remember,  # type: ignore
                    config_params=[
                        ConfigParam(name="agent", value=self),
                    ],
                )
                self.tools.append(memory_tool)
            elif self.memory_manager.execution_mode == MemoryExecutionMode.AUTOMATIC:
                memory_post_hook = FunctionHook(
                    name="update_memory",
                    fun=self.memory_manager.update_memory,  # type: ignore
                    trigger=HookPhase.POST_AGENT_CALL,
                    type=HookType.LISTENER,
                )
                self.hooks.append(memory_post_hook)

    @property
    def pre_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.PRE_AGENT_CALL]

    @property
    def post_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.POST_AGENT_CALL]

    @property
    def on_event_hooks(self) -> list[FunctionHook]:
        return [h for h in self.hooks if h.trigger == HookPhase.ON_AGENT_EVENT]

    @field_validator("llm_provider", mode="wrap")
    @classmethod
    def validate_llm_provider(cls, v: Any, handler: Any, info: Any) -> Any:
        """Validate and convert llm_provider from dict to concrete implementation using type field."""

        if isinstance(v, BaseLLMProvider):
            return v

        # Handle dict deserialization using type field
        if isinstance(v, dict):
            provider_type = v.get("type", None)
            if provider_type:
                try:
                    return LLMProviderFactory.from_config(v, save_in_registry=False)

                except Exception as e:
                    get_logger().warning(
                        f"Warning: Could not deserialize LLM provider type '{provider_type}': {e}"
                    )

        try:
            return handler(v)
        except Exception:
            return v

    @field_serializer("llm_provider")
    def serialize_llm_provider(self, value: Any) -> Any:
        """Serialize llm_provider to dict with automatic type detection."""
        if hasattr(value, "model_dump"):
            serialized = value.model_dump()
            if hasattr(value, "__class__"):
                # Automatically add the class name as type
                serialized["type"] = value.__class__.__name__
            return serialized
        return value

    @field_validator("planner", mode="wrap")
    @classmethod
    def validate_planner(cls, v: Any, handler: Any, info: Any) -> Any:
        """Validate and convert planner from dict to concrete implementation using type field."""

        if isinstance(v, BasePlannerStrategy):
            return v

        # Handle dict deserialization using type field
        if isinstance(v, dict):
            planner_type = v.get("type")
            if planner_type:
                try:
                    return PlannerStrategyFactory.from_config(v, save_in_registry=False)

                except Exception as e:
                    get_logger().warning(
                        f"Warning: Could not deserialize planner type '{planner_type}': {e}"
                    )

        try:
            return handler(v)
        except Exception:
            return v

    @field_serializer("planner")
    def serialize_planner(self, value: Any) -> Any:
        """Serialize planner to dict with automatic type detection."""
        if hasattr(value, "model_dump"):
            serialized = value.model_dump()
            if hasattr(value, "__class__"):
                # Automatically add the class name as type
                serialized["type"] = value.__class__.__name__
            return serialized
        return value

    @field_validator("memory_manager", mode="wrap")
    @classmethod
    def validate_memory_manager(cls, v: Any, handler: Any, info: Any) -> BaseMemoryManager | None:
        """Validate and reconstruct memory_manager from dict if needed."""
        logger = get_logger()
        if v is None:
            return None

        if isinstance(v, BaseMemoryManager):
            return v

        if isinstance(v, dict):
            manager_type = v.get("type")
            if manager_type is None:
                logger.warning("Memory manager config missing 'type' field")
                return None

            manager_class = BaseMemoryManager._registry.get(manager_type)
            if manager_class is None:
                logger.warning("Unknown memory manager type '%s'", manager_type)
                return None

            try:
                # Use from_config pattern (consistent with BaseTool)
                return manager_class.from_config(v)
            except Exception as e:
                logger.warning(
                    "Could not deserialize memory manager type '%s': %s", manager_type, e
                )
                return None

        try:
            return handler(v)
        except Exception:
            return None

    @field_serializer("memory_manager")
    def serialize_memory_manager(self, value) -> dict[str, Any] | None:
        """Serialize memory_manager to dict with automatic type detection."""
        if value is None:
            return None
        if hasattr(value, "model_dump"):
            return value.model_dump()
        return None

    @property
    def invocations_parameters(self) -> dict[str, Any]:
        """Default parameters for agent invocation as function."""
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The specific task to perform by the agent. This is the more specific request for the agent to perform, with all the necessary details.",
                },
            },
            "required": ["task"],
        }

    @property
    def invocation_json_schema(self) -> dict:
        schema = {
            "properties": {
                self.name_string: {"const": self.name, "type": "string"},
                self.parameters_string: self.invocations_parameters,
            },
            "required": [self.parameters_string],
            "description": self.description,
        }
        return schema

    async def initialize_mcp_tools(self) -> None:
        """Initialize and fetch tools from configured MCP servers.

        This method should be called after agent creation to automatically
        discover and add tools from configured MCP servers.
        """

        tasks: list[Coroutine[Any, Any, Any]] = []

        async def safe_tool_init(t: MCPTool) -> None:
            try:
                await t.initialize()
            except Exception as e:
                get_logger().warning(
                    f"Could not initialize MCP tool {t.name} from {t.server_url}: {e}"
                )
                # self.tools.remove(t)

        mcp_tools = filter(lambda x: isinstance(x, MCPTool), cast(list[MCPTool], self.tools))
        init_tasks = map(safe_tool_init, mcp_tools)
        tasks.extend(init_tasks)

        new_tools = []
        for s in filter(lambda s: s.tool_autodiscovery, self.mcp_servers):
            # Remove existing MCPTools from this server
            new_tools = [
                t
                for t in self.tools
                if not (isinstance(t, MCPTool) and t.server_url == s.url and t.group == s.name)
            ]

            try:
                discovered_tools = await s.discover_tools()
                for tool_schema in discovered_tools:
                    mcp_tool = MCPTool(
                        server_url=s.url,
                        tool_name=tool_schema.name,
                        group=s.name,
                        use_oauth=s.use_oauth,
                        oauth_scopes=s.oauth_scopes,
                        oauth_client_name=s.oauth_client_name,
                        headers=s.headers,
                    )
                    new_tools.append(mcp_tool)
                    tasks.append(safe_tool_init(mcp_tool))

                self.tools = new_tools
            except Exception:
                get_logger().warning(f"Could not discover tools from MCP server {s.url}")

        await asyncio.gather(*tasks)

    async def execute(
        self, context: InteractionContext
    ) -> AsyncGenerator[tuple[BaseEvent, InteractionContext], None]:
        """Bidirectional wrapper: propagates asend() values from runner to _execute."""
        func_name = getattr(self, "default_execute_agent_function", "_execute")
        inner = getattr(self, func_name)(context)
        sent: Any = None
        while True:
            try:
                event = await inner.asend(sent)
                sent = yield event, context
            except StopAsyncIteration:
                break

    async def _execute(self, context: InteractionContext) -> AsyncGenerator[BaseEvent, None]:
        """Bidirectional wrapper: propagates asend() values from execute() to the planner."""
        inner = self.planner.execute(self, context)
        sent: Any = None
        while True:
            try:
                event = await inner.asend(sent)
                sent = yield event
            except StopAsyncIteration:
                break

    def get_tool_by_name(self, tool_name: str) -> FunctionTool | DelegateTool | None:
        """Get a tool by name."""

        matching_tools = [t for t in self.tools if t.name == tool_name]

        # if not found, try to check if it was included with a namespace. Using '.' as separator as per SEP-986
        # https://github.com/modelcontextprotocol/modelcontextprotocol/issues/986
        matching_tool: FunctionTool | DelegateTool | None = None
        if len(matching_tools) == 1:
            matching_tool = matching_tools[0]
        else:
            tool_name_parts = tool_name.split(".")
            tool_name_short = tool_name_parts[-1]
            tool_namespaces = ".".join(tool_name_parts[:-1])
            matching_tool = next(
                (t for t in self.tools if t.name == tool_name_short and t.group == tool_namespaces),
                None,
            )

        return matching_tool

    def get_sub_agent_by_name(self, agent_name: str) -> Agent | None:
        """Get a sub-agent by name."""
        return next((agent for agent in self.sub_agents if agent.name == agent_name), None)

    def remove_agent_by_name(self, agent_name: str) -> None:
        """Remove a sub-agent by name."""
        agent = self.get_sub_agent_by_name(agent_name)
        if not agent:
            raise ValueError(f"Agent {agent_name} not found as sub agent of {self.name}")

        self.sub_agents.remove(agent)

    def get_agent_description(self) -> AgentDescription:
        return AgentDescription(
            name=self.name,
            description=self.description,
            invocation_json_schema=self.invocation_json_schema,
            invocation_parameters=self.invocations_parameters,
        )

    def __hash__(self):
        return self.name.__hash__()

    @classmethod
    def from_config(cls, config: dict[str, Any], save_in_registry: bool = False) -> Agent:
        """Create a WrappedAgent from config.

        Config keys:
          - name: name of the agent
          - description: description of the agent
          - instruction: system / agent instruction
          - llm_provider: provider config or instance (expects key 'type' for dict)
          - planner_strategy: dict with planner params (currently only ReactPlannerStrategy)
          - tools: list of tool specifications. Each item can be:
                * FunctionTool / StreamableFunctionTool instance
                * dict with at least: name, type (function|streamable_function) and path or callable
          - subagents: list of Agent instances OR dict configs (recursive)
          - hooks: list of hook specs (instances or dicts)
          - handoff_visibility: one of global|peers|standard
          - max_iterations: override agent level iterations (optional)
          - memory_manager: dict with 'type' key, BaseMemoryManager instance, or None.
                Deserialization is handled by the field_validator (registry lookup + from_config).

        """
        # Defensive copy to avoid mutating caller data
        cfg = dict(config)

        required = ["name", "description", "instruction", "llm_provider"]
        missing = [k for k in required if k not in cfg]
        if missing:
            raise ValueError(f"Missing required agent config keys: {missing}")

        # ------------------------------------------------------------------
        # Build LLM provider
        # ------------------------------------------------------------------
        llm_provider_cfg = cfg.get("llm_provider")
        if isinstance(llm_provider_cfg, BaseLLMProvider):
            llm_provider = llm_provider_cfg
        elif isinstance(llm_provider_cfg, dict):
            llm_provider = LLMProviderFactory.from_config(
                llm_provider_cfg, save_in_registry=save_in_registry
            )
        else:
            raise ValueError("Invalid llm_provider specification")

        # ------------------------------------------------------------------
        # Planner strategy
        # ------------------------------------------------------------------
        planner_cfg = cfg.get("planner_strategy") or {}
        if isinstance(planner_cfg, BasePlannerStrategy):
            planner = planner_cfg
        elif isinstance(planner_cfg, dict):
            planner = PlannerStrategyFactory.from_config(
                planner_cfg, save_in_registry=save_in_registry
            )
        else:
            raise ValueError("Invalid planner_strategy specification")

        # ------------------------------------------------------------------
        # Hooks (agent level)
        # ------------------------------------------------------------------

        def _build_agent_hooks(
            items: list[Any],
        ) -> list[FunctionHook]:
            built: list[FunctionHook] = []
            for h in items:
                if isinstance(h, FunctionHook):
                    built.append(h)
                elif isinstance(h, dict):
                    built.append(HookFactory.from_config(h, save_in_registry=save_in_registry))
                else:
                    raise ValueError(f"Unsupported agent hook spec: {h}")
            return built

        # PRE Hooks
        hooks_cfg = cfg.get("hooks", []) or []
        hooks = _build_agent_hooks(hooks_cfg)

        # ------------------------------------------------------------------
        # Tools
        # ------------------------------------------------------------------

        tool_specs = cfg.get("tools", []) or []
        built_tools: list[FunctionTool | DelegateTool] = []
        for spec in tool_specs:
            if isinstance(spec, FunctionTool | StreamableFunctionTool | MCPTool):
                tool_obj = spec
            elif isinstance(spec, dict):
                tool_obj = Tool.from_config(spec, save_in_registry=save_in_registry)
            else:
                raise ValueError(f"Unsupported tool spec: {spec}")

            built_tools.append(tool_obj)

        # ------------------------------------------------------------------
        # Sub agents (recursive)
        # ------------------------------------------------------------------
        sub_agents_cfg = cfg.get("subagents") or cfg.get("sub_agents") or []
        built_sub_agents: list[Agent] = []
        for sub in sub_agents_cfg:
            if isinstance(sub, str):
                built_sub_agents.append(sub)
            elif isinstance(sub, BaseAgent):
                built_sub_agents.append(sub)  # type: ignore[arg-type]
            elif isinstance(sub, dict):
                built_sub_agents.append(cls.from_config(sub, save_in_registry=save_in_registry))
            else:
                raise ValueError(f"Unsupported subagent spec: {sub}")

        # ------------------------------------------------------------------
        # MCP Servers
        # ------------------------------------------------------------------
        mcp_servers_cfg = cfg.get("mcp_servers", []) or []
        built_mcp_servers: list[MCPServerStreamableHTTPConfig] = []
        for server_spec in mcp_servers_cfg:
            if isinstance(server_spec, MCPServerStreamableHTTPConfig):
                built_mcp_servers.append(server_spec)
            elif isinstance(server_spec, dict):
                built_mcp_servers.append(MCPServerStreamableHTTPConfig.from_dict(server_spec))
            else:
                raise ValueError(f"Unsupported MCP server spec: {server_spec}")

        # ------------------------------------------------------------------
        # Visibility
        # ------------------------------------------------------------------
        hv = cfg.get("handoff_visibility", HandoffVisibility.STANDARD)
        if isinstance(hv, str):
            hv = HandoffVisibility(hv.lower())

        agent = cls(
            name=cfg["name"],
            description=cfg["description"],
            instruction=cfg["instruction"],
            llm_provider=llm_provider,
            planner=planner,
            tools=built_tools,
            sub_agents=built_sub_agents,
            hooks=hooks,
            mcp_servers=built_mcp_servers,
            handoff_visibility=hv,  # type: ignore[arg-type]
            max_iterations=cfg.get(
                "max_iterations",
                planner.max_iterations if hasattr(planner, "max_iterations") else 3,
            ),
            memory_manager=cfg.get("memory_manager"),
            stream=cfg.get("stream", False),
        )
        return agent


Agent.model_rebuild()  # type: ignore
