from typing import Any

from domyn_agents.core.interfaces import BaseAgent


class AgentRegistry:
    """Registry for agent instances."""

    def __init__(self):
        self._agents: dict[str, BaseAgent] = {}

    def register_agent(self, name: str, agent: BaseAgent | Any) -> None:
        """Register agent instance."""

        self._agents[name] = agent

    def get_agent(self, name: str) -> BaseAgent:
        """Get agent by name."""

        from domyn_agents.agents.agent import Agent
        from domyn_agents.agents.wrapped import WrappedAgent

        _c = self._agents.get(name)
        if not _c:
            raise KeyError(f"Agent '{name}' not found in registry.")
        if isinstance(_c, Agent | WrappedAgent):
            return _c
        else:
            return _c()

    def list_agent_names(self) -> list[str]:
        """List all registered agent names."""
        return list(self._agents.keys())

    def list_agents(self) -> list[BaseAgent]:
        """List all registered agents."""
        return list(self._agents.values())

    def clear(self) -> None:
        """Clear all registered agents."""
        self._agents.clear()

    def __setitem__(self, name: str, agent: BaseAgent) -> None:
        self.register_agent(name, agent)

    def __getitem__(self, name: str) -> BaseAgent:
        return self.get_agent(name)


_agents_registry = AgentRegistry()


def get_agent_registry() -> AgentRegistry:
    """Get the global tool registry instance."""
    return _agents_registry
