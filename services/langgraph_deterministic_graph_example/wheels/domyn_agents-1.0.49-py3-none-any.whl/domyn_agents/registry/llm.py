from typing import Any

from domyn_agents.llm.base import BaseLLMProvider


class LLMProviderRegistry:
    """Registry for LLM provider instances."""

    def __init__(self):
        self._providers: dict[str, BaseLLMProvider] = {}

    def register_llm_provider(self, name: str, provider: BaseLLMProvider | Any) -> None:
        """Register LLM provider instance."""

        self._providers[name] = provider

    def get_llm_provider(self, name: str) -> BaseLLMProvider:
        """Get LLM provider by name."""

        _c = self._providers.get(name)
        if isinstance(_c, BaseLLMProvider) or _c is None:
            return _c
        else:
            return _c()

    def list_llm_provider_names(self) -> list[str]:
        """List all registered LLM provider names."""
        return list(self._providers.keys())

    def list_llm_providers(self) -> list[BaseLLMProvider]:
        """List all registered LLM providers."""
        return [self.get_llm_provider(name) for name in self._providers]

    def clear(self) -> None:
        """Clear all registered LLM providers."""
        self._providers.clear()

    def __setitem__(self, name: str, provider: BaseLLMProvider) -> None:
        self.register_llm_provider(name, provider)

    def __getitem__(self, name: str) -> BaseLLMProvider:
        return self.get_llm_provider(name)


_llm_registry = LLMProviderRegistry()


def get_llm_registry() -> LLMProviderRegistry:
    """Get the global LLM provider registry instance."""
    return _llm_registry
