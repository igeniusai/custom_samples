from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, field_validator

from domyn_agents.core import BaseEvent, Part
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.exceptions import RestHookError


class Hook(BaseModel):
    name: str | None = None
    type: HookType
    trigger: HookPhase


class HookType(StrEnum):
    LISTENER = "listener"
    UPDATER = "updater"


class HookPhase(StrEnum):
    PRE_AGENT_CALL = "pre_agent_call"
    POST_AGENT_CALL = "post_agent_call"
    PRE_TOOL_CALL = "pre_tool_call"
    POST_TOOL_CALL = "post_tool_call"
    ON_AGENT_EVENT = "on_agent_event"


class InputFields(StrEnum):
    AGENT_INPUT = "agent_input"
    AGENT_NAME = "agent_name"
    LAST_EVENT = "last_event"
    CURRENT_EVENT = "current_event"
    INTERACTION_HISTORY = "interaction_history"
    INTERACTION_CONTEXT = "interaction_context"
    TOOL_NAME = "tool_name"
    TOOL_ARGS = "tool_args"
    TOOL_RESULT = "tool_result"
    ON_AGENT_EVENT = "on_agent_event"


class HookError(BaseModel):
    error_code: str | int
    error_message: str

    @classmethod
    def from_exception(cls, exception: Exception) -> Self:
        if isinstance(exception, RestHookError):
            error_code = exception.error_code
            error_message = exception.error_message
        else:
            error_code = exception.__class__.__name__
            error_message = str(exception)
        return cls(error_code=error_code, error_message=error_message)

    def __repr__(self) -> str:
        return f"Error_code: {self.error_code}, error_message: {self.error_message}"


class HookResult(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    success: bool = True
    emitted_content: list[Part] | dict | str | None = []
    error: HookError | None = None
    is_update: bool = False
    name: str | None = None
    # agent hook fields
    new_context: InteractionContext | None = None
    break_execution: bool = False
    # pre-tool hook fields
    new_tool_args: dict[str, Any] | None = None
    # post-tool hook fields
    new_result: Any = None  # ToolResult | None — type enforced at runtime
    # on_agent_event hook fields
    modified_event: BaseEvent | None = None

    @field_validator("new_result", mode="before")
    @classmethod
    def coerce_new_result(cls, v: Any) -> Any:
        if isinstance(v, dict):
            from domyn_agents.tools.base import ToolResult  # lazy to avoid circular import

            return ToolResult(**v)
        return v

    @field_validator("emitted_content", mode="before")
    @classmethod
    def process_content(cls, v: Any) -> list[Part]:
        if not v:
            return []
        if isinstance(v, dict):
            return [cls._dict_to_part(v)]
        if isinstance(v, list):
            if all(isinstance(item, Part) for item in v):
                return list(v)
            return [Part(text=str(v))]
        return [Part(text=str(v))]

    @staticmethod
    def _dict_to_part(v: dict) -> Part:
        from domyn_agents.core import GuardrailResult

        try:
            return Part(guardrail_result=GuardrailResult(**v))
        except Exception:
            pass
        try:
            part = Part(**v)
            if any(val is not None for val in part.model_dump().values()):
                return part
        except Exception:
            pass
        return Part(metadata=v)

    @staticmethod
    def _dict_to_part(v: dict) -> Part:
        from domyn_agents.core import GuardrailResult

        try:
            return Part(guardrail_result=GuardrailResult(**v))
        except Exception:
            pass
        try:
            part = Part(**v)
            if any(val is not None for val in part.model_dump().values()):
                return part
        except Exception:
            pass
        return Part(metadata=v)


class HookRestAPIData(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"]
    url: str
    headers: dict[str, str] | None = None
