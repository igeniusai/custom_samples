import logging
from typing import Any, Protocol, runtime_checkable

logging.getLogger("domyn_agents").addHandler(logging.NullHandler())


@runtime_checkable
class LoggerProtocol(Protocol):
    """Interfaccia minima compatibile con logging.Logger, loguru, structlog, ecc."""

    def info(self, message: Any, *args: Any, **kwargs: Any) -> None: ...
    def warning(self, message: Any, *args: Any, **kwargs: Any) -> None: ...
    def error(self, message: Any, *args: Any, **kwargs: Any) -> None: ...
    def debug(self, message: Any, *args: Any, **kwargs: Any) -> None: ...
    def critical(self, message: Any, *args: Any, **kwargs: Any) -> None: ...


def _safe_log(fn: Any, message: Any, *args: Any, **kwargs: Any) -> None:
    """Chiama il metodo di log, scartando progressivamente i kwargs se non supportati."""
    try:
        fn(message, *args, **kwargs)
    except TypeError:
        fn(message)


class SafeLoggerWrapper:
    """Wrappa qualsiasi logger iniettato via set_logger() gestendo kwargs non supportati."""

    def __init__(self, logger: LoggerProtocol) -> None:
        self._logger = logger

    def info(self, message: Any, *args: Any, **kwargs: Any) -> None:
        _safe_log(self._logger.info, message, *args, **kwargs)

    def warning(self, message: Any, *args: Any, **kwargs: Any) -> None:
        _safe_log(self._logger.warning, message, *args, **kwargs)

    def error(self, message: Any, *args: Any, **kwargs: Any) -> None:
        _safe_log(self._logger.error, message, *args, **kwargs)

    def debug(self, message: Any, *args: Any, **kwargs: Any) -> None:
        _safe_log(self._logger.debug, message, *args, **kwargs)

    def critical(self, message: Any, *args: Any, **kwargs: Any) -> None:
        _safe_log(self._logger.critical, message, *args, **kwargs)


# Logger di default della libreria
_library_logger: LoggerProtocol = SafeLoggerWrapper(logging.getLogger("domyn_agents"))


def set_logger(logger: LoggerProtocol) -> None:
    """Inject globally a logger instance to be used across the library. The logger should be compatible with LoggerProtocol."""
    global _library_logger
    _library_logger = SafeLoggerWrapper(logger)


def get_logger() -> LoggerProtocol:
    return _library_logger
