from __future__ import annotations

import asyncio
import importlib
import inspect
import re
from collections.abc import Callable
from copy import deepcopy

# from collections.abc import Callable
from functools import cached_property
from typing import Any, Literal

from pydantic import ConfigDict, Field, PrivateAttr

from domyn_agents.core import ApprovalType
from domyn_agents.core.utils import SerializedCallable, load_function_from_file, serialize_callable
from domyn_agents.hooks.base import Hook, HookPhase
from domyn_agents.tools.base import (
    BaseTool,
    ConfigParam,
    FunctionDeclaration,
    ToolResult,
)

# def python_type_to_json_schema(t_types: Dict[str, str]) -> Any:
#     # Creare dinamicamente il modello
#     from pydantic import create_model
#     model = create_model('DynamicModel', **{k: eval(v) for k, v in t_types.items()})

#     # Generare lo schema JSON
#     return model.model_json_schema()['properties']


def split_union_types(type_str: str) -> list[str]:
    """Split a union type string into its component types considering also nested cases like List[int|str] | None."""

    parts = []
    current_part = []
    bracket_level = 0

    for char in type_str:
        if char == "[":
            bracket_level += 1
            current_part.append(char)
        elif char == "]":
            bracket_level -= 1
            current_part.append(char)
        elif (
            char == "|" and bracket_level == 0
        ):  # If we are at top level all the character before is a part
            parts.append("".join(current_part).strip())
            current_part = []
        else:  # If not a top level just add the character to the current part
            current_part.append(char)
    if current_part:
        parts.append("".join(current_part).strip())

    return parts


def python_type_to_json_type(type_str: str) -> Any:
    type_str = type_str.strip()

    # Mappa tipi base Python -> JSON
    base_map = {
        "str": "string",
        "int": "integer",
        "float": "number",
        "bool": "boolean",
        "None": "null",
        "Any": None,
    }

    # --- Gestione Literal ---
    # TODO: support literal

    # Gestione List/list (semplice o parametrizzata)
    m = re.fullmatch(r"(?:List|list)(?:\[(.+)\])?", type_str)
    if m:
        inner = m.group(1)
        item_type = python_type_to_json_type(inner.strip()) if inner else {}
        return {"type": "array", "items": item_type}

    # Gestione Dict/dict (semplice o parametrizzata)
    m = re.fullmatch(r"(?:Dict|dict)(?:\[(?:([^,]+),(.+))\])?$", type_str)
    if m:
        key_type = m.group(1)
        if key_type is None:
            return {"type": "object", "additionalProperties": {}}
        value_type = m.group(2).strip()
        additional_properties = python_type_to_json_type(value_type)
        return {"type": "object", "additionalProperties": additional_properties}

    # Gestione Union con '|'
    if "|" in type_str:
        parts = split_union_types(type_str)
        types = []
        for p in parts:
            t = python_type_to_json_type(p)
            types.append(t)

        if len(types) > 1:
            return {"anyOf": types}
        return {"type": types}

    # Tipi base
    t = base_map.get(type_str)
    if t is None:
        return {}
    return {"type": t}


class FunctionTool(BaseTool):
    """Wrapper for Python functions as tools."""

    type: Literal["function"] = "function"  # type: ignore

    func: SerializedCallable | Callable[..., Any] = Field(
        ..., description="Callable function or serialized callable function metadata"
    )
    approval_type: ApprovalType | None = Field(
        default=None, description="Type of user approval required before executing the tool"
    )
    config_params: list[ConfigParam] = Field(
        default_factory=list,
        description="Configuration parameters for the tool. These parameters are not shown to models.",
    )
    reference: str | None = Field(
        default=None, description="Reference tool name on which this tool is based."
    )
    hooks: list[Hook] = Field(
        default_factory=list, description="List of hooks applied to the tool"
    )  # Union of pre and post hooks, the type will be determined by the 'type' field of each hook #TODO: Better to specify the hook version but it will give raise to circular import
    _actual_callable: Callable[..., Any] | None = PrivateAttr(default=None)
    _declaration: FunctionDeclaration | None = PrivateAttr(default=None)

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def __init__(self, func=None, *args, **kwargs):
        if func is not None:
            kwargs["func"] = func

        field_names = [
            name
            for name, field_info in self.__class__.model_fields.items()
            if field_info.init is not False
        ]
        kwargs.update(dict(zip(field_names, args, strict=False)))

        super().__init__(**kwargs)

    def __call__(self, *args, **kwargs):
        return self.callable_function(*args, **kwargs)

    def model_post_init(self, context: Any, /) -> None:
        if not self._declaration:
            if callable(self.func):
                actual_callable = self.func
                serialized = serialize_callable(actual_callable)
                object.__setattr__(self, "func", serialized)
                # Store the original callable for cached_property access
                self._actual_callable = actual_callable
            elif isinstance(self.func, dict):
                # Try to reconstruct the function from serialized data
                try:
                    self._actual_callable = self._load_function_from_serialized(self.func)
                except Exception:
                    # If we can't load the function, we'll have to work without it
                    self._actual_callable = None
            else:
                self._actual_callable = None

            if self.reference is None:
                object.__setattr__(self, "reference", self.name)

            if self.uid is None:
                object.__setattr__(self, "uid", self.name)

    @property
    def pre_hooks(self) -> list[Hook]:
        return [hook for hook in self.hooks if hook.trigger == HookPhase.PRE_TOOL_CALL]

    @property
    def post_hooks(self) -> list[Hook]:
        return [hook for hook in self.hooks if hook.trigger == HookPhase.POST_TOOL_CALL]

    def _load_function_from_serialized(self, serialized: dict) -> Callable[..., Any] | None:
        """Try to load a function from serialized data."""
        if serialized.get("type") == "function":
            module_name = serialized.get("module")
            func_name = serialized.get("name")

            if module_name and func_name:
                try:
                    module = importlib.import_module(module_name)
                    return getattr(module, func_name)
                except (ImportError, AttributeError):
                    return None
        return None

    @property
    def declaration(self) -> FunctionDeclaration | None:
        if getattr(self, "_declaration", None) is not None:
            return self._declaration

        if self._actual_callable is not None:
            self._declaration = FunctionDeclaration.from_callable(
                self._actual_callable, ignore_params=[conf.name for conf in self.config_params]
            )
        return self._declaration

    def set_declaration(self, value: FunctionDeclaration | None):
        object.__setattr__(self, "_declaration", value)

    @cached_property
    def _is_async(self) -> bool:
        if self._actual_callable is not None:
            return inspect.iscoroutinefunction(self._actual_callable)
        return False

    @cached_property
    def _is_async_generator(self) -> bool:
        if self._actual_callable is not None:
            return inspect.isasyncgenfunction(self._actual_callable)
        return False

    @property
    def callable_function(self):
        if self._actual_callable is not None:
            return self._actual_callable
        else:
            raise ValueError(
                "Cannot convert serialized function back to callable. Original callable was lost."
            )

    @property
    def name(self) -> str:
        return self.declaration.name

    @name.setter
    def name(self, value: str) -> None:
        self.declaration.name = value

    @property
    def description(self) -> str:
        return self.declaration.description

    @description.setter
    def description(self, value: str) -> None:
        self.declaration.description = value

    @property
    def invocation_json_schema(self) -> dict[str, Any]:
        """Generate a JSON schema for the function parameters."""
        parameters_schema = {
            "properties": {},
            "required": [],
        }

        # json_type_conversion_map = {
        #     "str": "string",
        #     "int": "integer",
        #     "float": "number",
        #     "bool": "boolean",
        #     "list": "array",
        #     "dict": "object",
        #     "none": "null",
        #     "any": ["number", "string", "boolean", "object", "array", "null"],
        # }

        for param in self.declaration.parameters:
            param_schema = {
                "description": param.description,
                **python_type_to_json_type(param.type),
            }
            # if "|" in param.type:
            #     param_schema['type'] = [json_type_conversion_map[p.lower().strip()] for p in param.type.split("|")]
            # else:
            #     param_schema["type"] = json_type_conversion_map.get(param.type.lower().strip(), "any")

            parameters_schema["properties"][param.name] = param_schema
            # TODO: gestire parametri opzionali
            parameters_schema["required"].append(param.name)
        schema = {
            "properties": {
                self.name_string: {"const": self.name, "type": "string"},
                self.parameters_string: parameters_schema,
            },
            "required": [self.parameters_string],
            "description": self.description,
        }
        return schema

    @property
    def tool_definition(self) -> dict[str, Any]:
        """Return OpenAI-compatible tool definition for native tool calling."""
        parameters_schema: dict[str, Any] = {
            "type": "object",
            "properties": {},
            "required": [],
        }

        for param in self.declaration.parameters:
            param_schema = {
                "description": param.description,
                **python_type_to_json_type(param.type),
            }
            parameters_schema["properties"][param.name] = param_schema
            parameters_schema["required"].append(param.name)

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": parameters_schema,
            },
        }

    @property
    def namespaced_invocation_json_schema(self) -> dict[str, Any]:
        """Generate a JSON schema for the function parameters with namespacing.
        Using '.' as namespace separator as per SEP-986 https://github.com/modelcontextprotocol/modelcontextprotocol/issues/986
        """
        schema = self.invocation_json_schema
        schema["properties"][self.name_string]["const"] = (
            f"{self.group or 'base-group'}.{self.name}"
        )
        return schema

    async def execute(self, **kwargs: Any) -> ToolResult:
        # to fix non mi piace che uso nest asyncio
        """Execute the function with given parameters."""
        try:
            kwargs = {
                k: deepcopy(
                    v
                )  # Ensure that a tool can not modify kwargs (e.g. state) in place without returning it
                for k, v in kwargs.items()
                if k in list(inspect.signature(self.callable_function).parameters.keys())
            }

            # if self.callable_function.__qualname__ != self.callable_function.__name__:
            # Handle instance methods
            config_params = {param.name: param.value for param in self.config_params}

            if self._is_async_generator:
                result = "".join(
                    map(
                        str,
                        filter(
                            None,
                            [
                                item
                                async for item in self.callable_function(
                                    **{**kwargs, **config_params}
                                )
                            ],
                        ),
                    )
                )
            else:
                if self._is_async:
                    result = await self.callable_function(**{**kwargs, **config_params})
                else:
                    result = await asyncio.to_thread(
                        self.callable_function, **{**kwargs, **config_params}
                    )
            # else:
            #     if self._is_async:
            #         # Handle async functions
            #         result = await self.func(**kwargs)
            #     else:
            #         result = await asyncio.to_thread(self.func, **kwargs)

            if not isinstance(result, ToolResult):
                if isinstance(result, dict) and ("result" in result):
                    result = ToolResult(
                        success=True,
                        data=result["result"],
                        metadata=result.get("metadata", {}),
                        state=result.get("state"),
                    )
                else:
                    result = ToolResult(success=True, data=result)

        except Exception as e:
            result = ToolResult(success=False, error=str(e), error_code=type(e).__name__)

        return result

    # ---------------------------------------------------------------------
    # Factory helpers
    # ---------------------------------------------------------------------
    @classmethod
    def from_config(cls, config: dict, save_in_registry: bool = False) -> FunctionTool:
        from domyn_agents.hooks import HookFactory
        from domyn_agents.hooks.base import HookPhase

        hooks = []
        for hook in config.get("hooks", []):
            if isinstance(hook, dict):
                if hook["trigger"] == HookPhase.PRE_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.PRE_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                elif hook["trigger"] == HookPhase.POST_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.POST_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                else:
                    raise ValueError(f"Unsupported hook trigger: {hook['trigger']}")
            else:
                hooks.append(hook)

        kwargs = {}
        if "path" in config:
            func = load_function_from_file(name=config["name"], path=config["path"])
        else:
            func = config.get("func")
            if func is None:
                raise ValueError("func or path must be provided")

            if isinstance(func, dict):
                # func = SerializedCallable(**func)
                func = load_function_from_file(
                    name=func["name"], path=func["path"] or func["module"]
                )

        # Costruiamo kwargs solo con i valori presenti per permettere a Pydantic di usare i default
        kwargs.update(
            {
                "func": func,
                "hooks": hooks,
                "uid": config.get("uid"),
            }
        )

        kwargs["config_params"] = [
            ConfigParam(**param) for param in config.get("config_params", [])
        ]

        # Aggiungi approval_type solo se presente nella config
        if "approval_type" in config:
            kwargs["approval_type"] = (
                ApprovalType(config["approval_type"]) if config["approval_type"] else None
            )

        tool = cls(**kwargs)
        if save_in_registry:
            from domyn_agents.registry import get_tool_registry

            get_tool_registry().register_tool(config.get("name", tool.name), tool)
        return tool

    @classmethod
    def read_from_registry_and_configure(cls, config: dict) -> FunctionTool:
        from domyn_agents.hooks import HookFactory
        from domyn_agents.hooks.base import HookPhase
        from domyn_agents.registry import get_tool_registry

        hooks = []
        for hook in config.get("hooks", []):
            if isinstance(hook, dict):
                if hook["trigger"] == HookPhase.PRE_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.PRE_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                elif hook["trigger"] == HookPhase.POST_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.POST_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                else:
                    raise ValueError(f"Unsupported hook trigger: {hook['trigger']}")
            else:
                hooks.append(hook)

        registered_tool = get_tool_registry().get_tool(config.get("reference") or config["name"])
        if registered_tool and isinstance(registered_tool, FunctionTool):
            cls.func = registered_tool.func

            _registered_callable = registered_tool._actual_callable
            registered_tool._actual_callable = (
                None  # Porkaround to avoid issues with deepcopy and pickle
            )
            tool_with_config_params = deepcopy(registered_tool)
            tool_with_config_params._actual_callable = _registered_callable
            registered_tool._actual_callable = _registered_callable
            if "config_params" in config:
                tool_with_config_params.config_params = [
                    ConfigParam(**param) for param in config.get("config_params", [])
                ]
            if "hooks" in config:
                tool_with_config_params.hooks = hooks
            if "approval_type" in config:
                tool_with_config_params.approval_type = config["approval_type"]

            if config.get("reference") and config["reference"] != config["name"]:
                tool_with_config_params.name = config["name"]

            if config.get("uid"):
                tool_with_config_params.uid = config["uid"]

            return tool_with_config_params
        else:
            raise ValueError(
                f"FunctionTool with name '{config['reference']}' not found in registry."
            )
