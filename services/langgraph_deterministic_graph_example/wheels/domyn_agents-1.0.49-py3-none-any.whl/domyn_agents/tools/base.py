"""Base classes for tools in the domyn agents framework."""

import inspect
import re
import types
from collections.abc import Callable
from dataclasses import dataclass, field, fields
from enum import Enum
from functools import reduce
from operator import or_
from typing import Annotated, Any, ClassVar, Literal, _AnnotatedAlias  # type: ignore[attr-defined]

from pydantic import BaseModel, Field, TypeAdapter, model_serializer
from pydantic.dataclasses import dataclass as pydantic_dataclass


class SchemaType(Enum):
    """Schema types specification."""

    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"
    NULL = "null"
    ANY = "any"


FUNCTION_RESERVED_PARAMS = {"self", "cls", "run_config", "state"}


class ToolVisibility(Enum):
    """Controls state scope and run_config access for MCP tools.

    Progressive trust levels:
    - ISOLATED: state per tool (tool_name key), no run_config.
    - SCOPED: state per group (e.g. MCP server URL), no run_config.
      Tools from the same server share state.
    - TRUSTED: state per group + run_config (PII) in _meta.
    - GLOBAL: full shared state + run_config (PII) in _meta.
    """

    ISOLATED = "isolated"
    SCOPED = "scoped"
    TRUSTED = "trusted"
    GLOBAL = "global"


# sentinel to express missing default in Param
class _Missing:
    _instance: "_Missing | None" = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<MISSING>"

    def __bool__(self) -> bool:
        return False


_MISSING = _Missing()


@pydantic_dataclass
class Param:
    """Parameter definition."""

    type: str
    name: str | None = None
    description: str | None = None
    is_required: bool = True
    default: Any = _MISSING

    @model_serializer(mode="plain")
    def _serialize(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for f in fields(self):
            value = getattr(self, f.name)
            if f.name == "default" and isinstance(value, _Missing):
                continue  # omit default if it's the sentinel _MISSING
            out[f.name] = value
        return out


@pydantic_dataclass
class ConfigParam(Param):
    """Configuration parameter definition."""

    type: str | None = None
    value: Any = None
    is_secret: bool = False


class BaseTool(BaseModel):
    """Base class for all tools in the domyn agents framework."""

    name_string: ClassVar[str] = "name"
    parameters_string: ClassVar[str] = "arguments"
    # register subclasses
    _registry: ClassVar[dict[str, type["BaseTool"]]] = {}
    type: Literal["BaseTool"] = "BaseTool"
    group: str | None = Field(
        default=None, description="Group name for the tool (used for categorization)"
    )  # TODO: remove and include in metadata
    metadata: dict[str, Any] | None = Field(
        default_factory=dict, description="Additional metadata for the tool"
    )
    uid: str | None = Field(default=None, description="Optional unique identifier for the tool")

    # auto-register sub types
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        tag = getattr(cls, "type", None)
        if tag is not None:
            BaseTool._registry[tag] = cls

    @classmethod
    def from_config(cls, config: dict[str, Any], save_in_registry: bool = False) -> "BaseTool":
        """
        Create a tool instance from configuration dictionary.

        This method should be overridden by subclasses to provide
        their specific configuration logic.
        """
        raise NotImplementedError(f"from_config not implemented for {cls.__name__}")

    @classmethod
    def read_from_registry_and_configure(cls, config: dict[str, Any]) -> "BaseTool":
        raise NotImplementedError(
            f"read_from_registry_and_configure not implemented for {cls.__name__}"
        )


class BaseToolAdapter:
    """Custom adapter for BaseTool that uses from_config for dictionary inputs."""

    def __init__(self) -> None:
        # Create a union type of all registered tool types
        tool_types = reduce(or_, (BaseTool, *BaseTool._registry.values()))
        self._adapter: TypeAdapter[Any] = TypeAdapter(
            Annotated[tool_types, Field(discriminator="type")]
        )

    def validate_python(
        self,
        obj: Any,
        *,
        strict: bool | None = None,
        from_attributes: bool | None = None,
        context: dict[str, Any] | None = None,
        save_in_registry: bool = False,
    ) -> "BaseTool":
        """Validate Python object, using from_config for dictionaries."""
        # Case 1: Already a BaseTool or subclass - return as-is
        if isinstance(obj, BaseTool):
            return obj

        # Case 2: Dictionary - determine tool type and use its from_config method
        if isinstance(obj, dict):
            tool_type = obj.get("type")
            tool_reference = obj.get("reference")

            # Handle reference logic
            if not tool_type and not tool_reference:
                raise ValueError("Tool type or reference must be specified in the config")

            if tool_reference:
                from domyn_agents.registry import get_tool_registry

                referenced_tool = get_tool_registry().get_tool(tool_reference)
                if referenced_tool is None:
                    raise ValueError(f"Referenced tool '{tool_reference}' not found in registry")
                else:
                    tool_type = referenced_tool.type

            if tool_type is None:
                raise ValueError("Tool type cannot be None")

            tool_class = BaseTool._registry.get(tool_type)
            if tool_class is None:
                raise ValueError(f"Unknown tool type: {tool_type}")

            if tool_reference:
                return tool_class.read_from_registry_and_configure(obj)
            # Do not register a tool reconfigured from registry

            # Use the specific tool's from_config method in case of custom logic
            tool = tool_class.from_config(obj, save_in_registry=False)

            if save_in_registry:
                from domyn_agents.registry import get_tool_registry

                get_tool_registry().register_tool(tool)

            return tool

        # Case 3: Other types - use standard TypeAdapter validation
        result = self._adapter.validate_python(
            obj, strict=strict, from_attributes=from_attributes, context=context
        )
        if not isinstance(result, BaseTool):
            raise ValueError(f"Expected BaseTool, got {type(result)}")
        return result

    def from_config(self, config: dict[str, Any], *, save_in_registry: bool = False) -> "BaseTool":
        """Create tool from config with optional registry saving."""
        return self.validate_python(config, save_in_registry=save_in_registry)

    def validate_json(
        self, json_str: str, *, strict: bool | None = None, context: dict[str, Any] | None = None
    ) -> "BaseTool":
        """Validate JSON string."""
        result = self._adapter.validate_json(json_str, strict=strict, context=context)
        if not isinstance(result, BaseTool):
            raise ValueError(f"Expected BaseTool, got {type(result)}")
        return result

    def model_json_schema(self, *, mode: str = "validation") -> dict[str, Any]:
        """Generate JSON schema."""
        schema = self._adapter.json_schema(mode=mode)
        if not isinstance(schema, dict):
            raise ValueError(f"Expected dict schema, got {type(schema)}")
        return schema


Tool = BaseToolAdapter()


@dataclass
class FunctionDeclaration:
    """Function declaration structure."""

    name: str
    description: str
    parameters: list[Param]
    returns: Param | None = None

    @classmethod
    def from_callable(
        cls, callable_func: Callable, ignore_params: list[str]
    ) -> "FunctionDeclaration":
        """Create a FunctionDeclaration from a Python callable."""
        name = callable_func.__name__

        # extract signature
        sig = inspect.signature(callable_func)

        # check napoleon docstring
        parse_napoleon = _parse_napoleon_docstring(callable_func.__doc__ or "")

        if parse_napoleon:
            # Defaults aren't expressible in Google-style docstrings — read them from
            # the signature and merge so napoleon-driven Params still carry is_required/default.
            signature_defaults = {
                p.name: p.default
                for p in sig.parameters.values()
                if p.default is not inspect.Parameter.empty
            }

            list_parameters = []
            for arg in parse_napoleon["args"]:
                param = Param(**arg)
                if param.name in signature_defaults:
                    param.is_required = False
                    param.default = signature_defaults[param.name]
                if param.name not in ignore_params:
                    list_parameters.append(param)

            # check if there is a mismatch
            joined_params = (
                {c.name for c in _create_params_from_signature(sig)} - set(ignore_params)
            ).difference({param.name for param in list_parameters})
            if joined_params:
                raise ValueError("There is mismatch between docstring and signature of function.")
            return cls(
                name=name,
                description=parse_napoleon["description"],
                parameters=list_parameters,
                returns=Param(**parse_napoleon["returns"]) if parse_napoleon["returns"] else None,
            )
        else:
            description = callable_func.__doc__ or f"Function {name}"

            # Parse function signature
            parameters = list(
                filter(lambda x: x.name not in ignore_params, _create_params_from_signature(sig))
            )

            return cls(name=name, description=description, parameters=parameters)


class ToolResult(BaseModel):
    """Result of a tool execution."""

    success: bool
    data: Any = None
    error: str | None = None
    error_code: str | None = None
    state: dict | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class UpdateToolResult(BaseModel):
    """Update of a tool execution."""

    data: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)


def __get_param_type(param_type):
    if isinstance(param_type, types.UnionType):
        return str(param_type)
    return param_type.__name__


def _create_params_from_signature(sig: inspect.Signature) -> list[Param]:
    """Create a list of Params from function signature."""
    params = []
    for param_name, param in sig.parameters.items():
        if param_name in FUNCTION_RESERVED_PARAMS:
            continue

        param_type = param.annotation if param.annotation != inspect.Parameter.empty else None
        if isinstance(param_type, _AnnotatedAlias):
            param_type = param_type.__origin__

        has_default = param.default is not inspect.Parameter.empty
        params.append(
            Param(
                type=__get_param_type(param_type) if param_type else "any",
                name=param_name,
                description=param.annotation.__metadata__[0]
                if isinstance(param.annotation, _AnnotatedAlias)
                else f"Parameter {param_name}",
                is_required=not has_default,
                default=param.default if has_default else _MISSING,
            )
        )
    return params


def _parse_napoleon_docstring(docstring: str) -> dict[str, Any] | None:
    """
    Parser migliorato per docstring in stile Napoleon (Google-style, con alcuni alias).
    Restituisce un dizionario con chiavi:
      - description: str
      - args: list[{"name","type","desc"}]
      - returns: {"type","desc"} o None
      - raises: list[{"type","desc"}]
    Restituisce None se non trova sezioni riconosciute (Args/Parameters/Returns/Raises).
    """
    if not docstring or not docstring.strip():
        return None

    # Rimuoviamo l'indentazione comune (es. docstring indentata dentro una funzione)
    text = "\n".join(
        [d.strip() for d in docstring.split("\n")]
    )  # textwrap.dedent(docstring).strip()
    lines = text.splitlines()

    # Riconosciamo header tipici (Args, Arguments, Parameters, Returns, Raises)
    header_re = re.compile(r"^(Args|Arguments|Parameters|Returns|Raises):\s*$", re.IGNORECASE)
    sections = {"description": []}
    current = "description"
    for line in lines:
        m = header_re.match(line)
        if m:
            key = m.group(1).lower()
            if key in ("arguments", "parameters"):
                key = "args"
            sections[key] = []
            current = key
        else:
            sections.setdefault(current, []).append(line)

    # Se non ci sono intestazioni riconosciute, non è Napoleon-style (per questo parser)
    recognized_headers = set(sections.keys()) - {"description"}
    if not recognized_headers:
        return None

    result: dict[str, Any] = {
        "description": "\n".join(
            [desc.rstrip() for desc in sections.get("description", [])]
        ).strip(),
        "args": [],
        "returns": None,
        "raises": [],
    }

    # --- parse Args (Google-style) ---

    def fix_args(typ: str) -> str:
        if not typ:
            return "any"
        typ = typ.strip()
        # Only replace commas that are not inside brackets (e.g. "str, optional"
        # but NOT "list[dict[str, str]]")
        result_chars = []
        depth = 0
        for ch in typ:
            if ch in "([":
                depth += 1
                result_chars.append(ch)
            elif ch in ")]":
                depth -= 1
                result_chars.append(ch)
            elif ch == "," and depth == 0:
                result_chars.append("|")
            else:
                result_chars.append(ch)
        typ = "".join(result_chars)
        typ = typ.replace("optional", "None")
        typ = re.sub(r"\s{2,}", " ", typ)  # normalize multiple whitespaces
        return " | ".join(map(str.strip, typ.split("|"))) if "|" in typ else typ

    if "args" in sections:
        body = "\n".join(sections["args"])
        param_pat = re.compile(
            r"^\s*(?P<name>[A-Za-z_]\w*)\s*(?:\((?P<type>[^)]+)\))?\s*:\s*(?P<desc>.*?)(?=(?:\n^\s*[A-Za-z_]\w*\s*(?:\([^)]+\))?\s*:)|\Z)",
            re.MULTILINE | re.DOTALL,
        )
        for m in param_pat.finditer(body):
            name = m.group("name")
            typ = fix_args((m.group("type") or "").strip())
            desc = m.group("desc").strip().replace("\n", " ").strip()
            result["args"].append({"name": name, "type": typ or "any", "description": desc})

    # --- parse Returns ---
    if "returns" in sections:
        body = "\n".join(sections["returns"]).strip()
        if body:
            m = re.match(r"^\s*([^\:]+?)\s*:\s*(.+)$", body, re.DOTALL)
            if m:
                typ = m.group(1).strip()
                desc = m.group(2).strip().replace("\n", " ").strip()
                result["returns"] = {"type": typ, "description": desc}
            else:
                result["returns"] = {"type": "", "description": body.replace("\n", " ").strip()}

    # --- parse Raises ---
    if "raises" in sections:
        body = "\n".join(sections["raises"])
        exc_pat = re.compile(
            r"^\s*(?P<type>[\w\.]+)\s*:\s*(?P<desc>.*?)(?=(?:\n^\s*[\w\.]+\s*:)|\Z)",
            re.MULTILINE | re.DOTALL,
        )
        for m in exc_pat.finditer(body):
            typ = m.group("type").strip()
            desc = m.group("desc").strip().replace("\n", " ").strip()
            result["raises"].append({"type": typ, "description": desc})

    return result


# TODO: da capire come integrarlo
# class HumanTool(BaseModel):
#     """Wrapper for human-in-the-loop tools."""

#     declaration: FunctionDeclaration = Field(
#         ..., description="Function declaration for the human tool"
#     )

#     def __init__(self, name: str, description: str, **data: Any) -> None:
#         declaration = FunctionDeclaration(name=name, description=description, parameters=[])
#         super().__init__(declaration=declaration, **data)

#     @property
#     def name(self) -> str:
#         return self.declaration.name

#     @property
#     def description(self) -> str:
#         return self.declaration.description
