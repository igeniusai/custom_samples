"""MCP server configuration for Domyn agents."""

from typing import Any

from fastmcp import Client
from fastmcp.client.auth import OAuth
from fastmcp.client.transports import StreamableHttpTransport
from mcp import Tool
from mcp.client.auth import OAuthClientProvider
from pydantic import BaseModel, ConfigDict, Field
from pydantic.json_schema import SkipJsonSchema

from domyn_agents.logger import get_logger


class MCPServerStreamableHTTPConfig(BaseModel):
    """Configuration for an MCP server connection. Only supports Streamable HTTP protocol for now.

    This class handles connection details and authentication for MCP servers.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str = Field(..., description="Unique name for this MCP server")
    url: str = Field(..., description="URL of the MCP server endpoint")
    tool_autodiscovery: bool = Field(
        default=True,
        description="Whether to enable tool autodiscovery for this MCP server",
    )

    # Authentication options
    use_oauth: bool = Field(
        default=False,
        description="Whether to use OAuth authentication",
    )
    oauth_provider: SkipJsonSchema[OAuthClientProvider] | None = Field(
        default=None,
        description="OAuth client provider for authentication",
    )
    oauth_scopes: list[str] | None = Field(
        default=None,
        description="OAuth scopes to request (e.g., ['read', 'write'])",
    )
    oauth_client_name: str | None = Field(
        default=None,
        description="Client name for OAuth registration",
    )
    headers: dict[str, str] | None = Field(
        default=None,
        description="HTTP headers for authentication (e.g., {'Authorization': 'Bearer token'})",
    )

    # Optional settings
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
    )

    def create_client(self) -> Client[StreamableHttpTransport]:
        """Create a fastmcp Client instance from this configuration.

        Returns:
            Configured Client instance
        """
        # Create OAuth config if needed
        auth = None
        if self.use_oauth:
            auth = self.oauth_provider or OAuth(
                mcp_url=self.url,
                scopes=self.oauth_scopes or ["read"],
                client_name=self.oauth_client_name or "Domyn Agent",
            )

        # Create client with appropriate config
        if self.headers and not self.use_oauth:
            # Use config format for headers
            config = {
                "mcpServers": {
                    self.name: {
                        "transport": "http",
                        "url": self.url,
                        "headers": self.headers,
                    }
                }
            }
            return Client(config, auth=auth, timeout=self.timeout)  # type: ignore
        else:
            # Simple URL-based connection (with optional OAuth)
            return Client(self.url, auth=auth, timeout=self.timeout)  # type: ignore

    async def discover_tools(self) -> list[Tool]:
        """Discover all available tools from this MCP server.

        Returns:
            List of tool schemas from the server

        Raises:
            RuntimeError: If connection or discovery fails
        """
        logger = get_logger()

        client = self.create_client()

        try:
            async with client:
                tools = await client.list_tools()
                logger.info(f"Discovered {len(tools)} tools from MCP server '{self.name}'")
                return tools
        except Exception as e:
            logger.error(f"Failed to discover tools from MCP server '{self.name}': {e}")
            raise RuntimeError(
                f"Failed to discover tools from MCP server '{self.name}': {e}"
            ) from e

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> "MCPServerStreamableHTTPConfig":
        """Create MCPServerConfig from a dictionary.

        Args:
            config: Configuration dictionary

        Returns:
            MCPServerConfig instance
        """
        return cls(**config)
