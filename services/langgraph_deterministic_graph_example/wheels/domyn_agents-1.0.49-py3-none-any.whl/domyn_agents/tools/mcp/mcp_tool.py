"""MCP tool wrapper that integrates remote MCP tools with Domyn agents.

This module provides MCPTool, which wraps MCP server tools using fastmcp.Client,
allowing them to be used seamlessly within Domyn agents with full hook support.
"""

import asyncio
import inspect
import uuid
from collections.abc import AsyncGenerator, Callable, Coroutine
from typing import Any, Literal, cast

from fastmcp import Client
from fastmcp.client import StreamableHttpTransport
from fastmcp.client.auth import OAuth
from fastmcp.exceptions import ClientError, ToolError, ValidationError
from mcp.client.auth import OAuthClientProvider
from mcp.types import TextContent
from pydantic import ConfigDict, Field, PrivateAttr
from pydantic.json_schema import SkipJsonSchema

from domyn_agents.core import ApprovalType
from domyn_agents.hooks.base import HookPhase
from domyn_agents.logger import get_logger
from domyn_agents.tools.base import (
    _MISSING,
    FunctionDeclaration,
    Param,
    ToolResult,
    ToolVisibility,
    UpdateToolResult,
    _parse_napoleon_docstring,
)
from domyn_agents.tools.function_tool import FunctionTool
from domyn_agents.tools.streamable_function_tool import StreamableToolResult
from domyn_agents.tracing import inject_trace_headers


class MCPTool(FunctionTool):
    """Wrapper for MCP (Model Context Protocol) remote tools.

    This class extends FunctionTool to provide integration with remote MCP servers
    using the fastmcp library. It handles tool discovery, schema conversion, and
    execution via the MCP protocol over HTTP/SSE transport.
    """

    type: Literal["mcp"] = "mcp"  # type: ignore
    model_config = ConfigDict(arbitrary_types_allowed=True)
    server_url: str = Field(..., description="URL of the MCP server endpoint")
    tool_name: str = Field(..., description="Name of the tool on the MCP server")
    visibility: ToolVisibility = ToolVisibility.ISOLATED
    timeout: float = Field(0, description="Maximum time in seconds to wait for tool execution")

    # OAuth configuration
    use_oauth: bool = Field(
        default=False,
        description="Whether to use OAuth authentication",
    )
    oauth_provider: SkipJsonSchema[OAuthClientProvider] | None = Field(
        default=None,
        description="OAuth client provider for authentication",
    )
    oauth_scopes: list[str] | None = Field(
        default=None,
        description="OAuth scopes to request (e.g., ['read', 'write'])",
    )
    oauth_client_name: str | None = Field(
        default=None,
        description="Client name for OAuth registration",
    )

    # Additional headers for non-OAuth authentication
    headers: dict[str, str | Callable[[], Coroutine[Any, Any, str]]] | None = Field(
        default=None,
        description="HTTP headers for authentication (e.g., {'Authorization': 'Bearer token'})",
    )

    # Override func to be optional for MCP tools
    func: Any = None

    # Private attributes
    _client: Client | None = PrivateAttr(default=None)  # type: ignore
    _tool_schema: dict[str, Any] | None = PrivateAttr(default=None)
    _timeout_ping: float = PrivateAttr(
        default=5.0
    )  # Interval for healthcheck pings during execution

    async def _build_client(self) -> Client:
        """Create an MCP client with the current authentication configuration."""
        # Create OAuth config if needed
        auth = None
        if self.use_oauth:
            auth = self.oauth_provider or OAuth(
                mcp_url=self.server_url,
                scopes=self.oauth_scopes or ["read"],
                client_name=self.oauth_client_name or "Domyn Agent",
            )

        if self.headers:
            self.headers = {
                k: str(await v()) if inspect.iscoroutinefunction(v) else v
                for k, v in self.headers.items()
            }

        transport = StreamableHttpTransport(
            url=self.server_url,
            headers=cast(dict[str, str], self.headers),
            auth=auth,
        )
        return Client(transport)

    def model_post_init(self, __context: Any) -> None:
        """Initialize after Pydantic validation.

        Skip FunctionTool's model_post_init since we don't have a callable function.
        """
        logger = get_logger()
        # Don't call super().model_post_init() - we manage our own callable
        self._actual_callable = None

        if self.uid is None:
            object.__setattr__(self, "uid", f"{self.server_url}.{self.tool_name}")

        if self.visibility in (ToolVisibility.SCOPED, ToolVisibility.TRUSTED) and not self.group:
            logger.warning(
                f"MCPTool '{self.tool_name}' has {self.visibility.value} visibility but no group set. "
                "State will be keyed by tool_name, equivalent to ISOLATED.",
            )

    async def initialize(self) -> Client:  # type: ignore
        """Ensure fastmcp client is created and connected.

        Returns:
            Client instance

        Raises:
            RuntimeError: If connection fails
        """
        if self._client is None:
            self._client = await self._build_client()

        await self.get_tool_schema()
        if self._tool_schema is None:
            raise RuntimeError(f"Tool '{self.tool_name}' not found on MCP server {self.server_url}")

        return self._client

    async def get_tool_schema(self) -> None:
        if self._tool_schema is None:
            async with self._client as client:
                tools = await client.list_tools()
            for tool in tools:
                if tool.name == self.tool_name:
                    napoleon = (
                        _parse_napoleon_docstring(tool.description)
                        if isinstance(tool.description, str)
                        else None
                    )
                    input_schema = tool.inputSchema or {}
                    napoleon_args_by_name = {}
                    if napoleon and napoleon.get("args"):
                        napoleon_args_by_name = {
                            arg["name"]: arg for arg in napoleon["args"] if "name" in arg
                        }
                    for param_name, param_schema in input_schema.get("properties", {}).items():
                        if (
                            "description" not in param_schema
                        ):  # If the schema doesn't already have a description, try to get it from the Napoleon docstring
                            napoleon_arg = napoleon_args_by_name.get(param_name)
                            if napoleon_arg and "description" in napoleon_arg:
                                param_schema["description"] = napoleon_arg["description"]
                            else:
                                param_schema["description"] = f"Parameter {param_name}"
                    self._tool_schema = input_schema
                    napoleon_desc = napoleon.get("description", None) if napoleon else None
                    self._tool_schema["description"] = napoleon_desc or tool.description
                    break

    @property
    def invocation_json_schema(self) -> dict[str, Any]:
        if self._tool_schema is None:
            return {
                "properties": {
                    self.name_string: {"const": self.tool_name, "type": "string"},
                    self.parameters_string: {},
                },
                "required": [self.parameters_string],
                "description": self.tool_name,
            }

        return {
            "properties": {
                self.name_string: {"const": self.name, "type": "string"},
                self.parameters_string: {
                    "properties": self._tool_schema.get("properties", {}),
                    "required": self._tool_schema.get("required", []),
                },
            },
            "required": [self.parameters_string],
            "description": self._tool_schema.get("description", ""),
        }

    @property
    def declaration(self) -> FunctionDeclaration:
        """Convert MCP tool schema to FunctionDeclaration.

        Returns:
            FunctionDeclaration compatible with Domyn's tool system
        """
        if self._tool_schema is None:
            # Return minimal declaration if schema not yet discovered
            return FunctionDeclaration(
                name=self.tool_name,
                description=self.tool_name,
                parameters=[],
            )

        # Extract input schema
        input_schema = self._tool_schema
        properties = input_schema.get("properties", {})
        required = set(input_schema.get("required", []))

        parameters = []
        for param_name, param_schema in properties.items():
            param_type = param_schema.get("type", "any")
            param_desc = param_schema.get("description", f"Parameter {param_name}")
            # Prendiamo desc dalla napoleon (se c'è)

            # Map JSON Schema types to Python types
            type_mapping = {
                "string": "str",
                "integer": "int",
                "number": "float",
                "boolean": "bool",
                "array": "list",
                "object": "dict",
            }
            py_type = type_mapping.get(param_type, "any")

            has_default = "default" in param_schema
            parameters.append(
                Param(
                    name=param_name,
                    type=py_type,
                    description=param_desc,
                    is_required=param_name in required,
                    default=param_schema["default"] if has_default else _MISSING,
                )
            )

        description = self._tool_schema.get("description", "")
        if not description:
            description = self._tool_schema.get("title", self.tool_name)

        return FunctionDeclaration(
            name=self.tool_name,
            description=description,
            parameters=parameters,
        )

    @property
    def name(self) -> str:
        """Get tool name."""
        return self.tool_name

    @name.setter
    def name(self, value: str) -> None:
        """Set tool name."""
        object.__setattr__(self, "tool_name", value)

    @staticmethod
    def convert_content_to_string(result_data: Any) -> str:
        result_text = "\n".join(result_data) if result_data else ""

        # TODO: handle better with summarization/rag etc
        max_length = 10000
        if len(result_text) > max_length:
            result_text = f"{result_text[:max_length]}... [truncated]"
        return result_text

    @staticmethod
    def _unwrap_fastmcp_result(data: Any, metadata: dict[str, Any]) -> Any:
        """Remove FastMCP's transport wrapper from wrapped tool results.

        FastMCP may expose a tool return value as structured content shaped
        like ``{"result": <actual payload>}`` and mark it with
        ``meta.fastmcp.wrap_result``.  Downstream agents should reason about
        the logical tool payload, not the transport envelope.
        """
        fastmcp_meta = metadata.get("fastmcp")
        wrap_result = isinstance(fastmcp_meta, dict) and fastmcp_meta.get("wrap_result") is True
        if wrap_result and isinstance(data, dict) and set(data) == {"result"}:
            return data["result"]
        return data

    async def execute(  # type: ignore[override]
        self, **kwargs: Any
    ) -> AsyncGenerator[StreamableToolResult | UpdateToolResult | ToolResult, None]:
        """Execute the MCP tool remotely.

        Yields intermediate objects for each MCP progress notification received during the call,
        then yields the final result once the remote tool completes.

        Args:
            **kwargs: Tool arguments matching the tool's input schema

        Yields:
            StreamableToolResult: zero or more progress notifications
            UpdateToolResult: zero or more update notifications
            ToolResult: the final result of the tool call

        Raises:
            RuntimeError: If connection or execution fails

        """
        # retrieve logger
        logger = get_logger()
        result: ToolResult

        try:
            # Ensure client is ready, better to do this at the beginning to make sure the schema is populated
            client = await self.initialize()

            # Filter kwargs to only include expected parameters
            _state = kwargs.get("state", {})
            _run_config = kwargs.get("run_config", {})

            # State scope:
            #   ISOLATED → per tool (tool_name key), strictest sandbox.
            #   SCOPED   → per group (MCP server URL key), sibling tools share state.
            #   TRUSTED  → per group (like SCOPED) + run_config.
            #   GLOBAL   → full state dict + run_config.
            if self.visibility == ToolVisibility.ISOLATED:
                filtered_state = _state.get(self.tool_name, {})
            elif self.visibility in (ToolVisibility.SCOPED, ToolVisibility.TRUSTED):
                state_key = self.group or self.tool_name
                filtered_state = _state.get(state_key, {})
            else:
                filtered_state = _state

            # run_config: TRUSTED and GLOBAL receive it (contains PII: user_id, space_id, etc.).
            # TODO: support an optional meta_fields: list[str] allowlist for granular control.
            if self.visibility in (ToolVisibility.TRUSTED, ToolVisibility.GLOBAL):
                meta = _run_config | {"state": filtered_state}
            else:
                meta = {"state": filtered_state}

            meta = inject_trace_headers(meta)  # Add tracing headers if enabled

            if self._tool_schema:
                expected_params = set(self._tool_schema.get("properties", {}).keys())
                kwargs = {k: v for k, v in kwargs.items() if k in expected_params}

            logger.debug(f"Executing MCP tool {self.tool_name} with args: {kwargs}")

            # Unique ID shared by all progress notifications for this call.
            call_id = str(uuid.uuid4())

            # Queue used to put progress responses into the async generator.
            progress_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

            async def _progress_handler(
                progress: float, total: float | None, message: str | None
            ) -> None:
                """Handle progress updates from the MCP tool call."""
                await progress_queue.put(
                    {"call_id": call_id, "progress": progress, "total": total, "message": message}
                )

            # Shared result container — TaskGroup doesn't return values directly.
            call_result: list[Any] = []
            # Event to signal that call_task is done (either success or failure) so that other tasks can clean up.
            # it's used also in healtcheck_loop
            call_done = asyncio.Event()

            async def _call_tool() -> None:
                """Run the remote tool call and store the result."""
                response = await client.call_tool(
                    name=self.tool_name,
                    arguments=kwargs,
                    meta=meta,
                    progress_handler=_progress_handler,
                )
                call_result.append(response)
                call_done.set()

            async def _healthcheck_loop() -> None:
                """Ping the MCP server every 5 s while the remote call is in-flight.

                Uses a single dedicated client connection (not shared with call_task)
                and stops cleanly as soon as the call finishes.
                """
                # One dedicated connection for probing — avoids sharing state with call_task.
                # TODO: Are we sure tha we need another client connection? Maybe we can share the same client
                try:
                    async with await self._build_client() as probe_client:
                        # async with client as probe_client:
                        while not call_done.is_set():
                            await asyncio.sleep(self._timeout_ping)

                            if call_done.is_set():
                                return

                            await asyncio.wait_for(probe_client.ping(), timeout=3.0)
                except Exception as exc:
                    raise RuntimeError(
                        f"MCP server at {self.server_url} stopped responding during tool execution"
                    ) from exc

            async with client:
                try:
                    async with asyncio.TaskGroup() as tg:
                        tg.create_task(_call_tool())
                        tg.create_task(_healthcheck_loop())

                        # Yield progress items while the TaskGroup is running.
                        # TaskGroup.__aexit__ won't be reached until all tasks complete,
                        # so we drain output_queue here concurrently.
                        while not call_done.is_set():
                            try:
                                item = await asyncio.wait_for(progress_queue.get(), timeout=0.1)
                                yield UpdateToolResult(
                                    data={
                                        "call_id": item.get("call_id"),
                                        "progress": item.get("progress"),
                                        "total": item.get("total", None),
                                        "message": item.get("message", None),
                                    }
                                )
                            except TimeoutError:
                                continue

                except* RuntimeError as eg:
                    # Unwrap the first RuntimeError from the ExceptionGroup.
                    raise eg.exceptions[0] from eg.exceptions[0].__cause__
                except* ToolError as eg:
                    # Unwrap ToolError so the outer except handler catches it correctly.
                    raise eg.exceptions[0] from eg.exceptions[0].__cause__
                except* ClientError as eg:
                    # Unwrap ClientError so the outer except handler catches it correctly.
                    raise eg.exceptions[0] from eg.exceptions[0].__cause__
                except* ValidationError as eg:
                    # Unwrap ValidationError so the outer except handler catches it correctly.
                    raise eg.exceptions[0] from eg.exceptions[0].__cause__

            # Flush any notifications that arrived just before the tasks finished.
            while not progress_queue.empty():
                item = progress_queue.get_nowait()
                yield UpdateToolResult(
                    data={
                        "call_id": item.get("call_id"),
                        "progress": item.get("progress"),
                        "total": item.get("total", None),
                        "message": item.get("message", None),
                    }
                )

            # Retrieve the result stored by _call_tool.
            response = call_result[0]

        except ToolError as e:
            logger.error(f"Error executing MCP tool {self.tool_name}: {e}")
            result = ToolResult(success=False, error=str(e) + " - Is the MCP server running?")
        except ValidationError as e:
            logger.error(f"Validation error for MCP tool {self.tool_name}: {e}")
            result = ToolResult(success=False, error=str(e))
        except ClientError as e:
            logger.error(f"Error with the Client during MCP tool execution {self.tool_name}: {e}")
            result = ToolResult(success=False, error=str(e) + " - Is the MCP server running?")
        except Exception as e:
            if isinstance(e, ExceptionGroup):
                # Unwrap the first exception from the group for logging.
                e = e.exceptions[0]
            err_msg = str(e).strip() or type(e).__name__
            logger.error(f"Error executing MCP tool {self.tool_name}: {err_msg}")
            result = ToolResult(success=False, error=err_msg + " - Is the MCP server running?")
        else:
            # If no errors
            result_data: Any = []
            response_meta = dict(getattr(response, "meta", None) or {})

            if hasattr(response, "structured_content") and response.structured_content is not None:
                result_data = response.structured_content
            elif hasattr(response, "content"):
                for content in response.content:
                    # Extract text from TextContent objects
                    if isinstance(content, TextContent):
                        result_data.append(content.text)
                    else:
                        result_data.append(str(content))
                result_data = self.convert_content_to_string(result_data)
            elif isinstance(response, list):
                for content in response:
                    if isinstance(content, TextContent):
                        result_data.append(content.text)
                    else:
                        result_data.append(str(content))
                result_data = self.convert_content_to_string(result_data)
            else:
                # Fallback to string representation
                result_data.append(str(response))

            result_data = self._unwrap_fastmcp_result(result_data, response_meta)
            meta_state = response_meta.pop("state", {})

            # Write-back mirrors read scope:
            #   ISOLATED → nested under tool_name key
            #   SCOPED/TRUSTED → nested under group key
            #   GLOBAL   → merged at top level
            if not meta_state:
                state_addition = {}
            elif self.visibility == ToolVisibility.ISOLATED:
                state_addition = {self.tool_name: meta_state}
            elif self.visibility in (ToolVisibility.SCOPED, ToolVisibility.TRUSTED):
                state_addition = {(self.group or self.tool_name): meta_state}
            else:
                state_addition = meta_state

            result = ToolResult(
                success=True,  # TODO: HANDLE SUCCESS/IS_ERROR WHEN FASTMCP WILL SUPPORT IT
                data=result_data,
                state=_state | state_addition,
                metadata={"mcp_server": self.server_url, "tool_name": self.tool_name}
                | response_meta,
            )

        yield result

    @classmethod
    def from_config(cls, config: dict[str, Any], save_in_registry: bool = False) -> "MCPTool":
        """Create MCPTool from configuration dict.

        Args:
            config: Configuration dictionary with keys:
                - server_url: URL of MCP server
                - tool_name: Name of tool on server
                - name: Optional override for tool name (defaults to tool_name)
                - use_oauth: Optional OAuth authentication flag
                - oauth_scopes: Optional OAuth scopes list
                - oauth_client_name: Optional OAuth client name
                - headers: Optional HTTP headers dict
                - pre_hooks: Optional list of pre-hooks
                - post_hooks: Optional list of post-hooks
                - approval_type: Optional approval type
            save_in_registry: Whether to save tool in registry

        Returns:
            MCPTool instance
        """
        from domyn_agents.hooks import HookFactory

        hooks = []
        for hook in config.get("hooks", []):
            if isinstance(hook, dict):
                if hook["trigger"] == HookPhase.PRE_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.PRE_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                elif hook["trigger"] == HookPhase.POST_TOOL_CALL:
                    hooks.append(
                        HookFactory.from_config(hook, trigger=HookPhase.POST_TOOL_CALL)
                        if isinstance(hook, dict)
                        else hook
                    )
                else:
                    raise ValueError(f"Unsupported hook trigger: {hook['trigger']}")
            else:
                hooks.append(hook)

        # GLOBAL controls run_config (PII) access — set programmatically by the
        # host application (e.g. URL allowlist), not expected from user config.
        visibility = ToolVisibility(config.get("visibility", ToolVisibility.ISOLATED))

        kwargs = {
            "server_url": config["server_url"],
            "tool_name": config.get("name") or config["tool_name"],
            "use_oauth": config.get("use_oauth", False),
            "oauth_provider": config.get("oauth_provider"),
            "oauth_scopes": config.get("oauth_scopes"),
            "oauth_client_name": config.get("oauth_client_name"),
            "headers": config.get("headers"),
            "hooks": hooks,
            "visibility": visibility,
            "uid": config.get("uid"),
            "metadata": config.get("metadata", {}),
        }

        if "approval_type" in config:
            kwargs["approval_type"] = ApprovalType(config["approval_type"])

        tool = cls(**kwargs)

        if save_in_registry:
            from domyn_agents.registry import get_tool_registry

            get_tool_registry().register_tool(tool)

        return tool

    async def disconnect(self) -> None:
        """Disconnect from the MCP server.

        This should be called when the tool is no longer needed to clean up resources.
        """
        if self._client:
            # FastMCP Client handles cleanup in async context manager
            # No explicit disconnect needed
            self._client = None
