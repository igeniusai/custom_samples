"""Delegate tool — schema only, execution forwarded to the parent runner."""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import Callable
from typing import Any, Literal

from pydantic import ConfigDict, Field

from domyn_agents.core import ApprovalType
from domyn_agents.tools.base import BaseTool, ToolResult


class DelegateTool(BaseTool):
    """A tool that is visible to the planner but has no local implementation.

    The tool's ``name``, ``description``, and ``parameters`` schema are
    provided explicitly so the planner can include the tool in LLM tool
    definitions.  At execution time the runner detects ``DelegateTool``
    with no ``wrapped`` callable and forwards the ``TOOL_START`` event to
    the orchestrating runner via transport (Step 5).

    When ``wrapped`` is set the tool behaves like a normal local tool —
    the wrapped callable is invoked directly by the runner.  This mirrors
    the ``DelegateLLMProvider(wrapped=real_provider)`` pattern used for
    LLM delegation.
    """

    type: Literal["delegate"] = "delegate"  # type: ignore[assignment]

    # Required fields — the planner needs these to build tool definitions
    tool_name: str = Field(..., description="Tool name exposed to the LLM")
    tool_description: str = Field(default="", description="Tool description exposed to the LLM")

    # OpenAI-style properties schema: {"param": {"type": "string", "description": "..."}}
    tool_parameters: dict[str, Any] = Field(default_factory=dict)
    required_params: list[str] = Field(default_factory=list)

    approval_type: ApprovalType | None = Field(default=None)

    # Optional local callable; when set the runner executes it normally
    wrapped: Callable[..., Any] | None = Field(default=None, exclude=True)

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # ── Interface expected by Agent and Runner ───────────────────────────────

    @property
    def name(self) -> str:
        return self.tool_name

    @property
    def description(self) -> str:
        return self.tool_description

    @property
    def pre_hooks(self) -> list:
        return []

    @property
    def post_hooks(self) -> list:
        return []

    @property
    def tool_definition(self) -> dict[str, Any]:
        """OpenAI-compatible tool definition used by the planner context manager."""
        required = self.required_params or list(self.tool_parameters.keys())
        return {
            "type": "function",
            "function": {
                "name": self.tool_name,
                "description": self.tool_description,
                "parameters": {
                    "type": "object",
                    "properties": self.tool_parameters,
                    "required": required,
                },
            },
        }

    async def execute(self, **kwargs: Any) -> ToolResult:
        """Execute the tool locally via ``wrapped``, or raise if pure delegate."""
        if self.wrapped is None:
            raise RuntimeError(
                f"DelegateTool '{self.tool_name}' has no local implementation. "
                "Execution must be forwarded to the parent runner via transport."
            )
        try:
            # filter kwargs to only those accepted by the wrapped callable
            sig = inspect.signature(self.wrapped)
            accepted = set(sig.parameters.keys())
            filtered = {k: v for k, v in kwargs.items() if k in accepted}

            if inspect.iscoroutinefunction(self.wrapped):
                result = await self.wrapped(**filtered)
            else:
                result = await asyncio.to_thread(self.wrapped, **filtered)

            if not isinstance(result, ToolResult):
                result = ToolResult(success=True, data=result)
        except Exception as e:
            result = ToolResult(success=False, error=str(e), error_code=type(e).__name__)
        return result

    # ── Factory ─────────────────────────────────────────────────────────────

    @classmethod
    def from_config(cls, config: dict[str, Any], save_in_registry: bool = False) -> DelegateTool:
        tool = cls(
            tool_name=config["name"],
            tool_description=config.get("description", ""),
            tool_parameters=config.get("parameters", {}),
            required_params=config.get("required_params", []),
            uid=config.get("uid"),
        )
        if save_in_registry:
            from domyn_agents.registry import get_tool_registry

            get_tool_registry().register_tool(tool.tool_name, tool)
        return tool
