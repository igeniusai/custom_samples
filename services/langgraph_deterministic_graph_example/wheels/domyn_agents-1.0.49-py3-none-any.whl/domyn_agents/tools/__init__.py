"""Tools package for domyn agents framework."""

from enum import Enum
from functools import reduce
from operator import or_

from domyn_agents.tools.base import BaseTool, ConfigParam, Param, Tool
from domyn_agents.tools.delegate_tool import DelegateTool
from domyn_agents.tools.function_tool import FunctionTool
from domyn_agents.tools.mcp.mcp_tool import MCPTool
from domyn_agents.tools.rest_function_tool import RestFunctionTool
from domyn_agents.tools.streamable_function_tool import StreamableFunctionTool


class ToolType(Enum):
    FUNCTION = "function"
    STREAMABLE_FUNCTION = "streamable_function"
    REST = "rest"
    MCP = "mcp"
    DELEGATE = "delegate"


ToolTypes = reduce(or_, (BaseTool, *BaseTool._registry.values()))


__all__ = [
    "ConfigParam",
    "DelegateTool",
    "FunctionTool",
    "FunctionToolPreHook",
    "MCPTool",
    "Param",
    "RestFunctionTool",
    "StreamableFunctionTool",
    "Tool",
    "ToolType",
]
