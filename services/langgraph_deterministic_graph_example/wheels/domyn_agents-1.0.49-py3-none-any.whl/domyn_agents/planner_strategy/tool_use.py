"""Tool-use planner strategy for native tool-calling agentic loops.

Uses the LLM's native tool-calling API instead of prompt-engineered ReAct.
The LLM receives tool definitions as structured parameters and returns
tool_calls objects, eliminating the need for text parsing.

Response contract
-----------------
* ``use_stop=False`` (main / user-facing agent):
  - Content only (no tool calls) → final ``RESPONSE``, loop ends.
  - Content + tool calls in the same turn → content is treated as a
    user-visible preamble. In streaming mode it is emitted as
    ``RESPONSE_TOKEN`` events, but it is not copied into
    ``action.thought`` / ``action.message`` on the tool-call event.

* ``use_stop=True`` (sub-agent):
  - ``STOP(info)`` returns data to the parent agent (``AGENT_END``).
  - ``ASK_USER(text)`` asks the end-user for clarification (``RESPONSE`` with
    ``need_feedback=True``).
  - Content only (no tool calls) → implicit ``AGENT_END``.
"""

from __future__ import annotations

import json
import traceback
import uuid
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from pydantic import field_validator

from domyn_agents.core import (
    AGENT_ERROR_CODE,
    AGENT_ERROR_MESSAGE,
    METADATA_FORWARD_VERBATIM,
    METADATA_FORWARD_VERBATIM_SOURCE_ID,
    METADATA_FORWARD_VERBATIM_SOURCE_KEY,
    AgentAction,
    BaseEvent,
    ExecutionEventType,
    LLMCallAction,
    Part,
    ToolAction,
)
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import LLMMessage, LLMResponse, LLMToolCall
from domyn_agents.llm.delegate import DelegateLLMProvider
from domyn_agents.logger import get_logger
from domyn_agents.planner_strategy.base import BasePlannerStrategy
from domyn_agents.planner_strategy.context_management.tool_use import ToolUseContextManager
from domyn_agents.planner_strategy.utils import (
    FORWARD_VERBATIM_FEEDBACK_AGENT_END_SOURCE_KEY,
    FORWARD_VERBATIM_FEEDBACK_EMPTY_SOURCE_ID,
    FORWARD_VERBATIM_FEEDBACK_HARD_FALLBACK,
    FORWARD_VERBATIM_FEEDBACK_INVALID_FORMAT,
    FORWARD_VERBATIM_FEEDBACK_NOT_FOUND,
    FORWARD_VERBATIM_FEEDBACK_PATH_NOT_RESOLVED,
    FORWARD_VERBATIM_MISS_UNRESOLVED,
    is_valid_source_id_format,
    resolve_verbatim_detailed,
)

# Number of soft-miss retries before falling back to the hard-miss terminal.
# Each retry injects a tool-role feedback message and re-iterates the planner
# so the LLM can recover by responding in its own words. The cap prevents
# pathological loops where the LLM keeps hallucinating the same garbage source_id.
MAX_FV_SOFT_MISS_RETRIES = 2


@dataclass(frozen=True)
class ForwardVerbatimMiss:
    """Recoverable ``FORWARD_VERBATIM`` miss.

    A successful ``FORWARD_VERBATIM`` dispatch returns a real ``BaseEvent``.
    Misses are not events yet: top-level planners may turn ``feedback`` into a
    tool-role diagnostic and retry, while sub-agents or exhausted retries later
    become a terminal hard-miss event.
    """

    feedback: str


def _handle_forward_verbatim(
    agent: BaseAgent,
    interaction_context: InteractionContext,
    tool_call: LLMToolCall,
    args: dict[str, Any],
    use_stop: bool,
    stop_tool_name: str,
) -> BaseEvent | ForwardVerbatimMiss:
    """Resolve a ``FORWARD_VERBATIM`` tool call.

    Diagnoses the call without making retry decisions — the planner owns
    retry policy and decides whether to yield the returned event, surface
    miss feedback as a soft retry, or build a terminal hard-miss event.

    Miss reasons surfaced via ``feedback``:
    - empty ``source_id``
    - phrase-shaped ``source_id`` (failed format check, likely hallucinated)
    - ``source_key`` set on an ``AGENT_END`` source (post-extraction prose
      cannot be navigated by dot-path)
    - ``source_key`` missing on an existing ``TOOL_END`` observation
    - valid format but no matching event in visible history
    """
    logger = get_logger()

    source_id = (args.get("source_id") or "").strip()
    source_key = args.get("source_key")

    if not source_id:
        logger.warning("FORWARD_VERBATIM called without source_id")
        return ForwardVerbatimMiss(feedback=FORWARD_VERBATIM_FEEDBACK_EMPTY_SOURCE_ID)

    if not is_valid_source_id_format(source_id):
        logger.warning(
            f"FORWARD_VERBATIM source_id={source_id!r} failed format check (likely hallucinated)"
        )
        return ForwardVerbatimMiss(
            feedback=FORWARD_VERBATIM_FEEDBACK_INVALID_FORMAT.format(source_id=source_id),
        )

    resolution = resolve_verbatim_detailed(interaction_context, source_id, source_key)
    text, found = resolution.text, resolution.found

    if not found:
        logger.warning(
            FORWARD_VERBATIM_MISS_UNRESOLVED.format(source_id=source_id, source_key=source_key)
        )
        # Distinguish the AGENT_END + source_key reject from a generic miss so
        # the LLM gets actionable feedback. ``resolve_verbatim`` returns the
        # same ``(text="", found=False)`` for both cases; reproduce the check
        # here only when the source actually exists with that ``event_id``.
        if source_key and _source_event_is_agent_end(interaction_context, source_id):
            return ForwardVerbatimMiss(
                feedback=FORWARD_VERBATIM_FEEDBACK_AGENT_END_SOURCE_KEY.format(
                    source_key=source_key
                ),
            )
        if source_key and resolution.source_key_miss:
            return ForwardVerbatimMiss(
                feedback=FORWARD_VERBATIM_FEEDBACK_PATH_NOT_RESOLVED.format(
                    source_id=source_id,
                    source_key=source_key,
                ),
            )
        return ForwardVerbatimMiss(
            feedback=FORWARD_VERBATIM_FEEDBACK_NOT_FOUND.format(source_id=source_id),
        )

    # Audit trail lives in metadata (not action.parameters) so it never
    # leaks into the next-turn LLM prompt via the context manager's
    # AGENT_END rendering which dumps parameters verbatim.
    terminal_metadata: dict[str, Any] = {
        METADATA_FORWARD_VERBATIM: True,
        METADATA_FORWARD_VERBATIM_SOURCE_ID: source_id,
        METADATA_FORWARD_VERBATIM_SOURCE_KEY: source_key,
    }
    if use_stop:
        return BaseEvent(
            event_type=ExecutionEventType.AGENT_END,
            author=agent.name,
            action=ToolAction(
                name=stop_tool_name,
                parameters={"info": text},
            ),
            content=[Part(text=text)],
            is_partial=False,
            metadata=terminal_metadata,
        )
    return BaseEvent(
        event_type=ExecutionEventType.RESPONSE,
        content=[Part(text=text)],
        author=agent.name,
        is_partial=False,
        action=ToolAction(
            name=tool_call.function.name,
            parameters={},
        ),
        metadata=terminal_metadata,
    )


def _source_event_is_agent_end(context: InteractionContext, source_id: str) -> bool:
    """Look up a source event_id and report whether it is an ``AGENT_END``.

    Mirrors the lookup in :func:`resolve_verbatim` but answers a different
    question: did we miss because of an ``AGENT_END`` + ``source_key`` reject,
    or because the event_id genuinely did not match? Used only to choose the
    right LLM-facing feedback string on a miss.
    """
    visible = [*context.interaction_history, *context.conversation_history]
    for event in visible:
        if event.event_id == source_id:
            return event.event_type == ExecutionEventType.AGENT_END
    return False


def _hard_miss_event(agent: BaseAgent, use_stop: bool, stop_tool_name: str) -> BaseEvent:
    """Build the terminal event for an unrecoverable ``FORWARD_VERBATIM`` miss.

    Emits ``AGENT_END`` in both modes with ``error_code`` / ``error_message``
    populated so SDK consumers (e.g. agents-service runner) can decide how to
    surface the failure — graceful response, retry from a higher layer, or
    propagate as error — instead of a hard ``ERROR_OCCURRED`` that closes the
    turn unconditionally.

    ``use_stop=True`` (sub-agent): action carries ``STOP(info=AGENT_ERROR_MESSAGE)``
    so the parent sees a normal sub-end and can decide recovery.

    ``use_stop=False`` (top-level): action left unset — top-level has no STOP
    wrapping. The error fields signal degraded termination.

    Reached only after both the soft-miss retry budget and the hard-fallback
    nudge have been exhausted.
    """
    action: ToolAction | None = None
    if use_stop:
        action = ToolAction(
            name=stop_tool_name,
            parameters={"info": AGENT_ERROR_MESSAGE},
        )
    return BaseEvent(
        event_type=ExecutionEventType.AGENT_END,
        event_id=str(uuid.uuid4()),
        timestamp=datetime.now(),
        author=agent.name,
        content=[Part(text=AGENT_ERROR_MESSAGE)],
        action=action,
        error_code=AGENT_ERROR_CODE,
        error_message=AGENT_ERROR_MESSAGE,
        is_partial=False,
    )


def _create_event(event_type: ExecutionEventType, content: list[Part], author: str) -> BaseEvent:
    return BaseEvent(
        event_type=event_type,
        event_id=str(uuid.uuid4()),
        timestamp=datetime.now(),
        author=author,
        content=content,
        is_partial=False,
    )


class ToolUsePlannerStrategy(BasePlannerStrategy):
    """Native tool-calling planner strategy.

    Calls the LLM with tool definitions via the provider's ``tools`` parameter.
    Loops until the LLM returns a response with no tool calls.
    """

    type: str = "tool_use"
    name: str = "tool_use"
    context_manager: ToolUseContextManager = ToolUseContextManager()
    max_iterations: int = 25
    use_stop: bool = False

    # verbose: bool = False

    @field_validator("context_manager", mode="wrap")
    @classmethod
    def validate_context_manager(cls, v: Any, handler: Any, info: Any) -> ToolUseContextManager:
        if isinstance(v, ToolUseContextManager):
            return v
        if isinstance(v, dict):
            return ToolUseContextManager(**v)
        if v is None:
            return ToolUseContextManager()
        try:
            return handler(v)
        except Exception:
            return ToolUseContextManager()

    async def execute(
        self, agent: BaseAgent, interaction_context: InteractionContext
    ) -> AsyncGenerator[BaseEvent, None]:
        """Execute the native tool-use loop.

        1. Build messages from conversation history
        2. Call LLM with tool definitions
        3. If LLM returns tool calls, yield TOOL_START events
        4. If LLM returns no tool calls, yield final RESPONSE and stop
        5. Repeat until max_iterations
        """
        logger = get_logger()
        iteration = 0
        # Soft-miss budget for FORWARD_VERBATIM. Each retry injects a tool-role
        # feedback message so the LLM sees the diagnostic and can recover. Cap
        # prevents loops where the LLM keeps hallucinating the same garbage.
        # Only used when ``use_stop=False`` (top-level); sub-agents always emit
        # the hard miss so their parent decides recovery.
        fv_soft_miss_remaining = MAX_FV_SOFT_MISS_RETRIES
        # One last-ditch fallback after the soft-miss budget is spent: tell
        # the LLM to abandon FORWARD_VERBATIM and RESPOND directly. Avoids
        # ending the turn on AGENT_ERROR when the model just keeps hammering
        # FV with paths/event_ids the framework can't resolve.
        fv_hard_fallback_used = False
        # Carry-over messages from the previous iteration's soft-miss, prepended
        # to the next iteration's freshly-built context. We can't append these
        # to ``messages`` directly because ``messages`` is rebuilt each loop
        # from history; the FV miss feedback isn't in history (no ERROR_OCCURRED
        # was emitted), so it would otherwise be lost.
        fv_soft_miss_carry: list[LLMMessage] = []

        while iteration < self.max_iterations:
            iteration += 1

            # Build messages from history
            messages = await self.context_manager.get_context(
                context=interaction_context, agent=agent
            )
            if fv_soft_miss_carry:
                messages.extend(fv_soft_miss_carry)

            # Get tool definitions
            tool_defs = self.context_manager.get_tool_definitions(agent, interaction_context)

            # Handle memory recall
            if agent.memory_manager:
                recalled_memories = await agent.memory_manager.recall_memories(
                    user_id=interaction_context.user_id,
                    agent=agent,
                    recency_limit=agent.memory_manager.recency_limit,
                    question=interaction_context.agent_input.content[0].text
                    if interaction_context.agent_input and interaction_context.agent_input.content
                    else "",
                    run_config=interaction_context.run_config,
                )
                if recalled_memories:
                    messages.insert(
                        1,
                        LLMMessage(
                            role="assistant",
                            content="\n".join([mem.memory for mem in recalled_memories]),
                        ),
                    )

            # ── LLM invocation ────────────────────────────────────────────────
            response: LLMResponse | None = None

            if isinstance(agent.llm_provider, DelegateLLMProvider):
                # Bidirectional: runner executes LLM, sends back LLMResponse via asend()
                # TODO: To move out of the strategy directly in the runner? or we need this delegation in every strategy
                response = yield BaseEvent(
                    event_type=ExecutionEventType.LLM_START,
                    action=LLMCallAction(
                        messages=messages,
                        tools=tool_defs,
                        stream=agent.stream,
                    ),
                    author=agent.name,
                )
                if response is None:
                    logger.error("DelegateLLMProvider received None from runner — aborting")
                    break
                yield _create_event(
                    event_type=ExecutionEventType.LLM_END,
                    content=[Part(text="LLM response received via delegate")],
                    author=agent.name,
                )
            else:
                yield _create_event(
                    event_type=ExecutionEventType.LLM_START,
                    content=[Part(text="Invoking LLM with tools")],
                    author=agent.name,
                )
                try:
                    valid_response = False
                    while not valid_response:
                        if agent.stream:
                            streamed_text_parts: list[str] = []
                            response = None
                            last_chunk = None
                            # Stream content as it arrives. If tool_calls follow in
                            # the same turn, this content is a user-visible preamble,
                            # not internal thought; do not copy it onto the tool event.
                            async for chunk in agent.llm_provider.generate_streaming(
                                messages=messages, tools=tool_defs if tool_defs else None
                            ):
                                last_chunk = chunk
                                # Drop only no-op (None/empty) chunks. Whitespace-only
                                # chunks (paragraph breaks, list separators) carry
                                # semantic meaning and must reach the consumer; the
                                # accumulator also depends on them so the final
                                # ``response.content`` keeps its formatting.
                                if chunk.content:
                                    streamed_text_parts.append(chunk.content)
                                    yield BaseEvent(
                                        event_type=ExecutionEventType.RESPONSE_TOKEN,
                                        content=[Part(text=chunk.content)],
                                        author=agent.name,
                                        is_partial=True,
                                    )
                                if chunk.tool_calls:
                                    response = chunk.model_copy(
                                        update={"content": "".join(streamed_text_parts)}
                                    )

                            if response is None:
                                accumulated = "".join(streamed_text_parts)
                                base = last_chunk or LLMResponse(
                                    content="", generated_tokens=0, execution_time=0.0
                                )
                                response = base.model_copy(
                                    update={"content": accumulated, "tool_calls": []}
                                )
                            else:
                                response = response.model_copy(
                                    update={"content": "".join(streamed_text_parts)}
                                )
                        else:
                            response = await agent.llm_provider.generate(
                                messages=messages,
                                tools=tool_defs if tool_defs else None,
                            )

                        if not response.content and not response.tool_calls:
                            logger.error("LLM response has no content and no tool calls")
                            messages.append(
                                LLMMessage(
                                    role="system",
                                    content="LLM response had no content and no tool calls, please generate a response to the final user.",
                                )
                            )
                        else:
                            valid_response = True

                except Exception as e:
                    logger.error(
                        f"LLM generation failed: {e}",
                        payload={"exception": traceback.format_exc()},
                    )
                    yield BaseEvent(
                        event_type=ExecutionEventType.ERROR_OCCURRED,
                        event_id=str(uuid.uuid4()),
                        timestamp=datetime.now(),
                        author=agent.name,
                        content=[Part(text=f"LLM error: {e}")],
                        error_message=str(e),
                        is_partial=False,
                    )
                    break

                yield _create_event(
                    event_type=ExecutionEventType.LLM_END,
                    content=[Part(text="LLM response received")],
                    author=agent.name,
                )

            response_text = (getattr(response, "content", "") or "").strip()
            has_tool_calls = bool(getattr(response, "tool_calls", []))

            # ── Content only (no tool calls) → terminal ───────────────────────
            if response_text and not has_tool_calls:
                if self.use_stop:
                    yield BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=agent.name,
                        action=ToolAction(
                            name=self.context_manager.stop_tool_name,
                            parameters={"info": response_text},
                        ),
                        content=[Part(text=response_text)],
                    )
                else:
                    yield BaseEvent(
                        event_type=ExecutionEventType.RESPONSE,
                        content=[Part(text=response_text)],
                        author=agent.name,
                        is_partial=False,
                    )
                return

            # ── Content + tool calls → emit preamble before tools ─────────────
            # In non-streaming mode the preamble never reached the consumer as
            # RESPONSE_TOKEN, so emit it as a partial RESPONSE before the tool
            # events. In streaming mode the tokens already flowed through
            # RESPONSE_TOKEN; skip the duplicate emission.
            if response_text and has_tool_calls and not agent.stream:
                yield BaseEvent(
                    event_type=ExecutionEventType.RESPONSE,
                    content=[Part(text=response_text)],
                    author=agent.name,
                    is_partial=True,
                )

            # ── Process tool calls ────────────────────────────────────────────
            if has_tool_calls:
                for tool_call in response.tool_calls:
                    try:
                        args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        args = {}

                    tool_name = tool_call.function.name
                    tool = agent.get_tool_by_name(tool_name)

                    if tool:
                        action = ToolAction(
                            call_id=tool_call.id,
                            name=tool_name,
                            parameters=args,
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_START,
                            author=agent.name,
                            action=action,
                        )
                    elif tool_name in [
                        a.name for a in interaction_context.agents_visibility_description
                    ]:
                        agent_action = AgentAction(
                            name=tool_name,
                            parameters=args,
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.AGENT_CALL,
                            author=agent.name,
                            action=agent_action,
                        )
                        return
                    elif tool_name == self.context_manager.stop_tool_name and self.use_stop:
                        yield BaseEvent(
                            event_type=ExecutionEventType.AGENT_END,
                            author=agent.name,
                            action=ToolAction(
                                name=tool_name,
                                parameters=args,
                            ),
                            content=[],
                        )
                        return
                    elif tool_name == self.context_manager.ask_user_tool_name and self.use_stop:
                        yield BaseEvent(
                            event_type=ExecutionEventType.RESPONSE,
                            content=[Part(text=args.get("text", ""))],
                            author=agent.name,
                            need_feedback=True,
                            action=ToolAction(name=tool_name, parameters=args),
                        )
                        return
                    elif (
                        tool_name == self.context_manager.forward_verbatim_tool_name
                        and self.forward_verbatim_enabled
                    ):
                        # FORWARD_VERBATIM ends this planner step on hit. On miss
                        # the planner offers the LLM a bounded number of recovery
                        # attempts (top-level only) by injecting a tool-role
                        # diagnostic and re-iterating; once the budget is spent,
                        # it falls back to the hard-miss terminal.
                        fv_result = _handle_forward_verbatim(
                            agent,
                            interaction_context,
                            tool_call,
                            args,
                            use_stop=self.use_stop,
                            stop_tool_name=self.context_manager.stop_tool_name,
                        )
                        if isinstance(fv_result, BaseEvent):
                            yield fv_result
                            return
                        # Miss path. Sub-agents (use_stop=True) skip soft retry
                        # so the parent — which sees the resulting AGENT_END —
                        # owns recovery. Top-level agents retry up to
                        # ``MAX_FV_SOFT_MISS_RETRIES`` times before terminating.
                        if not self.use_stop and fv_soft_miss_remaining > 0:
                            # Native tool-use invariant: every assistant
                            # tool_call needs a paired tool-role reply. Carry
                            # both forward into the next iteration so the LLM
                            # sees what it tried and the diagnostic in turn.
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="assistant",
                                    content=None,
                                    tool_calls=[tool_call],
                                )
                            )
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="tool",
                                    tool_call_id=tool_call.id,
                                    name=tool_name,
                                    content=fv_result.feedback,
                                )
                            )
                            fv_soft_miss_remaining -= 1
                            logger.info(
                                f"FORWARD_VERBATIM soft-miss: retries remaining={fv_soft_miss_remaining}"
                            )
                            break  # break inner tool_calls loop → next planner iteration
                        # Soft-miss budget exhausted. Last-ditch fallback (top-level
                        # only): tell the LLM to abandon FORWARD_VERBATIM and
                        # RESPOND directly with information already in history,
                        # instead of ending on AGENT_ERROR. Sub-agents skip this
                        # so the parent owns recovery.
                        if not self.use_stop and not fv_hard_fallback_used:
                            fv_hard_fallback_used = True
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="assistant",
                                    content=None,
                                    tool_calls=[tool_call],
                                )
                            )
                            fv_soft_miss_carry.append(
                                LLMMessage(
                                    role="tool",
                                    tool_call_id=tool_call.id,
                                    name=tool_name,
                                    content=FORWARD_VERBATIM_FEEDBACK_HARD_FALLBACK,
                                )
                            )
                            logger.info(
                                "FORWARD_VERBATIM hard-fallback: instructing LLM "
                                "to abandon FV and RESPOND directly"
                            )
                            break  # break inner tool_calls loop → next planner iteration
                        # Hard miss: fallback already used or sub-agent.
                        yield _hard_miss_event(
                            agent,
                            use_stop=self.use_stop,
                            stop_tool_name=self.context_manager.stop_tool_name,
                        )
                        return
                    else:
                        action = ToolAction(
                            call_id=tool_call.id,
                            name=tool_name,
                            parameters=args,
                            observation=f"Tool '{tool_name}' not found",
                        )
                        yield BaseEvent(
                            event_type=ExecutionEventType.TOOL_ERROR,
                            author=agent.name,
                            action=action,
                        )
            elif response.content:
                # No tool calls — LLM is done, emit final response
                if self.use_stop:
                    # the content is the feedback
                    yield BaseEvent(
                        event_type=ExecutionEventType.AGENT_END,
                        author=agent.name,
                        action=ToolAction(
                            name=self.context_manager.stop_tool_name,
                            parameters={"info": response.content or ""},
                        ),
                        content=[Part(text=response.content or "")],
                    )

                else:
                    yield BaseEvent(
                        event_type=ExecutionEventType.RESPONSE,
                        content=[Part(text=response.content or "")],
                        author=agent.name,
                        is_partial=False,
                    )
                return

        # Max iterations reached
        yield BaseEvent(
            event_type=ExecutionEventType.RESPONSE,
            event_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            author=agent.name,
            content=[Part(text=f"Reached maximum iterations ({self.max_iterations})")],
            is_partial=False,
        )
