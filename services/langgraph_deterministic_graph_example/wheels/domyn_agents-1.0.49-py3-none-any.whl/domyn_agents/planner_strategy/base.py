"""Base logic implementation for planner strategies.

This module purposefully avoids importing the concrete *Agent* implementation at
runtime to prevent circular import issues (Agent -> planner_strategy -> Agent).
Only lightweight core/llm types are imported at import time; Agent types are
referenced via forward annotations and imported under TYPE_CHECKING.
"""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import AsyncGenerator
from typing import Any

from pydantic import BaseModel

from domyn_agents.core import BaseAction, BaseEvent

# Import lazy per evitare cicli - Agent viene importato da agents package
# from domyn_agents.agents import Agent  # REMOVED - causes circular import
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import BaseLLMProvider, LLMMessage
from domyn_agents.planner_strategy.context_management.base import MessageContextManager


class BasePlannerStrategy(BaseModel):
    """
    Strategy che decide DINAMICAMENTE le prossime azioni durante l'esecuzione.
    Può restituire multiple azioni da eseguire.
    Integra con LLM provider per l'inferenza e può emettere eventi.
    """

    type: str = "base"
    name: str
    context_manager: MessageContextManager
    max_iterations: int = 25
    verbose: bool = False
    forward_verbatim_enabled: bool = True

    @abstractmethod
    async def execute(
        self, agent: BaseAgent, context: InteractionContext
    ) -> AsyncGenerator[BaseEvent, Any]:
        """Execute the agent logic, yielding events and optionally receiving LLM responses.

        When the agent uses a DelegateLLMProvider, the planner yields LLM_START
        with an LLMCallAction payload instead of calling the provider directly.
        The runner intercepts it, executes the LLM call, and sends back an
        LLMResponse via asend(). The planner receives it as the return value of
        ``response = yield llm_start_event``.

        For all other event types, the sent value is None and can be ignored.
        """
        ...

    # @abstractmethod
    # def update_context(
    #     self, context: AgentContext, actions: list[BaseAction], results: list[Any]
    # ) -> AgentContext:
    #     """Aggiorna il contesto dopo l'esecuzione delle azioni."""
    #     ...

    async def generate_events(
        self,
        context: InteractionContext,
        actions: list[BaseAction],
        results: list[Any],
        llm_provider: BaseLLMProvider,
    ) -> AsyncGenerator[BaseEvent, None]:
        """
        Genera eventi personalizzati usando l'LLM provider per l'inferenza.
        Questo metodo è opzionale e può essere implementato dalle strategie
        che vogliono emettere eventi personalizzati.
        """
        # Default implementation: no events - empty async generator
        if False:  # Making this unreachable code reachable for generator
            yield  # Placeholder to make this a generator function

    async def get_latest_llm_response(self) -> str | None:
        """
        Restituisce l'ultima risposta dell'LLM se disponibile.
        Utile per emettere eventi con il contenuto della risposta.
        """
        return None

    async def invoke_llm(
        self, llm_provider: BaseLLMProvider, prompt: str, context: InteractionContext, **kwargs: Any
    ) -> str:
        """
        Helper method per invocare l'LLM provider con un prompt.
        Le strategie possono utilizzare questo metodo per ottenere inferenza dall'LLM.
        """
        messages = [LLMMessage(role="user", content=prompt)]
        response = await llm_provider.generate(messages, **kwargs)
        return response
