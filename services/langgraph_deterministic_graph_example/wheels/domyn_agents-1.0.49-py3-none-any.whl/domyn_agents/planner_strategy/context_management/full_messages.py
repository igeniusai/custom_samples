from __future__ import annotations

from domyn_agents.core import ExecutionEventType
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import LLMMessage
from domyn_agents.planner_strategy.context_management.base import MessageContextManager


class FullMessageContext(MessageContextManager):
    type: str = "full_messages"
    narrow_non_visible_agents: bool

    async def get_context(
        self, context: InteractionContext, agent: BaseAgent, **kwargs
    ) -> list[LLMMessage]:
        visible_agents_name = [a.name for a in context.agents_visibility_description] + [agent.name]
        messages = [self.prompting.get_system_prompt_message(agent=agent, context=context)]
        included_events = []
        for event in context.conversation_history + context.interaction_history:
            if event.event_id in included_events:
                continue
            else:
                included_events.append(event.event_id)

            match event.event_type:
                case ExecutionEventType.USER_INPUT:
                    messages.append(self.prompting.get_user_request_message(event))

                case ExecutionEventType.RESPONSE:
                    messages.append(
                        self.prompting.get_response_message(event, use_stop=agent.planner.use_stop)
                    )

                case ExecutionEventType.AGENT_END:
                    messages.extend(self.prompting.get_agent_end_messages(event))

                case ExecutionEventType.AGENT_CALL:
                    messages.extend(self.prompting.get_agent_call_messages(event))

                case ExecutionEventType.AGENT_START:
                    if not event.content:
                        event = self.add_default_agent_start_content(event=event, context=context)
                    messages.extend(self.prompting.get_agent_start_messages(event))

                case ExecutionEventType.TOOL_END:
                    if (not self.narrow_non_visible_agents) or (
                        event.author in visible_agents_name
                    ):
                        messages.extend(
                            self.prompting.get_tool_end_messages(
                                event,
                                forward_verbatim_enabled=self.is_forward_verbatim_enabled(agent),
                            )
                        )

                case ExecutionEventType.TOOL_ERROR:
                    messages.extend(self.prompting.get_tool_error_messages(event))

        return messages
