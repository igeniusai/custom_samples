from abc import ABC, abstractmethod
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, model_validator

from domyn_agents.core import BaseEvent, Part
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import LLMMessage
from domyn_agents.planner_strategy.prompting.base import BasePrompting
from domyn_agents.planner_strategy.prompting.json_prompting import JSONMessagePrompting
from domyn_agents.planner_strategy.prompting.messages_building import MessageBuilder
from domyn_agents.planner_strategy.prompting.structural_tags_prompting import (
    StructuralTagMessagePrompting,
)


class ContextManager(ABC, BaseModel):
    type: str
    name: str

    model_config = ConfigDict(extra="ignore")  # oppure "forbid" o "allow"

    @staticmethod
    def is_forward_verbatim_enabled(agent: BaseAgent) -> bool:
        planner = getattr(agent, "planner", None)
        return bool(getattr(planner, "forward_verbatim_enabled", True))

    @abstractmethod
    async def get_context(
        self, context: InteractionContext, agent: BaseAgent, use_stop: bool, **kwargs
    ) -> Any:
        """Builds context to be passed to the model"""


class MessageContextManager(ContextManager, ABC):
    prompting: StructuralTagMessagePrompting | JSONMessagePrompting

    @model_validator(mode="after")
    def check_message_builder_types(self) -> Self:
        """Validates that message_builder is an instance of MessageBuilder and BasePrompting as python is missing intersection types"""
        if not isinstance(self.prompting, MessageBuilder):
            raise ValueError(
                "message_builder must be an instance of MessageBuilder and BasePrompting"
            )
        if not isinstance(self.prompting, BasePrompting):
            raise ValueError(
                "message_builder must be an instance of BasePrompting and MessageBuilder"
            )
        return self

    def add_default_agent_start_content(
        self, context: InteractionContext, event: BaseEvent
    ) -> BaseEvent:
        _e = event.model_copy(deep=True)
        _e.content = [Part(text=context.agent_input.content[0].text)]
        return _e

    async def get_context_with_start(
        self, context: InteractionContext, agent: BaseAgent, use_stop: bool, **kwargs
    ) -> list[LLMMessage]:
        messages = await self.get_context(context=context, agent=agent, use_stop=use_stop, **kwargs)
        messages = self.prompting.add_start_message(messages=messages, agent=agent)
        return messages
