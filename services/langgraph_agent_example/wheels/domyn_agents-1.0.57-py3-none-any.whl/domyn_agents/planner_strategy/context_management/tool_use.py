"""Tool-use context manager for native tool-calling agentic loops.

Builds LLM messages in the OpenAI/Anthropic native tool-use format
instead of embedding tool descriptions in the system prompt.
"""

from __future__ import annotations

import json
from typing import Any

from domyn_agents.core import BaseEvent, ExecutionEventType
from domyn_agents.core.context import InteractionContext
from domyn_agents.core.interfaces import BaseAgent
from domyn_agents.llm.base import LLMMessage, LLMToolCall, ToolCallFunction
from domyn_agents.logger import get_logger
from domyn_agents.planner_strategy.context_management.base import ContextManager
from domyn_agents.planner_strategy.utils import (
    EVENT_ID_HEADER_FMT,
    FORWARD_VERBATIM_DESCRIPTION,
    FORWARD_VERBATIM_SOURCE_ID_DESCRIPTION,
    FORWARD_VERBATIM_SOURCE_KEY_DESCRIPTION,
    FORWARD_VERBATIM_TOOL_NAME,
)
from domyn_agents.tools.base import FunctionDeclaration, Param
from domyn_agents.tools.function_tool import FunctionTool

_FORWARD_VERBATIM_INSTRUCTION = (
    "Use FORWARD_VERBATIM only when a single prior observation already "
    "contains the complete, user-ready answer in natural language and can "
    "be returned as-is. If the prose is wrapped inside a structured "
    "payload, source_key must trace the full path from the observation "
    "root to the prose leaf and must resolve to a string, not a container. "
    "Do not use FORWARD_VERBATIM for partial answers, metadata-only "
    "observations (listings, IDs, status flags, raw records without prose), "
    "or when the user asked for a different format, length, language, "
    "transformation, or synthesis across multiple observations. In those "
    "cases, use RESPOND with the necessary summary or adaptation."
)


class ToolUseContextManager(ContextManager):
    """Context manager that builds messages for native tool-calling APIs."""

    type: str = "tool_use"
    name: str = "tool_use"
    max_tool_result_chars: int = 16_000

    stop_tool_name: str = "STOP"
    ask_user_tool_name: str = "ASK_USER_MISSING_INFO"
    respond_tool_name: str = "RESPOND"
    forward_verbatim_tool_name: str = FORWARD_VERBATIM_TOOL_NAME
    forward_verbatim_instruction: str = _FORWARD_VERBATIM_INSTRUCTION
    info_start_pattern: str = "<INFO>"
    info_end_pattern: str = "</INFO>"
    user_role: str = "user"
    assistant_role: str = "assistant"
    user_info_key: str = "user_info"

    async def get_context(
        self, context: InteractionContext, agent: BaseAgent, **kwargs: Any
    ) -> list[LLMMessage]:
        """Build message list from conversation history in native tool-use format."""
        messages: list[LLMMessage] = []
        forward_verbatim_enabled = self.is_forward_verbatim_enabled(agent)

        # System message with agent instructions (no tool format descriptions)
        system_content = self._build_system_prompt(agent, context)
        messages.append(LLMMessage(role="system", content=system_content))

        # Convert conversation + interaction history to messages
        included_events: list[str | None] = []

        event_to_parse = list(context.conversation_history)
        if context.agent_input and context.agent_input.action:
            event_to_parse.append(context.agent_input)
        event_to_parse += context.interaction_history

        for event in event_to_parse:
            if event.event_id in included_events:
                continue
            included_events.append(event.event_id)

            match event.event_type:
                case ExecutionEventType.USER_INPUT:
                    messages.append(self._get_user_request_message(event))

                case ExecutionEventType.TOOL_START:
                    if event.action:
                        thought = event.action.thought or ""
                        tool_call = LLMToolCall(
                            id=event.action.call_id,
                            type="function",
                            function=ToolCallFunction(
                                name=event.action.name,
                                arguments=json.dumps(
                                    event.action.parameters or {}, ensure_ascii=False
                                ),
                            ),
                        )
                        # Group consecutive TOOL_START events into one assistant message
                        # so parallel tool calls share a single assistant turn.
                        if (
                            messages
                            and messages[-1].role == "assistant"
                            and messages[-1].tool_calls
                        ):
                            messages[-1].tool_calls.append(tool_call)
                            # Merge thought if present
                            if thought:
                                existing = messages[-1].content or ""
                                messages[-1].content = (
                                    f"{existing}\n{thought}".strip() if existing else thought
                                )
                        else:
                            messages.append(
                                LLMMessage(
                                    role=self.assistant_role,
                                    tool_calls=[tool_call],
                                )
                            )

                case ExecutionEventType.TOOL_END | ExecutionEventType.TOOL_ERROR:
                    if event.action:
                        # Build the event_id header first so the truncation
                        # budget accounts for it — total content stays within
                        # max_tool_result_chars. The header lets the LLM
                        # reference this observation by event_id in a later
                        # FORWARD_VERBATIM call.
                        #
                        # Header exposure is controlled by the current
                        # planner only. If this event is already in the
                        # current agent's visible context, the agent may
                        # forward it when its own FV tool is enabled; a
                        # sub-agent's FV flag only controls what that sub can
                        # do inside its own planner.
                        header = (
                            EVENT_ID_HEADER_FMT.format(event_id=event.event_id) + "\n"
                            if event.event_id and forward_verbatim_enabled
                            else ""
                        )
                        body_budget = self.max_tool_result_chars - len(header)
                        if body_budget <= 0:
                            # Header alone meets/exceeds budget — drop header so
                            # observation content survives within the limit.
                            # NOTE: dropping the header breaks FORWARD_VERBATIM
                            # for this observation (no event_id for the LLM to
                            # reference). Surface it loudly so misconfigured
                            # max_tool_result_chars doesn't fail silently.
                            get_logger().warning(
                                "max_tool_result_chars=%d is smaller than the "
                                "event_id header (%d chars) for event_id=%s; "
                                "dropping header — FORWARD_VERBATIM will not "
                                "be able to reference this tool result.",
                                self.max_tool_result_chars,
                                len(header),
                                event.event_id,
                            )
                            header = ""
                            body_budget = self.max_tool_result_chars
                        observation = str(event.action.observation or "")
                        if len(observation) > body_budget:
                            observation = observation[:body_budget] + "\n...(truncated)"
                        observation = header + observation
                        messages.append(
                            LLMMessage(
                                role="tool",
                                tool_call_id=event.action.call_id,
                                name=event.action.name,
                                content=observation,
                            )
                        )

                case ExecutionEventType.RESPONSE:
                    text = self._extract_text(event)
                    if text:
                        messages.append(LLMMessage(role=self.assistant_role, content=text))

                case ExecutionEventType.AGENT_END:
                    # it's a feedback from a sub-agent, we can extract it as assistant content to be visible in the main agent context
                    if event.action and event.action.name == self.stop_tool_name:
                        # Render only the sub's *prose* payload, not the raw
                        # ``{"info": "..."}`` parameters dict. Dumping the dict
                        # form leaks the STOP-tool envelope shape to the parent
                        # LLM, which has historically picked ``source_key="info"``
                        # for FORWARD_VERBATIM as if it were a JSON dot-path —
                        # but at the AGENT_END boundary the sub already extracted
                        # its answer; ``source_key`` must be empty.
                        params = event.action.parameters or {}
                        if isinstance(params, dict) and "info" in params:
                            info = params["info"]
                        elif params:
                            info = params
                        else:
                            info = self._extract_text(event)
                        # event_id header surfaced when the caller is FV-capable
                        # (has the FORWARD_VERBATIM tool registered). Visibility
                        # has already been decided by the context; the emitting
                        # sub-agent's FV flag only controls whether that sub can
                        # call FORWARD_VERBATIM inside its own planner.
                        header = (
                            EVENT_ID_HEADER_FMT.format(event_id=event.event_id)
                            if event.event_id and forward_verbatim_enabled
                            else None
                        )
                        content = (
                            f"Sub-Agent: {event.author} ended"
                            f"{f' {header}' if header else ''}.\n"
                            f"Information from this agent's execution: {info}"
                        )
                        messages.append(LLMMessage(role=self.user_role, content=content))
                    else:
                        text = self._extract_text(event)
                        if text:
                            messages.append(LLMMessage(role=self.assistant_role, content=text))

                case ExecutionEventType.AGENT_CALL:
                    # calling agent invoked a sub-agent

                    tool_call = LLMToolCall(
                        id=event.action.call_id,
                        type="function",
                        function=ToolCallFunction(
                            name=event.action.name,
                            arguments=json.dumps(event.action.parameters or {}, ensure_ascii=False),
                        ),
                    )
                    messages.append(LLMMessage(role=self.assistant_role, tool_calls=[tool_call]))

                case ExecutionEventType.AGENT_START:
                    # called agent receiving its task assignment
                    task = event.content[0].text if event.content else ""
                    if not task and context.agent_input:
                        task = (
                            context.agent_input.content[0].text
                            if context.agent_input.content
                            else ""
                        )
                    if messages and messages[-1].role != self.user_role:
                        messages.append(
                            LLMMessage(
                                role=self.user_role,
                                content=f"Agent: {event.author}\nTask assigned: {task}\n",
                            )
                        )

        return messages

    def get_special_tools(
        self, use_stop: bool, forward_verbatim_enabled: bool
    ) -> list[FunctionTool]:
        special_tools: list[FunctionTool] = []

        if use_stop:
            _stop = FunctionTool(func=lambda: None, name=self.stop_tool_name, description="")
            _stop.set_declaration(
                FunctionDeclaration(
                    name=self.stop_tool_name,
                    description="When you have completed your task, use this tool to return the data you have found to the agent that invoked you. Pass all the information you deem relevant in the 'info' field. Don't provide the final answer to the user but use this tool to return to the previous agent first.",
                    parameters=[
                        Param(
                            name="info",
                            type="str",
                            description="The information to return to the calling agent",
                        )
                    ],
                )
            )
            _ask = FunctionTool(func=lambda: None, name=self.ask_user_tool_name, description="")
            _ask.set_declaration(
                FunctionDeclaration(
                    name=self.ask_user_tool_name,
                    description="Use this action to ask questions to the user if you can't proceed without more information. Don't use this to provide the final answer to the user, use the stop tool instead.",
                    parameters=[
                        Param(name="text", type="str", description="The question to ask the user")
                    ],
                )
            )
            special_tools.extend([_stop, _ask])

        if forward_verbatim_enabled:
            _fwd = FunctionTool(
                func=lambda: None, name=self.forward_verbatim_tool_name, description=""
            )
            _fwd.set_declaration(
                FunctionDeclaration(
                    name=self.forward_verbatim_tool_name,
                    description=FORWARD_VERBATIM_DESCRIPTION,
                    parameters=[
                        Param(
                            name="source_id",
                            type="str",
                            description=FORWARD_VERBATIM_SOURCE_ID_DESCRIPTION,
                        ),
                        Param(
                            name="source_key",
                            type="str",
                            description=FORWARD_VERBATIM_SOURCE_KEY_DESCRIPTION,
                        ),
                    ],
                )
            )
            special_tools.append(_fwd)

        return special_tools

    def get_tool_definitions(
        self, agent: BaseAgent, context: InteractionContext
    ) -> list[dict[str, Any]]:
        """Get native tool definitions for all agent tools + visible sub-agents."""
        tool_defs: list[dict[str, Any]] = []

        # Add regular tools
        for tool in agent.tools:
            if hasattr(tool, "tool_definition"):
                tool_defs.append(tool.tool_definition)

        # Add visible sub-agents as callable tools
        for agent_desc in context.agents_visibility_description:
            agent_tool_def: dict[str, Any] = {
                "type": "function",
                "function": {
                    "name": agent_desc.name,
                    "description": agent_desc.description,
                    "parameters": agent_desc.invocation_parameters
                    or {
                        "type": "object",
                        "properties": {},
                    },
                },
            }
            tool_defs.append(agent_tool_def)

        # special tools always append at bottom
        use_stop: bool = getattr(agent.planner, "use_stop", False)
        for tools in self.get_special_tools(use_stop, self.is_forward_verbatim_enabled(agent)):
            tool_defs.append(tools.tool_definition)

        for tool in tool_defs:
            tool["function"]["parameters"]["properties"]["reasoning"] = {
                "description": "Reasoning that brought the agent to choose this tool. Be concise.",
                "type": "string",
            }

        return tool_defs

    def _build_system_prompt(self, agent: BaseAgent, context: InteractionContext) -> str:
        """Build a clean system prompt with agent instructions only."""
        parts: list[str] = []

        if hasattr(agent, "instruction") and agent.instruction:
            parts.append(agent.instruction)

        if not parts:
            parts.append(f"You are {agent.name}. {agent.description}")

        if self.is_forward_verbatim_enabled(agent):
            parts.append(self.forward_verbatim_instruction)

        return "\n\n".join(parts)

    @staticmethod
    def _extract_text(event: Any) -> str:
        """Extract text content from an event's content parts."""
        if not event.content:
            return ""
        texts = []
        for part in event.content:
            if hasattr(part, "text") and part.text:
                texts.append(part.text)
        return " ".join(texts)

    def _get_user_request_message(self, event: BaseEvent) -> LLMMessage:
        info = ""
        if user_info := event.metadata.get(self.user_info_key, {}):
            if isinstance(user_info, dict):
                for k, v in user_info.items():
                    info += f"{k.upper()}: {v}\n"
            else:
                info = str(user_info)

        message = f"{self.info_start_pattern}\n{info}{self.info_end_pattern}\n\n" if info else ""

        text = self._extract_text(event)
        if text:
            message += f"USER INPUT: {text}"

        return LLMMessage(role=self.user_role, content=message)


_REACT_THOUGHT_INSTRUCTION = """Never generate text when calling a tool. Instead, if you have any reasoning or thoughts that led you to call the tool, include them in the field dedicated to reasoning. Always include reasoning if you have it, even if it's just a few words.
The content field MUST be reserved for information you want to share with the user, and MUST NOT include any information about your thought process or tool calls."""


class ToolUseWithThoughtContextManager(ToolUseContextManager):
    """Context manager for ReAct-style tool-use loops.

    Identical to ``ToolUseContextManager`` but appends a reasoning instruction
    to the system prompt so that the LLM emits plain-text ``content`` before
    every tool call.  That content is then captured as the ``thought`` by
    ``ToolUseWithThoughtPlannerStrategy``.
    """

    type: str = "thought_tool_use"
    name: str = "thought_tool_use"
    thought_instruction: str = _REACT_THOUGHT_INSTRUCTION

    def _build_system_prompt(self, agent: BaseAgent, context: InteractionContext) -> str:
        """Build system prompt with an added reasoning instruction."""
        base = super()._build_system_prompt(agent, context)
        return f"{base}\n\n{self.thought_instruction}"
