"""SSE-based RunnerTransport for DelegateAgent.

Communicates with a relay over two HTTP primitives:

* **Receive** — ``POST {url}?channelId=…&spaceId=…&conversationId=…`` opens a
  Server-Sent Events stream.  The SSE connection stays open and streams all
  events as they arrive.  It is only closed and reopened when the runner calls
  ``send_result`` (i.e. a known/platform tool was executed locally and the
  result must be forwarded to the relay).  Observational events (LLM_START,
  LLM_END, remote-side TOOL_START/TOOL_END) never trigger a close, so events
  already in the TCP receive buffer are never lost.

* **Send** — the next SSE open carries the result event as its POST body,
  forwarding it to the relay's WS clients in the same request that re-opens
  the subscription.

Wire it up::

    from domyn_agents.runner.sse_transport import SSETransport
    from domyn_agents.agents.delegate_agent import DelegateAgent

    transport = SSETransport(
        url="https://relay/internal/v1/messages",
        channel_id="abc123",
        space_id="space-uuid",
    )
    agent = DelegateAgent(name="Expert", description="…", transport=transport)

Or via config dict (as produced by the config loader)::

    transport:
      type: sse
      url: https://relay/internal/v1/messages
      headers:
        channel-id: abc123
        space-id: space-uuid
      timeout: 60.0
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import Any, ClassVar

import httpx
from httpx_sse import aconnect_sse

from domyn_agents.core import AgentAction, BaseEvent, ExecutionEventType, Part, RelayMessage
from domyn_agents.core.context import InteractionContext
from domyn_agents.logger import get_logger
from domyn_agents.runner.transport import RunnerTransport
from domyn_agents.tracing import inject_trace_headers


def _is_terminal_event(event: BaseEvent) -> bool:
    """Return True when the full delegate session is over."""
    if event.event_type == ExecutionEventType.AGENT_END:
        return True
    return event.event_type == ExecutionEventType.RESPONSE and not event.is_partial


class SSETransport(RunnerTransport):
    """SSE transport for ``DelegateAgent`` with close-on-send semantics.

    One SSE connection is kept open and streams all events from the relay.
    The connection is only closed (and immediately reopened) when
    ``send_result`` is called — that is, when the runner has executed a local
    tool and needs to forward the result to the remote agent.  Purely
    observational events (LLM_START/LLM_END, remote tool execution) never
    trigger a close, avoiding TCP-buffer event loss.

    Parameters
    ----------
    url:
        URL of the relay endpoint.
    channel_id:
        Relay channel identifier (``channelId`` query param).
    space_id:
        Relay space / tenant identifier (``spaceId`` query param).
    meta:
        Extra HTTP headers sent on every request.
    timeout:
        Connect / write timeout in seconds.  SSE read is unbounded.
    """

    type: ClassVar[str] = "sse"

    @classmethod
    def from_config(cls, config: dict) -> SSETransport:
        headers: dict[str, str] = config.get("headers") or {}
        return cls(
            url=config.get("url", ""),
            channel_id=headers.get("channel-id", ""),
            space_id=headers.get("space-id", ""),
            meta=config.get("meta") or (headers if headers else None),
            timeout=float(config.get("timeout", 60.0)),
        )

    def __init__(
        self,
        url: str,
        channel_id: str,
        space_id: str,
        meta: dict[str, str] | None = None,
        timeout: float = 60.0,
    ) -> None:
        self._url = url
        self._channel_id = channel_id
        self._space_id = space_id
        self._meta = meta or {}
        self._timeout = timeout
        # Per-session state, reset in execute().
        self._send_trigger: asyncio.Event | None = None
        self._pending_send: BaseEvent | None = None

    # ------------------------------------------------------------------
    # RunnerTransport interface
    # ------------------------------------------------------------------

    async def execute(
        self,
        agent_name: str,
        context: InteractionContext,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Stream events from the relay for *agent_name*.

        Opens an SSE connection with AGENT_START as the POST body.  The
        connection is kept alive until either:

        * A terminal event (AGENT_END or final RESPONSE) is received → done.
        * ``send_result`` is called by the runner (a local tool was executed)
          → close, then reopen with the result as the next POST body.

        All other events (LLM_START/LLM_END, observational TOOL_START/END)
        are yielded without closing the connection.
        """
        user_text = self._extract_user_text(context)
        conversation_id: str = context.conversation_id or ""

        forwarded_action = (
            context.agent_input.action
            if context.agent_input is not None
            and context.agent_input.event_type == ExecutionEventType.AGENT_START
            and isinstance(context.agent_input.action, AgentAction)
            else AgentAction(
                name=agent_name,
                parameters={"task": user_text},
            )
        )
        agent_start = BaseEvent(
            event_type=ExecutionEventType.AGENT_START,
            author=agent_name,
            content=[Part(text=user_text)],
            action=forwarded_action,
            conversation_id=conversation_id,
            interaction_id=context.interaction_id,
            turn_id=context.turn_id,
        )

        self._send_trigger = asyncio.Event()
        self._pending_send = agent_start

        get_logger().info(
            "[SSE transport] Opening session for agent '%s' (conv=%s)",
            agent_name,
            conversation_id,
        )

        sse_timeout = httpx.Timeout(
            connect=self._timeout,
            read=self._timeout,
            write=self._timeout,
            pool=self._timeout,
        )
        async with httpx.AsyncClient(headers=self._meta, timeout=sse_timeout) as client:
            while True:
                self._send_trigger.clear()

                async for event in self._open_sse(
                    client, agent_name, conversation_id, body=self._pending_send
                ):
                    self._pending_send = None
                    yield event

                    if _is_terminal_event(event):
                        get_logger().info(
                            "[SSE transport] Session complete for agent '%s'", agent_name
                        )
                        return

                    # Close and reopen only when send_result was called.
                    if self._send_trigger.is_set():
                        break

                else:
                    # SSE stream ended cleanly without a terminal event.
                    get_logger().warning(
                        "[SSE transport] SSE stream ended without terminal event for '%s'",
                        agent_name,
                    )
                    return

                # send_result was called — loop back with the result as body.
                get_logger().debug(
                    "[SSE transport] Reopening SSE to send %s for agent '%s'",
                    self._pending_send.event_type.value if self._pending_send else "?",
                    agent_name,
                )

    async def send_result(self, event: BaseEvent) -> None:
        """Signal that a local tool result is ready to be forwarded.

        Sets ``_pending_send`` and fires the trigger so ``execute`` closes
        the current SSE and reopens with the result as the POST body.
        """
        get_logger().debug("[SSE transport] send_result %s", event.event_type.value)
        self._pending_send = event
        if self._send_trigger is not None:
            self._send_trigger.set()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _open_sse(
        self,
        client: httpx.AsyncClient,
        agent_name: str,
        conversation_id: str,
        body: BaseEvent | None = None,
    ) -> AsyncGenerator[BaseEvent, None]:
        """Open one SSE connection, optionally forwarding *body* to the relay."""
        params: dict[str, str] = {
            "channelId": self._channel_id,
            "spaceId": self._space_id,
            "conversationId": conversation_id,
        }

        get_logger().debug(
            "[SSE transport] Connecting to %s (body=%s, conv=%s)",
            self._url,
            body.event_type.value if body else None,
            conversation_id,
        )

        kwargs: dict[str, Any] = {"params": params}
        if body is not None:
            kwargs["content"] = body.model_dump_json()
            kwargs["headers"] = inject_trace_headers({"Content-Type": "application/json"})

        try:
            async with aconnect_sse(
                client,
                "POST",
                self._url,
                **kwargs,
            ) as event_source:
                async for sse_event in event_source.aiter_sse():
                    if not sse_event.data or sse_event.data.strip() == "":
                        continue  # heartbeat / keep-alive

                    try:
                        body = RelayMessage.model_validate_json(sse_event.data)
                        event = body.payload
                        _ = body.meta
                    except Exception:
                        get_logger().warning(
                            "[SSE transport] Could not parse SSE event: %r", sse_event.data
                        )
                        continue

                    if (
                        conversation_id
                        and event.conversation_id
                        and event.conversation_id != conversation_id
                    ):
                        get_logger().debug(
                            "[SSE transport] Skipping event for conversation %s (expected %s)",
                            event.conversation_id,
                            conversation_id,
                        )
                        continue

                    event = event.model_copy(update={"author": agent_name})
                    get_logger().debug("[SSE transport] Received %s", event.event_type.value)
                    yield event

        except httpx.TimeoutException:
            error_msg = (
                f"The delegated agent '{agent_name}' did not respond within the timeout period. "
                "The connection has been closed. Please check the agent's availability and connection."
            )
            get_logger().warning(
                "[SSE transport] Timeout waiting for SSE event — closing connection for '%s'",
                agent_name,
            )
            yield BaseEvent(
                event_type=ExecutionEventType.AGENT_END,
                author=agent_name,
                error_code="delegate_timeout",
                error_message=error_msg,
                content=[Part(text=error_msg)],
            )
        except httpx.HTTPStatusError as exc:
            get_logger().error(
                "[SSE transport] HTTP error on SSE stream: %s %s",
                exc.response.status_code,
                exc.response.text,
            )
            raise
        except Exception as exc:
            get_logger().error("[SSE transport] Unexpected error on SSE stream: %s", exc)
            raise

    @staticmethod
    def _extract_user_text(context: InteractionContext) -> str:
        """Pull plain text from the user input event in *context*."""
        user_input = context.agent_input

        parts = getattr(user_input, "content", []) or []
        text_from_content = " ".join(p.text for p in parts if p.text)
        if text_from_content:
            return text_from_content

        action = getattr(user_input, "action", None)
        if action is not None:
            params: dict[str, Any] = getattr(action, "parameters", None) or {}
            task: str = params.get("task", "")
            user_request: str = params.get("user_request", "")
            if task and user_request and task != user_request:
                return f"{user_request}\n\nTask: {task}"
            return task or user_request

        return ""
